/-
Copyright (c) 2026 PolyFun Contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Quang Dao, Devon Tuma
-/
module

public import Cslib.Foundations.Data.PFunctor.Free.W
public import PolyFun.Control.Monad.Hom
public import PolyFun.PFunctor.Basic
public import PolyFun.PFunctor.Lens.Basic
public import ToCslib.Data.PFunctor.Free.Basic

/-!
# Free Monad of a Polynomial Functor

PolyFun's layer over cslib's free monad `PFunctor.FreeM`: the W-type presentation of programs
with return values, root predicates, transport along lenses, and the bundled monad-homomorphism
form of `FreeM.liftM` with its universal property and naturality. This module re-exports cslib's
fold `FreeM.foldFreeM` and its laws, cslib's W-type equivalence `FreeM.equivWOfIsEmpty` for an
empty leaf type, and the constructor-spelled node equations staged in
`ToCslib.Data.PFunctor.Free.Basic`.
-/

@[expose] public section

/--
Simp set for structurally unfolding `FreeM` and displayed-family operations.

This set is reserved for one-way unfolding lemmas: constructor equations for
`FreeM` operations, displayed-family operations, and local-hom recursion through
`liftBind`. Folding and normalization lemmas should not be tagged with this
attribute.
-/
register_simp_attr freeM_unfold

universe u v uA uB uA₂ uB₂ uA₃ uB₃ uδ uβ uγ

namespace PFunctor

namespace FreeM

variable {P : PFunctor.{uA, uB}} {α β γ : Type v}

/-! ## Fixed-point presentation -/

/-- Reinterpret a finite free program as the W-type of query-or-return
nodes. Query nodes are the left summand and return nodes are nullary nodes in
the constant right summand. -/
def toWWithReturn : FreeM P α → (P + C.{v, uB} α).W
  | .pure value => ⟨Sum.inr value, PEmpty.elim⟩
  | .liftBind position next =>
      ⟨Sum.inl position, fun direction => toWWithReturn (next direction)⟩

/-- Decode the query-or-return W-type as a finite free program. -/
def ofWWithReturn : (P + C.{v, uB} α).W → FreeM P α
  | ⟨Sum.inl position, next⟩ =>
      FreeM.liftBind position fun direction => ofWWithReturn (next direction)
  | ⟨Sum.inr value, _⟩ => FreeM.pure value

@[simp] theorem toWWithReturn_pure (value : α) :
    toWWithReturn (pure value : FreeM P α) =
      WType.mk (Sum.inr value) PEmpty.elim :=
  rfl

theorem toWWithReturn_liftBind (position : P.A)
    (next : P.B position → FreeM P α) :
    toWWithReturn (FreeM.liftBind position next) =
      WType.mk (Sum.inl position) fun direction =>
        toWWithReturn (next direction) :=
  rfl

@[simp] theorem ofWWithReturn_return (value : α)
    (next : PEmpty → (P + C.{v, uB} α).W) :
    ofWWithReturn (WType.mk (Sum.inr value) next) = FreeM.pure value :=
  rfl

@[simp] theorem ofWWithReturn_query (position : P.A)
    (next : P.B position → (P + C.{v, uB} α).W) :
    ofWWithReturn (WType.mk (Sum.inl position) next) =
      FreeM.liftBind position fun direction => ofWWithReturn (next direction) :=
  rfl

/-- `FreeM P α` is the initial algebra, or W-type, for the polynomial
`P + C α`. -/
def equivWWithReturn : FreeM P α ≃ (P + C.{v, uB} α).W where
  toFun := toWWithReturn
  invFun := ofWWithReturn
  left_inv program := by
    induction program with
    | pure value => rfl
    | lift_bind position next ih =>
        exact congrArg (FreeM.liftBind position) (funext ih)
  right_inv tree := by
    induction tree with
    | mk shape next ih =>
        cases shape with
        | inl position =>
            exact congrArg (WType.mk (Sum.inl position)) (funext ih)
        | inr value =>
            exact congrArg (WType.mk (Sum.inr value))
              (funext fun direction => direction.elim)

/-- Test only the root of a free polynomial tree.

A leaf demands `leafPred` of its result, while an internal node demands
`positionPred` of its exposed position. This deliberately does not recurse
into the continuations; callers can quantify over paths or cursors when they
need a whole-tree property. -/
def RootSatisfies (positionPred : P.A → Prop) (leafPred : α → Prop) :
    FreeM P α → Prop
  | .pure result => leafPred result
  | .liftBind position _ => positionPred position

@[simp]
theorem rootSatisfies_pure (positionPred : P.A → Prop) (leafPred : α → Prop)
    (result : α) :
    RootSatisfies positionPred leafPred (pure result : FreeM P α) =
      leafPred result :=
  rfl

theorem rootSatisfies_liftBind (positionPred : P.A → Prop) (leafPred : α → Prop)
    (position : P.A) (next : P.B position → FreeM P α) :
    RootSatisfies positionPred leafPred
        (FreeM.liftBind (P := P) position next) =
      positionPred position :=
  rfl

section mapLens

variable {Q : PFunctor.{uA₂, uB₂}} {R : PFunctor.{uA₃, uB₃}}

/-- Transport a free polynomial tree along a polynomial lens.

The source polynomial `P` is the abstract/control interface. The target
polynomial `Q` is the concrete/runtime interface. At each `P`-node, the lens
chooses a `Q`-position by `toFunA`; when runtime supplies a `Q`-direction,
`toFunB` maps it back to the corresponding `P`-direction selecting the
control continuation. -/
@[implicit_reducible]
protected def mapLens (l : Lens P Q) : FreeM P α → FreeM Q α
  | .pure x => .pure x
  | .liftBind a rest => .liftBind (l.toFunA a) fun d =>
      (rest (l.toFunB a d)).mapLens l

@[simp]
theorem mapLens_pure (l : Lens P Q) (x : α) :
    (pure x : FreeM P α).mapLens l = FreeM.pure x :=
  rfl

theorem mapLens_liftBind (l : Lens P Q) (a : P.A) (rest : P.B a → FreeM P α) :
    (FreeM.liftBind a rest).mapLens l =
      FreeM.liftBind (l.toFunA a) (fun d ↦ (rest (l.toFunB a d)).mapLens l) :=
  rfl

@[simp]
theorem mapLens_id (x : FreeM P α) :
    x.mapLens (Lens.id P) = x := by
  induction x with
  | pure _ => rfl
  | lift_bind a rest ih => exact congrArg (FreeM.liftBind a) (funext ih)

@[simp]
theorem mapLens_mapLens (l₂ : Lens Q R) (l₁ : Lens P Q) (x : FreeM P α) :
    (x.mapLens l₁).mapLens l₂ = x.mapLens (l₂ ∘ₗ l₁) := by
  induction x with
  | pure _ => rfl
  | lift_bind a rest ih =>
      exact congrArg (FreeM.liftBind (l₂.toFunA (l₁.toFunA a))) (funext fun d => ih _)

@[deprecated (since := "2026-10-19")] alias mapLens_comp := mapLens_mapLens

theorem mapLens_bind (l : Lens P Q) (x : FreeM P α) (f : α → FreeM P β) :
    (FreeM.bind x f).mapLens l =
      FreeM.bind (x.mapLens l) (fun a => (f a).mapLens l) := by
  induction x with
  | pure _ => rfl
  | lift_bind a rest ih => exact congrArg (FreeM.liftBind (l.toFunA a)) (funext fun d => ih _)

@[simp]
theorem mapLens_bind' (l : Lens P Q) (x : FreeM P α) (f : α → FreeM P β) :
    (x >>= f).mapLens l = x.mapLens l >>= fun a => (f a).mapLens l := mapLens_bind l x f

/-- Relabelling a program along a lens commutes with mapping its results. -/
@[simp]
theorem mapLens_map (l : Lens P Q) (f : α → β) (x : FreeM P α) :
    (f <$> x).mapLens l = f <$> x.mapLens l := by
  induction x with
  | pure _ => rfl
  | lift_bind a rest ih => exact congrArg (FreeM.liftBind (l.toFunA a)) (funext fun d => ih _)

end mapLens

section liftM

variable {m : Type uB → Type v} {α : Type uB} [Monad m] [LawfulMonad m]
  (s : (a : P.A) → m (P.B a))

/-- `FreeM.liftM` as a monad homomorphism. -/
protected def liftMHom (s : (a : P.A) → m (P.B a)) : FreeM P →ᵐ m where
  toFun _ x := x.liftM s
  toFun_pure' := FreeM.liftM_pure s
  toFun_bind' := FreeM.liftM_bind s

@[simp] lemma liftMHom_toFun_eq (s : (a : P.A) → m (P.B a)) :
    ((FreeM.liftMHom s).toFun α) = fun x => x.liftM s := rfl

/-- `FreeM.liftM` as a monad homomorphism, packaging the interpretation of
positions as a natural transformation `NatHom P.Obj m`. -/
protected def liftMHom' (s : NatHom P.Obj m) : FreeM P →ᵐ m where
  toFun _ x := x.liftM (fun t => s ⟨t, id⟩)
  toFun_pure' _ := rfl
  toFun_bind' x y := FreeM.liftM_bind _ x y

@[simp] lemma liftMHom'_toFun_eq (s : NatHom P.Obj m) :
    (FreeM.liftMHom' s).toFun α = fun x => x.liftM (fun t => s ⟨t, id⟩) := rfl

/-! ## Universal property and naturality of the fold

`FreeM.liftM s` is the universal fold: the *unique* monad homomorphism out of `FreeM P` extending a
handler `s` (`liftMHom_unique`), and it is *natural* in the target monad — post-composing with a
monad morphism `φ : m →ᵐ n` is the fold of the post-composed handler (`liftM_natural`,
`liftMHom_comp`). This is the freeness of `FreeM P`; downstream it lets a semantic monad morphism
(e.g. an evaluation-distribution map) be pushed through a fold uniformly, rather than re-run by
induction per interpretation. -/

variable {n : Type uB → Type u} [Monad n] [LawfulMonad n]

/-- **Universal property of `FreeM.liftM`** (freeness of `FreeM P`): a monad homomorphism out of
`FreeM P` is determined by its action on generators. If `F : FreeM P →ᵐ m` agrees with `s` on every
`FreeM.lift a`, then `F = FreeM.liftMHom s`. So handlers `(a : P.A) → m (P.B a)` are in bijection
with monad homomorphisms `FreeM P →ᵐ m` — the universal property behind `simulateQ`. -/
theorem liftMHom_unique (F : FreeM P →ᵐ m) (h : ∀ a, F (FreeM.lift a) = s a) :
    F = FreeM.liftMHom s :=
  MonadHom.ext' fun _ x => congrFun (FreeM.Interprets.eq (handler := s)
    { apply_pure := F.mmap_pure
      apply_lift_bind := fun a cont => by
        rw [← h a]
        exact F.mmap_bind (FreeM.lift a) cont }) x

omit [LawfulMonad m] [LawfulMonad n] in
/-- **Naturality of the fold along a monad morphism**: pushing a monad morphism `φ : m →ᵐ n` through
`FreeM.liftM s` is the fold of the post-composed handler `fun a => φ (s a)` — the value-level
naturality square of the universal fold. -/
@[simp, grind =] theorem liftM_natural (φ : m →ᵐ n) (x : FreeM P α) :
    φ (FreeM.liftM s x) = FreeM.liftM (fun a => φ (s a)) x := by
  induction x with
  | pure x => exact φ.mmap_pure x
  | lift_bind a r ih => simp [ih]

/-- Bundled form of `liftM_natural`: composing the fold monad-homomorphism `FreeM.liftMHom s` with
a monad morphism `φ` is the fold of the post-composed handler. -/
theorem liftMHom_comp (φ : m →ᵐ n) :
    φ ∘ᵐ FreeM.liftMHom s = FreeM.liftMHom (fun a => φ (s a)) :=
  MonadHom.ext' fun β x => by simp

/-- Interpreting a relabelled program pulls the handler back along the lens: the handler
answers at the relabelled position and the lens's backward map translates the direction. -/
theorem liftM_mapLens {Q : PFunctor.{uA₂, uB}} (l : Lens P Q) (h : (a : Q.A) → m (Q.B a)) :
    ∀ x : FreeM P α, (x.mapLens l).liftM h = x.liftM fun a => l.toFunB a <$> h (l.toFunA a)
  | .pure _ => rfl
  | .liftBind a rest => by
    rw [FreeM.mapLens_liftBind]
    change (h (l.toFunA a) >>= fun d => ((rest (l.toFunB a d)).mapLens l).liftM h) =
      (l.toFunB a <$> h (l.toFunA a)) >>= fun d =>
        (rest d).liftM fun a => l.toFunB a <$> h (l.toFunA a)
    rw [bind_map_left]
    exact bind_congr fun d => liftM_mapLens l h (rest (l.toFunB a d))

end liftM

section stateNaturality

variable {m : Type uB → Type v} {n : Type uB → Type u} [Monad m] [Monad n] {σ : Type uB}
  {α : Type uB}

/-- **Stateful naturality of the fold**: running a fold whose stateful handler is post-composed by
a `StateT`-lifted monad morphism `StateT.mapHom φ` is `φ` applied to the run of the original fold —
the shape a `StateT`-threaded semantic morphism (e.g. an evaluation-distribution map through a
stateful handler) instantiates, collapsing a per-interpretation induction to one use of
`liftM_natural`. -/
theorem run_liftM_mapHom (φ : m →ᵐ n) (impl : (a : P.A) → StateT σ m (P.B a))
    (x : FreeM P α) (s : σ) :
    (FreeM.liftM (fun a => StateT.mapHom φ (impl a)) x).run s =
      φ ((FreeM.liftM impl x).run s) := by
  rw [← liftM_natural impl (StateT.mapHom φ) x, StateT.run_mapHom]

end stateNaturality

section idFold

variable {α : Type uB}

theorem liftMHom_lift_eq_id :
    FreeM.liftMHom (P := P) (m := FreeM P) FreeM.lift = MonadHom.id (FreeM P) :=
  MonadHom.ext' fun _ x => by simp

end idFold

end FreeM

end PFunctor
