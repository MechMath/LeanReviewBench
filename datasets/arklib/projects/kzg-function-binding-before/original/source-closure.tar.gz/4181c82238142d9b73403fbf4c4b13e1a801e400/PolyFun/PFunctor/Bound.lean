/-
Copyright (c) 2026 PolyFun Contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Devon Tuma
-/
module

public import PolyFun.PFunctor.Free.Basic

/-!
# Roll Bounds for the Free Monad of a Polynomial Functor

We define `PFunctor.FreeM.IsRollBound oa budget canRoll cost`, a generalized
predicate that bounds the number of `roll` constructors a term `oa : FreeM P α`
unfolds, parameterized by:
- `B` — the budget type
- `budget : B` — the initial budget
- `canRoll : P.A → B → Prop` — whether a `roll` at position `a` is allowed under
  budget `b`
- `cost : P.A → B → B` — how the budget is updated after a `roll` at `a`

The definition is structural via `FreeM.rec`: `pure` satisfies any bound,
and `liftBind a r` satisfies the bound when `canRoll a b` holds and each
continuation `r y` satisfies the bound at `cost a b`.

`OracleComp.IsQueryBound` (in `VCVio/OracleComp/QueryTracking/QueryBound.lean`)
is the specialization of this predicate to `FreeM (spec.toPFunctor)` and is
equal to `IsRollBound` definitionally; the bridge lemma in `QueryBound.lean`
witnesses the equivalence by `Iff.rfl`.

Bounds on one program combine into product and family budgets (`IsRollBound.prod`,
`IsRollBound.pi`). Bounds compose under `FreeM.bind` (`isRollBound_bind`, `isTotalRollBound_bind`)
and under the binds of the error-handling transformers `ExceptT ε (FreeM P)` and
`OptionT (FreeM P)`, whose early exits perform no roll (`isTotalRollBound_exceptT_bind`,
`isTotalRollBound_optionT_bind`).

`ProgramProgress` is the complementary liveness predicate: every reachable query
has at least one typed answer, so a roll bound stated by universal quantification
over answers is never satisfied vacuously.
-/

@[expose] public section

universe v w uA uB uA₂ uB₂

namespace PFunctor.FreeM

variable {P : PFunctor.{uA, uB}} {α β : Type v} {B : Type*}

/-- Generalized roll bound on `FreeM P` parameterized by a budget type `B`,
a validity check `canRoll`, and a cost function `cost`. `pure` satisfies any
bound; `roll a r` satisfies the bound when `canRoll a b` holds and every
continuation satisfies the bound at `cost a b`. -/
def IsRollBound (oa : FreeM P α) (budget : B)
    (canRoll : P.A → B → Prop) (cost : P.A → B → B) : Prop :=
  FreeM.rec (motive := fun _ => B → Prop)
    (fun _ _ => True)
    (fun a _r ih b => canRoll a b ∧ ∀ y, ih y (cost a b))
    oa budget

@[simp, grind .]
lemma isRollBound_pure (x : α) (b : B)
    (canRoll : P.A → B → Prop) (cost : P.A → B → B) :
    IsRollBound (pure x : FreeM P α) b canRoll cost := trivial

@[simp, grind =]
lemma isRollBound_lift_bind_iff (a : P.A) (r : P.B a → FreeM P α) (b : B)
    (canRoll : P.A → B → Prop) (cost : P.A → B → B) :
    IsRollBound ((FreeM.lift a).bind (α := no_index (P.B a)) r) b canRoll cost ↔
      canRoll a b ∧ ∀ y, IsRollBound (r y) (cost a b) canRoll cost :=
  Iff.rfl

/-- `isRollBound_lift_bind_iff` when results and directions share a universe. -/
@[simp, grind =]
lemma isRollBound_lift_bind_iff' {α : Type uB} (a : P.A) (r : P.B a → FreeM P α) (b : B)
    (canRoll : P.A → B → Prop) (cost : P.A → B → B) :
    IsRollBound (Bind.bind (α := no_index (P.B a)) (FreeM.lift a) r) b canRoll cost ↔
      canRoll a b ∧ ∀ y, IsRollBound (r y) (cost a b) canRoll cost :=
  Iff.rfl

lemma isRollBound_liftBind_iff (a : P.A) (r : P.B a → FreeM P α) (b : B)
    (canRoll : P.A → B → Prop) (cost : P.A → B → B) :
    IsRollBound (FreeM.liftBind a r) b canRoll cost ↔
      canRoll a b ∧ ∀ y, IsRollBound (r y) (cost a b) canRoll cost :=
  Iff.rfl

@[grind =]
lemma isRollBound_lift_iff (a : P.A) (b : B)
    (canRoll : P.A → B → Prop) (cost : P.A → B → B) :
    IsRollBound (FreeM.lift a : FreeM P (P.B a)) b canRoll cost ↔ canRoll a b :=
  ⟨fun h => h.1, fun h => ⟨h, fun _ => trivial⟩⟩

private lemma isRollBound_map_aux (oa : FreeM P α) {γ : Type w} (f : α → γ)
    (canRoll : P.A → B → Prop) (cost : P.A → B → B) :
    ∀ {b : B}, (FreeM.map f oa).IsRollBound b canRoll cost ↔
      oa.IsRollBound b canRoll cost := by
  induction oa with
  | pure x => intro b; exact ⟨fun _ => trivial, fun _ => trivial⟩
  | lift_bind a r ih =>
    intro b
    change (canRoll a b ∧ ∀ y, IsRollBound (FreeM.map f (r y)) (cost a b) canRoll cost) ↔
      (canRoll a b ∧ ∀ y, IsRollBound (r y) (cost a b) canRoll cost)
    exact and_congr_right fun _ => forall_congr' fun y => ih y

@[simp, grind =]
lemma isRollBound_map_iff (oa : FreeM P α) {γ : Type w} (f : α → γ) (b : B)
    (canRoll : P.A → B → Prop) (cost : P.A → B → B) :
    IsRollBound (FreeM.map f oa) b canRoll cost ↔ IsRollBound oa b canRoll cost :=
  isRollBound_map_aux oa f canRoll cost

/-- If `f <$> oa = ob` for any `f`, the roll-bound predicate transfers between
them. The standard shape arises when `oa` and `ob` are two views of the same
underlying computation that agree up to a projection. -/
lemma isRollBound_iff_of_map_eq
    {oa : FreeM P α} {ob : FreeM P β} {f : α → β} {b : B}
    (h : f <$> oa = ob)
    (canRoll : P.A → B → Prop) (cost : P.A → B → B) :
    IsRollBound oa b canRoll cost ↔ IsRollBound ob b canRoll cost := by
  rw [← h]; exact (isRollBound_map_iff oa f b canRoll cost).symm

private lemma isRollBound_congr_aux
    (oa : FreeM P α)
    (canRoll₁ canRoll₂ : P.A → B → Prop) (cost₁ cost₂ : P.A → B → B)
    (hcan : ∀ (a : P.A) (b : B), canRoll₁ a b ↔ canRoll₂ a b)
    (hcost : ∀ (a : P.A) (b : B), cost₁ a b = cost₂ a b) :
    ∀ {b : B}, oa.IsRollBound b canRoll₁ cost₁ ↔ oa.IsRollBound b canRoll₂ cost₂ := by
  induction oa using FreeM.induction <;> intro b <;> grind

lemma isRollBound_congr
    {oa : FreeM P α} {b : B}
    {canRoll₁ canRoll₂ : P.A → B → Prop} {cost₁ cost₂ : P.A → B → B}
    (hcan : ∀ (a : P.A) (b : B), canRoll₁ a b ↔ canRoll₂ a b)
    (hcost : ∀ (a : P.A) (b : B), cost₁ a b = cost₂ a b) :
    oa.IsRollBound b canRoll₁ cost₁ ↔ oa.IsRollBound b canRoll₂ cost₂ :=
  isRollBound_congr_aux oa canRoll₁ canRoll₂ cost₁ cost₂ hcan hcost

/-- Project an `IsRollBound` along a budget projection `proj : B → B'`.

If the source bound at budget `b` validates rolls at every step, the projected
bound at `proj b` is also validated, provided:
* `h_can`  — whenever a step is allowed in the source (`canRoll a b'`), it is
  allowed in the projection (`canRoll' a (proj b')`);
* `h_cost` — the projection commutes with the cost step on the allowed branch
  (`proj (cost a b') = cost' a (proj b')`). -/
lemma IsRollBound.proj
    {B' : Type*} (proj : B → B')
    {oa : FreeM P α} {b : B}
    {canRoll : P.A → B → Prop} {cost : P.A → B → B}
    {canRoll' : P.A → B' → Prop} {cost' : P.A → B' → B'}
    (h_can : ∀ (a : P.A) (b' : B), canRoll a b' → canRoll' a (proj b'))
    (h_cost : ∀ (a : P.A) (b' : B), canRoll a b' → proj (cost a b') = cost' a (proj b'))
    (h : IsRollBound oa b canRoll cost) :
    IsRollBound oa (proj b) canRoll' cost' := by
  induction oa using FreeM.induction generalizing b with
  | pure x => simp
  | lift_bind a r ih =>
      rw [isRollBound_lift_bind_iff] at h ⊢
      refine ⟨h_can a b h.1, fun y => ?_⟩
      have hy : IsRollBound (r y) (proj (cost a b)) canRoll' cost' :=
        ih y (h.2 y)
      rwa [h_cost a b h.1] at hy

/-- Enlarge a budget along any relation respected by validity and cost updates. -/
lemma IsRollBound.mono_of_rel (R : B → B → Prop) {oa : FreeM P α} {b b' : B}
    {canRoll : P.A → B → Prop} {cost : P.A → B → B}
    (h_can : ∀ a b b', R b b' → canRoll a b → canRoll a b')
    (h_cost : ∀ a b b', R b b' → canRoll a b → R (cost a b) (cost a b'))
    (h : IsRollBound oa b canRoll cost) (hb : R b b') :
    IsRollBound oa b' canRoll cost := by
  induction oa using FreeM.induction generalizing b b' with
  | pure _ => trivial
  | lift_bind a r ih =>
      exact ⟨h_can a b b' hb h.1, fun y => ih y (h.2 y) (h_cost a b b' hb h.1)⟩

/-- Two bounds on one program combine into a bound with a product budget: a roll is admitted
when both components admit it, and each component is charged by its own cost. -/
lemma IsRollBound.prod {B' : Type*} {oa : FreeM P α} {b : B} {b' : B'}
    {canRoll : P.A → B → Prop} {cost : P.A → B → B}
    {canRoll' : P.A → B' → Prop} {cost' : P.A → B' → B'}
    (h : IsRollBound oa b canRoll cost) (h' : IsRollBound oa b' canRoll' cost') :
    IsRollBound oa (b, b') (fun a p => canRoll a p.1 ∧ canRoll' a p.2)
      (fun a p => (cost a p.1, cost' a p.2)) := by
  induction oa using FreeM.induction generalizing b b' with
  | pure _ => trivial
  | lift_bind a r ih => exact ⟨⟨h.1, h'.1⟩, fun y => ih y (h.2 y) (h'.2 y)⟩

/-- A family of bounds on one program combines into a bound with a budget for each member: a
roll is admitted when every member admits it, and each budget is charged by its own cost. -/
lemma IsRollBound.pi {ι : Type*} {Bι : ι → Type*} {oa : FreeM P α} {b : ∀ i, Bι i}
    {canRoll : ∀ i, P.A → Bι i → Prop} {cost : ∀ i, P.A → Bι i → Bι i}
    (h : ∀ i, IsRollBound oa (b i) (canRoll i) (cost i)) :
    IsRollBound oa b (fun a p => ∀ i, canRoll i a (p i)) (fun a p i => cost i a (p i)) := by
  induction oa using FreeM.induction generalizing b with
  | pure _ => trivial
  | lift_bind a r ih => exact ⟨fun i => (h i).1, fun y => ih y fun i => (h i).2 y⟩

/-- Generic bind composition for `IsRollBound` parameterised by an arbitrary
budget type `B` and a binary `combine` operation on it.

The two side conditions are universally quantified so they survive recursion
under `generalizing b₁`:
* `h_can` — extending any validated budget on either side via `combine` keeps
  the roll valid;
* `h_cost` — `cost` distributes left and right over `combine` on validated
  budgets. -/
lemma isRollBound_bind {γ : Type w} {oa : FreeM P α} {ob : α → FreeM P γ}
    {canRoll : P.A → B → Prop} {cost : P.A → B → B}
    (combine : B → B → B) {b₁ b₂ : B}
    (h_can : ∀ a b₁' b₂' b, canRoll a b → canRoll a (combine b₁' b) ∧
      canRoll a (combine b b₂'))
    (h_cost : ∀ a b₁' b₂' b, canRoll a b →
      combine b₁' (cost a b) = cost a (combine b₁' b) ∧
      cost a (combine b b₂') = combine (cost a b) b₂')
    (h₁ : IsRollBound oa b₁ canRoll cost)
    (h₂ : ∀ x, IsRollBound (ob x) b₂ canRoll cost) :
    IsRollBound (FreeM.bind oa ob) (combine b₁ b₂) canRoll cost := by
  induction oa using FreeM.induction generalizing b₁ with
  | pure x =>
      change IsRollBound (ob x) (combine b₁ b₂) canRoll cost
      exact IsRollBound.proj (combine b₁)
        (fun a b hcan => (h_can a b₁ b₂ b hcan).1)
        (fun a b hcan => (h_cost a b₁ b₂ b hcan).1)
        (h₂ x)
  | lift_bind a r ih =>
      rw [isRollBound_lift_bind_iff] at h₁
      rw [FreeM.liftBind_bind, isRollBound_lift_bind_iff]
      refine ⟨(h_can a b₁ b₂ b₁ h₁.1).2, fun y => ?_⟩
      have hrec := ih y (h₁.2 y)
      rw [(h_cost a b₁ b₂ b₁ h₁.1).2]
      exact hrec

/-- Forward-direction `seq` analogue of `isRollBound_bind`. Reduces to the
bind case via `seq_eq_bind_map` plus `isRollBound_map_iff`. -/
lemma isRollBound_seq {og : FreeM P (α → β)} {oa : FreeM P α}
    {canRoll : P.A → B → Prop} {cost : P.A → B → B}
    (combine : B → B → B) {b₁ b₂ : B}
    (h_can : ∀ a b₁' b₂' b, canRoll a b → canRoll a (combine b₁' b) ∧
      canRoll a (combine b b₂'))
    (h_cost : ∀ a b₁' b₂' b, canRoll a b →
      combine b₁' (cost a b) = cost a (combine b₁' b) ∧
      cost a (combine b b₂') = combine (cost a b) b₂')
    (h₁ : IsRollBound og b₁ canRoll cost)
    (h₂ : IsRollBound oa b₂ canRoll cost) :
    IsRollBound (og <*> oa) (combine b₁ b₂) canRoll cost := by
  rw [seq_eq_bind_map]
  exact isRollBound_bind combine h_can h_cost h₁
    (fun g => (isRollBound_map_iff oa g b₂ canRoll cost).mpr h₂)

/-! ### Total roll bounds -/

/-- A total roll bound: `oa` encounters at most `n` `FreeM.liftBind` constructors
along every branch. Each roll consumes one unit of a natural-number budget,
independently of its position. -/
def IsTotalRollBound (oa : FreeM P α) (n : ℕ) : Prop :=
  IsRollBound oa n (fun _ b => 0 < b) (fun _ b => b - 1)

/-- The total-bound specialization exposes the underlying generalized
`IsRollBound` definitionally. -/
theorem isTotalRollBound_iff_isRollBound (oa : FreeM P α) (n : ℕ) :
    IsTotalRollBound oa n ↔
      IsRollBound oa n (fun _ b => 0 < b) (fun _ b => b - 1) :=
  Iff.rfl

@[simp, grind .]
lemma isTotalRollBound_pure (x : α) (n : ℕ) :
    IsTotalRollBound (pure x : FreeM P α) n := trivial

@[simp, grind =]
lemma isTotalRollBound_lift_bind_iff (a : P.A) (r : P.B a → FreeM P α) (n : ℕ) :
    IsTotalRollBound ((FreeM.lift a).bind (α := no_index (P.B a)) r) n ↔
      0 < n ∧ ∀ y, IsTotalRollBound (r y) (n - 1) :=
  Iff.rfl

/-- `isTotalRollBound_lift_bind_iff` when results and directions share a universe. -/
@[simp, grind =]
lemma isTotalRollBound_lift_bind_iff' {α : Type uB} (a : P.A) (r : P.B a → FreeM P α) (n : ℕ) :
    IsTotalRollBound (Bind.bind (α := no_index (P.B a)) (FreeM.lift a) r) n ↔
      0 < n ∧ ∀ y, IsTotalRollBound (r y) (n - 1) :=
  Iff.rfl

lemma isTotalRollBound_liftBind_iff (a : P.A) (r : P.B a → FreeM P α) (n : ℕ) :
    IsTotalRollBound (FreeM.liftBind a r) n ↔
      0 < n ∧ ∀ y, IsTotalRollBound (r y) (n - 1) :=
  Iff.rfl

/-- A total roll bound remains valid when its budget is increased. -/
lemma IsTotalRollBound.mono {oa : FreeM P α} {n₁ n₂ : ℕ}
    (h : IsTotalRollBound oa n₁) (hle : n₁ ≤ n₂) :
    IsTotalRollBound oa n₂ := by
  induction oa using FreeM.induction generalizing n₁ n₂ with
  | pure _ => simp
  | lift_bind a r ih =>
      rw [isTotalRollBound_lift_bind_iff] at h ⊢
      exact ⟨Nat.lt_of_lt_of_le h.1 hle,
        fun y => ih y (h.2 y) (Nat.sub_le_sub_right hle 1)⟩

/-- Total roll bounds add under monadic sequencing. This uses the named
`FreeM.bind`, whose result may live in an independent universe; in the
homogeneous specialization it is definitionally the typeclass bind. -/
lemma isTotalRollBound_bind {γ : Type w} {oa : FreeM P α}
    {ob : α → FreeM P γ} {n₁ n₂ : ℕ} (h₁ : IsTotalRollBound oa n₁)
    (h₂ : ∀ x, IsTotalRollBound (ob x) n₂) :
    IsTotalRollBound (FreeM.bind oa ob) (n₁ + n₂) := by
  refine isRollBound_bind (fun a b => a + b) ?_ ?_ h₁ h₂ <;> grind

/-- Total roll bounds add under applicative sequencing. -/
lemma isTotalRollBound_seq {og : FreeM P (α → β)} {oa : FreeM P α}
    {n₁ n₂ : ℕ} (h₁ : IsTotalRollBound og n₁)
    (h₂ : IsTotalRollBound oa n₂) :
    IsTotalRollBound (og <*> oa) (n₁ + n₂) := by
  refine isRollBound_seq (fun a b => a + b) ?_ ?_ h₁ h₂ <;> grind

/-- Interface transport along a lens preserves total roll bounds. A lens relabels
positions and reindexes directions, leaving the branching structure — and hence the
number of rolls along each branch — untouched. -/
lemma isTotalRollBound_mapLens {Q : PFunctor.{uA₂, uB₂}} (l : Lens P Q)
    (oa : FreeM P α) {n : ℕ} (h : oa.IsTotalRollBound n) :
    (oa.mapLens l).IsTotalRollBound n := by
  induction oa generalizing n with
  | pure x => simp
  | lift_bind a cont ih =>
      rw [isTotalRollBound_lift_bind_iff] at h
      change IsTotalRollBound (FreeM.liftBind (l.toFunA a)
        (fun d => (cont (l.toFunB a d)).mapLens l)) n
      rw [FreeM.liftBind_eq, isTotalRollBound_lift_bind_iff]
      exact ⟨h.1, fun d => ih _ (h.2 _)⟩

/-! ### Error-handling transformers

A computation in `ExceptT ε (FreeM P)` or `OptionT (FreeM P)` is the free program `x.run` with
an early exit. The exit is a `pure` leaf and performs no roll, so roll bounds compose under the
transformer's bind exactly as under `FreeM.bind`: a bound for the first computation, combined
with a uniform bound for every continuation. -/

section Transformers

variable {ε : Type v}

/-- Roll bounds compose through an `ExceptT` bind, under the side conditions of
`isRollBound_bind`. An error exits with no further rolls. -/
lemma isRollBound_exceptT_bind {x : ExceptT ε (FreeM P) α} {f : α → ExceptT ε (FreeM P) β}
    {canRoll : P.A → B → Prop} {cost : P.A → B → B}
    (combine : B → B → B) {b₁ b₂ : B}
    (h_can : ∀ a b₁' b₂' b, canRoll a b → canRoll a (combine b₁' b) ∧
      canRoll a (combine b b₂'))
    (h_cost : ∀ a b₁' b₂' b, canRoll a b →
      combine b₁' (cost a b) = cost a (combine b₁' b) ∧
      cost a (combine b b₂') = combine (cost a b) b₂')
    (hx : x.run.IsRollBound b₁ canRoll cost)
    (hf : ∀ value, (f value).run.IsRollBound b₂ canRoll cost) :
    (x >>= f).run.IsRollBound (combine b₁ b₂) canRoll cost := by
  rw [ExceptT.run_bind]
  refine isRollBound_bind combine h_can h_cost hx fun result => ?_
  cases result with
  | error _ => exact isRollBound_pure _ _ _ _
  | ok value => exact hf value

/-- Roll bounds compose through an `OptionT` bind, under the side conditions of
`isRollBound_bind`. A failure exits with no further rolls. -/
lemma isRollBound_optionT_bind {x : OptionT (FreeM P) α} {f : α → OptionT (FreeM P) β}
    {canRoll : P.A → B → Prop} {cost : P.A → B → B}
    (combine : B → B → B) {b₁ b₂ : B}
    (h_can : ∀ a b₁' b₂' b, canRoll a b → canRoll a (combine b₁' b) ∧
      canRoll a (combine b b₂'))
    (h_cost : ∀ a b₁' b₂' b, canRoll a b →
      combine b₁' (cost a b) = cost a (combine b₁' b) ∧
      cost a (combine b b₂') = combine (cost a b) b₂')
    (hx : x.run.IsRollBound b₁ canRoll cost)
    (hf : ∀ value, (f value).run.IsRollBound b₂ canRoll cost) :
    (x >>= f).run.IsRollBound (combine b₁ b₂) canRoll cost := by
  change IsRollBound (FreeM.bind x.run fun result => match result with
    | some value => (f value).run
    | none => pure none) (combine b₁ b₂) canRoll cost
  refine isRollBound_bind combine h_can h_cost hx fun result => ?_
  cases result with
  | none => exact isRollBound_pure _ _ _ _
  | some value => exact hf value

/-- Total roll bounds add under an `ExceptT` bind: an error exits with no further rolls. -/
lemma isTotalRollBound_exceptT_bind {x : ExceptT ε (FreeM P) α}
    {f : α → ExceptT ε (FreeM P) β} {n₁ n₂ : ℕ} (hx : x.run.IsTotalRollBound n₁)
    (hf : ∀ value, (f value).run.IsTotalRollBound n₂) :
    (x >>= f).run.IsTotalRollBound (n₁ + n₂) := by
  refine isRollBound_exceptT_bind (fun a b => a + b) ?_ ?_ hx hf <;> grind

/-- Total roll bounds add under an `OptionT` bind: a failure exits with no further rolls. -/
lemma isTotalRollBound_optionT_bind {x : OptionT (FreeM P) α}
    {f : α → OptionT (FreeM P) β} {n₁ n₂ : ℕ} (hx : x.run.IsTotalRollBound n₁)
    (hf : ∀ value, (f value).run.IsTotalRollBound n₂) :
    (x >>= f).run.IsTotalRollBound (n₁ + n₂) := by
  refine isRollBound_optionT_bind (fun a b => a + b) ?_ ?_ hx hf <;> grind

/-- Returning a value in `ExceptT` performs no roll. -/
lemma isTotalRollBound_exceptT_pure (value : α) (n : ℕ) :
    (pure value : ExceptT ε (FreeM P) α).run.IsTotalRollBound n := trivial

/-- Throwing an error in `ExceptT` performs no roll. -/
lemma isTotalRollBound_exceptT_throw (error : ε) (n : ℕ) :
    (throw error : ExceptT ε (FreeM P) α).run.IsTotalRollBound n := trivial

/-- Lifting a free program into `ExceptT` keeps exactly its rolls. -/
lemma isTotalRollBound_exceptT_lift_iff (x : FreeM P α) (n : ℕ) :
    (ExceptT.lift x : ExceptT ε (FreeM P) α).run.IsTotalRollBound n ↔ x.IsTotalRollBound n :=
  isRollBound_map_iff x Except.ok n _ _

/-- Returning a value in `OptionT` performs no roll. -/
lemma isTotalRollBound_optionT_pure (value : α) (n : ℕ) :
    (pure value : OptionT (FreeM P) α).run.IsTotalRollBound n := trivial

/-- Failing in `OptionT` performs no roll. -/
lemma isTotalRollBound_optionT_failure (n : ℕ) :
    (failure : OptionT (FreeM P) α).run.IsTotalRollBound n := trivial

/-- Lifting a free program into `OptionT` keeps exactly its rolls. -/
lemma isTotalRollBound_optionT_lift_iff (x : FreeM P α) (n : ℕ) :
    (OptionT.lift x : OptionT (FreeM P) α).run.IsTotalRollBound n ↔ x.IsTotalRollBound n := by
  rw [OptionT.run_lift, LawfulMonad.bind_pure_comp]
  exact isRollBound_map_iff x some n _ _

end Transformers

/-! ### Program progress -/

/-- Every query in a finite free program has at least one typed answer, and the
same holds recursively on every answer branch. This is separate from a
branchwise roll bound: universal branch obligations such as `IsTotalRollBound`
are vacuous at a query whose answer type is empty. -/
def ProgramProgress : FreeM P α → Prop
  | .pure _ => True
  | .liftBind a r => Nonempty (P.B a) ∧ ∀ y, ProgramProgress (r y)

@[simp, grind .]
lemma programProgress_pure (x : α) : ProgramProgress (pure x : FreeM P α) :=
  trivial

@[simp, grind =]
lemma programProgress_lift_bind_iff (a : P.A) (r : P.B a → FreeM P α) :
    ProgramProgress ((FreeM.lift a).bind (α := no_index (P.B a)) r) ↔
      Nonempty (P.B a) ∧ ∀ y, ProgramProgress (r y) :=
  Iff.rfl

lemma programProgress_liftBind_iff (a : P.A) (r : P.B a → FreeM P α) :
    ProgramProgress (FreeM.liftBind a r) ↔ Nonempty (P.B a) ∧ ∀ y, ProgramProgress (r y) :=
  Iff.rfl

/-- Mapping returned values preserves the reachable query tree and hence
program progress. -/
lemma ProgramProgress.map {oa : FreeM P α} (h : oa.ProgramProgress) (f : α → β) :
    (FreeM.map f oa).ProgramProgress := by
  induction oa with
  | pure x => trivial
  | lift_bind a r ih => exact ⟨h.1, fun y ↦ ih y (h.2 y)⟩

end PFunctor.FreeM
