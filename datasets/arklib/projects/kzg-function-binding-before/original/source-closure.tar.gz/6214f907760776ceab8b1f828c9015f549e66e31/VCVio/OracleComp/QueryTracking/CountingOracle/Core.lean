/-
Copyright (c) 2024 Devon Tuma. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Devon Tuma, Quang Dao
-/

module
public import VCVio.OracleComp.QueryTracking.Structures
public import VCVio.OracleComp.QueryTracking.Tracing.Core

/-!
# Query counting and cost instrumentation

Response-independent writer traces accumulate per-query costs and per-index query counts.
Their output projections and operational support equations preserve the original program.
Counting uses an additive writer backed by `Multiplicative (QueryCount ι)`; an abort in the
underlying monad can discard the whole writer result.
-/

public section

open OracleSpec OracleComp

universe u v w

open scoped OracleSpec.PrimitiveQuery

variable {ι : Type u} {spec : OracleSpec ι} {α β γ : Type u}

namespace QueryImpl

variable {m : Type u → Type v} [Monad m]

section withCost

variable {ω : Type u} [Monoid ω]

/-- Wrap an oracle implementation to accumulate cost in a `WriterT ω` layer.
The cost function `costFn` assigns a cost value to each oracle query.
Cost is accumulated *before* the implementation runs, so failed queries are still costed.

This is the response-independent specialisation of `QueryImpl.withTraceBefore`:
the trace value depends only on the query, not on the response.

**Side-channel trace instrumentation.**
`withCost` doubles as automatic side-channel instrumentation: given any
`OracleComp spec α` and a cost function `costFn : spec.Domain → ω`,
`(simulateQ (base.withCost costFn) oa).run` produces `m (α × ω)` without
modifying the computation's source code. The cost function encodes the
observation model:

* `fun _ => ()` (constant-time): every query looks identical to the observer.
* `fun t => queryLabel t` (typed): the observer sees which oracle was queried
  but not the arguments or results.

This is the preferred approach when the observation model is "every oracle
query is visible." For observations at non-query points (e.g. pure-computation
timing), use the explicit `observe` / `runObs` API from `ObservationOracle`. -/
@[expose] def withCost (so : QueryImpl spec m) (costFn : spec.Domain → ω) :
    QueryImpl spec (WriterT ω m) :=
  so.withTraceBefore costFn

lemma withCost_eq_withTraceBefore (so : QueryImpl spec m) (costFn : spec.Domain → ω) :
    so.withCost costFn = so.withTraceBefore costFn := rfl

@[simp, grind =]
lemma withCost_apply (so : QueryImpl spec m) (costFn : spec.Domain → ω)
    (t : spec.Domain) :
    so.withCost costFn t = (do tell (costFn t); so t) := by
  exact withTraceBefore_apply so costFn t

lemma fst_map_run_withCost [LawfulMonad m]
    (so : QueryImpl spec m) (costFn : spec.Domain → ω) (mx : OracleComp spec α) :
    Prod.fst <$> (simulateQ (so.withCost costFn) mx).run = simulateQ so mx :=
  fst_map_run_withTraceBefore so costFn mx

/-- When every query costs the monoid identity `1`, the trace is always `1`,
so `withCost` is a no-op up to pairing with `1`. -/
@[simp]
lemma run_simulateQ_withCost_const_one [LawfulMonad m]
    (so : QueryImpl spec m) (mx : OracleComp spec α) :
    (simulateQ (so.withCost (fun _ => (1 : ω))) mx).run =
      (·, 1) <$> simulateQ so mx :=
  run_simulateQ_withTraceBefore_const_one so mx

/-! ### EvalDist Bridge for `withCost`

These lemmas connect the result-marginal distribution of a `withCost`-instrumented
computation to the distribution of the uninstrumented computation, enabling direct
probability-level reasoning about traced computations. -/
lemma support_fst_run_withCost [LawfulMonad m] [MonadAttach m]
    (so : QueryImpl spec m) (costFn : spec.Domain → ω) (mx : OracleComp spec α) :
    support (Prod.fst <$> (simulateQ (so.withCost costFn) mx).run) =
      support (simulateQ so mx) :=
  support_fst_run_withTraceBefore so costFn mx

end withCost

/-- Wrap an oracle implementation to count queries in an additive writer.
Counting happens before the implementation runs; failure in the base monad can discard
the writer result. Use `AddWriterT.runAdd` to observe ordinary pointwise counts.
The underlying `withCost` uses `Multiplicative.ofAdd ∘ QueryCount.single`. -/
@[expose] def withCounting [DecidableEq ι] (so : QueryImpl spec m) :
    QueryImpl spec (AddWriterT (QueryCount ι) m) :=
  so.withCost (fun t => Multiplicative.ofAdd (QueryCount.single t))

@[simp, grind =]
lemma withCounting_apply [DecidableEq ι] (so : QueryImpl spec m) (t : spec.Domain) :
    so.withCounting t = (do AddWriterT.addTell (QueryCount.single t); so t) := by
  exact withCost_apply so (fun t => Multiplicative.ofAdd (QueryCount.single t)) t

lemma withCounting_eq_withCost [DecidableEq ι] (so : QueryImpl spec m) :
    so.withCounting = so.withCost (fun t => Multiplicative.ofAdd (QueryCount.single t)) := rfl

lemma fst_map_run_withCounting [DecidableEq ι] [LawfulMonad m]
    (so : QueryImpl spec m) (mx : OracleComp spec α) :
    Prod.fst <$> (simulateQ (so.withCounting) mx).run = simulateQ so mx :=
  fst_map_run_withCost so _ mx

/-- Forgetting the additive query count preserves the underlying computation. -/
lemma fst_map_runAdd_withCounting [DecidableEq ι] [LawfulMonad m]
    (so : QueryImpl spec m) (mx : OracleComp spec α) :
    Prod.fst <$> (simulateQ so.withCounting mx).runAdd = simulateQ so mx := by
  rw [AddWriterT.fst_map_runAdd, fst_map_run_withCounting]

end QueryImpl

/-- Oracle with arbitrary cost tracking. The cost is accumulated in a `WriterT ω` layer
while preserving the original oracle behavior. -/
@[expose] def costOracle {ω : Type u} [Monoid ω] (costFn : spec.Domain → ω) :
    QueryImpl spec (WriterT ω (OracleComp spec)) :=
  (QueryImpl.ofLift spec (OracleComp spec)).withCost costFn

/-- Oracle for counting the number of queries made by a computation. The count is stored as a
function from oracle indices to counts, to give finer grained information about the count. -/
@[expose] def OracleSpec.countingOracle [DecidableEq ι] :
    QueryImpl spec (AddWriterT (QueryCount ι) (OracleComp spec)) :=
  (QueryImpl.ofLift spec (OracleComp spec)).withCounting

/-- Pointwise behavior of the generic cost oracle. -/
@[simp]
lemma costOracle_apply {ω : Type u} [Monoid ω] (costFn : spec.Domain → ω)
    (t : spec.Domain) :
    costOracle costFn t =
      (do tell (costFn t); liftM (liftM (spec.query t) : OracleComp spec _)) := by
  rw [costOracle, QueryImpl.withCost_apply, QueryImpl.ofLift_apply]

/-- Pointwise behavior of the per-index counting oracle. -/
@[simp]
lemma OracleSpec.countingOracle_apply [DecidableEq ι] (t : spec.Domain) :
    spec.countingOracle t =
      (do
        AddWriterT.addTell (QueryCount.single t)
        liftM (liftM (spec.query t) : OracleComp spec _)) := by
  rw [OracleSpec.countingOracle, QueryImpl.withCounting_apply, QueryImpl.ofLift_apply]

lemma countingOracle_eq_costOracle [DecidableEq ι] :
    spec.countingOracle = costOracle (fun t => Multiplicative.ofAdd (QueryCount.single t)) := rfl

namespace costOracle

variable {ω : Type u} [Monoid ω]

@[simp]
lemma fst_map_run_simulateQ (costFn : spec.Domain → ω) (oa : OracleComp spec α) :
    Prod.fst <$> (simulateQ (costOracle costFn) oa).run = oa := by
  rw [costOracle, QueryImpl.fst_map_run_withCost, simulateQ_ofLift_eq_self]
lemma support_run_simulateQ
    (costFn : spec.Domain → ω) (oa : OracleComp spec α) :
    support (Prod.fst <$> (simulateQ (costOracle costFn) oa).run) = support oa := by
  rw [fst_map_run_simulateQ]

end costOracle

namespace countingOracle

variable [DecidableEq ι]

@[simp]
lemma fst_map_run_simulateQ (oa : OracleComp spec α) :
    Prod.fst <$> (simulateQ countingOracle oa).run = oa := by
  rw [countingOracle, QueryImpl.fst_map_run_withCounting, simulateQ_ofLift_eq_self]

@[simp]
lemma run_simulateQ_bind_fst (oa : OracleComp spec α) (ob : α → OracleComp spec β) :
    ((simulateQ countingOracle oa).run >>= fun x => ob x.1) = oa >>= ob := by
  rw [← bind_map_left Prod.fst, fst_map_run_simulateQ]

lemma support_fst_map_run_simulateQ {ι₀ : Type} {spec₀ : OracleSpec.{0, 0} ι₀} [DecidableEq ι₀]
    {α : Type} (oa : OracleComp spec₀ α) :
    support (Prod.fst <$> (simulateQ (spec₀.countingOracle) oa).run) = support oa := by
  rw [fst_map_run_simulateQ]

section support

/-- Run the counting interpretation with initial accumulated count `qc`. -/
@[expose] def simulate (oa : OracleComp spec α) (qc : QueryCount ι) :
    OracleComp spec (α × QueryCount ι) :=
  Prod.map id (qc + ·) <$> (simulateQ countingOracle oa).runAdd

lemma simulate_eq_map_simulate_zero (oa : OracleComp spec α) (qc : QueryCount ι) :
    simulate oa qc = Prod.map id (qc + ·) <$> simulate oa 0 := by
  simp only [simulate, Functor.map_map]
  congr 1
  funext ⟨x, q⟩
  simp

/-- We can always reduce simulation with counting to start with `0`,
and add the initial count back at the end. -/
lemma support_simulate (oa : OracleComp spec α) (qc : QueryCount ι) :
    support (simulate oa qc) = Prod.map id (qc + ·) '' support (simulate oa 0) := by
  rw [simulate_eq_map_simulate_zero]
  simp

/-- Reduce membership in support of simulation with counting to simulation starting from `0`. -/
lemma mem_support_simulate_iff (oa : OracleComp spec α) (qc : QueryCount ι)
    (z : α × QueryCount ι) :
    z ∈ support (simulate oa qc) ↔
      ∃ qc', (z.1, qc') ∈ support (simulate oa 0) ∧ qc + qc' = z.2 := by
  rw [support_simulate]
  aesop

lemma mem_support_simulate_iff_of_le (oa : OracleComp spec α) (qc : QueryCount ι)
    (z : α × QueryCount ι) (hz : qc ≤ z.2) :
    z ∈ support (simulate oa qc) ↔ (z.1, z.2 - qc) ∈ support (simulate oa 0) := by
  rw [mem_support_simulate_iff oa qc z]
  refine ⟨?_, ?_⟩
  · rintro ⟨qc', hmem, hq⟩
    convert hmem using 2
    funext i
    have hqi : qc i + qc' i = z.2 i := congrFun hq i
    simpa [Pi.sub_apply, hqi] using (Nat.add_sub_cancel_left (qc i) (qc' i))
  · refine fun hmem => ⟨z.2 - qc, hmem, ?_⟩
    funext i
    simp [Pi.add_apply, Pi.sub_apply, Nat.add_sub_of_le (hz i)]

lemma le_of_mem_support_simulate {oa : OracleComp spec α} {qc : QueryCount ι}
    {z : α × QueryCount ι} (h : z ∈ support (simulate oa qc)) : qc ≤ z.2 := by
  obtain ⟨qc', _, hq⟩ := (mem_support_simulate_iff oa qc z).1 h
  exact fun i => le_of_le_of_eq (Nat.le_add_right _ _) (congrFun hq i)

section snd_map

lemma mem_support_snd_map_simulate_iff (oa : OracleComp spec α)
    (qc qc' : QueryCount ι) :
    qc' ∈ support (((fun z : α × QueryCount ι => z.2) <$> simulate oa qc) :
      OracleComp spec (QueryCount ι)) ↔
      ∃ qc'', ∃ x, (x, qc'') ∈ support (simulate oa 0) ∧ qc + qc'' = qc' := by
  simp only [support_map, Set.mem_image, Prod.exists, exists_eq_right]
  refine ⟨fun ⟨x, hx⟩ => ?_, fun ⟨qc'', x, hmem, hq⟩ => ?_⟩
  · obtain ⟨qc'', hmem, hq⟩ := (mem_support_simulate_iff oa qc (x, qc')).1 hx
    exact ⟨qc'', x, hmem, hq⟩
  · exact ⟨x, (mem_support_simulate_iff oa qc (x, qc')).2 ⟨qc'', hmem, hq⟩⟩

lemma mem_support_snd_map_simulate_iff_of_le (oa : OracleComp spec α)
    {qc qc' : QueryCount ι} (hqc : qc ≤ qc') :
    qc' ∈ support (((fun z : α × QueryCount ι => z.2) <$> simulate oa qc) :
      OracleComp spec (QueryCount ι)) ↔
      qc' - qc ∈ support (((fun z : α × QueryCount ι => z.2) <$> simulate oa 0) :
        OracleComp spec (QueryCount ι)) := by
  rw [mem_support_snd_map_simulate_iff]
  simp only [support_map, Set.mem_image, Prod.exists, exists_eq_right]
  refine ⟨fun ⟨qc'', x, hmem, hq⟩ => ⟨x, ?_⟩, fun ⟨x, hx⟩ => ⟨qc' - qc, x, hx, ?_⟩⟩
  · convert hmem using 2
    funext i
    simp [Pi.sub_apply, ← congrFun hq i]
  · funext i
    simp [Pi.add_apply, Pi.sub_apply, Nat.add_sub_of_le (hqc i)]

lemma le_of_mem_support_snd_map_simulate {oa : OracleComp spec α}
    {qc qc' : QueryCount ι}
    (h : qc' ∈ support (((fun z : α × QueryCount ι => z.2) <$> simulate oa qc) :
      OracleComp spec (QueryCount ι))) : qc ≤ qc' := by
  obtain ⟨qc'', _, _, hq⟩ := (mem_support_snd_map_simulate_iff oa qc qc').1 h
  exact fun i => le_of_le_of_eq (Nat.le_add_right _ _) (congrFun hq i)

lemma sub_mem_support_snd_map_simulate {oa : OracleComp spec α}
    {qc qc' : QueryCount ι}
    (h : qc' ∈ support (((fun z : α × QueryCount ι => z.2) <$> simulate oa qc) :
      OracleComp spec (QueryCount ι))) :
    qc' - qc ∈ support (((fun z : α × QueryCount ι => z.2) <$> simulate oa 0) :
      OracleComp spec (QueryCount ι)) :=
  (mem_support_snd_map_simulate_iff_of_le (oa := oa)
    (hqc := le_of_mem_support_snd_map_simulate h)).1 h

end snd_map

lemma add_mem_support_simulate {oa : OracleComp spec α} {qc : QueryCount ι}
    {z : α × QueryCount ι} (hz : z ∈ support (simulate oa qc)) (qc' : QueryCount ι) :
    (z.1, z.2 + qc') ∈ support (simulate oa (qc + qc')) := by
  rcases (mem_support_simulate_iff oa qc z).1 hz with ⟨qc1, hmem, hq⟩
  refine (mem_support_simulate_iff oa (qc + qc') (z.1, z.2 + qc')).2 ?_
  refine ⟨qc1, hmem, ?_⟩
  funext i
  have hi : qc i + qc1 i = z.2 i := by simpa [Pi.add_apply] using congrFun hq i
  simp only [Pi.add_apply]
  omega

lemma add_right_mem_support_simulate_iff (oa : OracleComp spec α)
    (qc qc' : QueryCount ι) (x : α) :
    (x, qc + qc') ∈ support (simulate oa qc) ↔ (x, qc') ∈ support (simulate oa 0) := by
  rw [mem_support_simulate_iff]
  aesop

lemma add_left_mem_support_simulate_iff (oa : OracleComp spec α)
    (qc qc' : QueryCount ι) (x : α) :
    (x, qc' + qc) ∈ support (simulate oa qc) ↔ (x, qc') ∈ support (simulate oa 0) := by
  rw [add_comm qc' qc]
  exact add_right_mem_support_simulate_iff oa qc qc' x

lemma mem_support_simulate_pure_iff (x : α) (qc : QueryCount ι)
    (z : α × QueryCount ι) :
    z ∈ support (simulate (pure x : OracleComp spec α) qc) ↔ z = (x, qc) := by
  simp [simulate]

lemma apply_ne_zero_of_mem_support_simulate_queryBind {t : spec.Domain}
    {oa : spec.Range t → OracleComp spec α} {qc : QueryCount ι} {z : α × QueryCount ι}
    (hz : z ∈ support (simulate ((query t : OracleComp spec _) >>= oa) qc)) :
    z.2 t ≠ 0 := by
  obtain ⟨q0, hq0mem, hqsum⟩ :=
    (mem_support_simulate_iff (oa := ((query t : OracleComp spec _) >>= oa)) qc z).1 hz
  obtain ⟨u, b, _hb, hq0⟩ := (by
    simpa [simulate, countingOracle, QueryImpl.withCounting_apply] using hq0mem)
  have hqt : qc t + q0 t = z.2 t := congrFun hqsum t
  have hq0t : q0 t = QueryCount.single t t + b t := by
    simpa [Pi.add_apply] using (congrFun hq0 t).symm
  simp only [QueryCount.single, Pi.single_eq_same] at hq0t
  omega

lemma exists_mem_support_of_mem_support_simulate_queryBind {t : spec.Domain}
    {oa : spec.Range t → OracleComp spec α} {qc : QueryCount ι} {z : α × QueryCount ι}
    (hz : z ∈ support (simulate ((query t : OracleComp spec _) >>= oa) qc)) :
    ∃ u, (z.1, Function.update z.2 t (z.2 t - 1)) ∈ support (simulate (oa u) qc) := by
  obtain ⟨q0, hq0mem, hqsum⟩ :=
    (mem_support_simulate_iff (oa := ((query t : OracleComp spec _) >>= oa)) qc z).1 hz
  obtain ⟨u, b, hb, hq0⟩ := (by
    simpa [simulate, countingOracle, QueryImpl.withCounting_apply] using hq0mem)
  have hb0 : (z.1, b) ∈ support (simulate (oa u) 0) := by
    simpa [simulate, countingOracle] using hb
  refine ⟨u, (mem_support_simulate_iff (oa := oa u) qc
    (z := (z.1, Function.update z.2 t (z.2 t - 1)))).2 ⟨b, hb0, ?_⟩⟩
  funext j
  have hqj : qc j + q0 j = z.2 j := congrFun hqsum j
  have hq0j : q0 j = QueryCount.single t j + b j := by
    simpa [Pi.add_apply] using (congrFun hq0 j).symm
  rcases eq_or_ne j t with rfl | hj
  · simp only [Pi.add_apply, QueryCount.single, Pi.single_eq_same, Function.update_self]
      at hq0j ⊢
    omega
  · simp only [Pi.add_apply, QueryCount.single, Pi.single_eq_of_ne hj,
          Function.update_of_ne hj] at hq0j ⊢
    omega

lemma mem_support_simulate_queryBind_iff (t : spec.Domain)
    (oa : spec.Range t → OracleComp spec α) (qc : QueryCount ι) (z : α × QueryCount ι) :
    z ∈ support (simulate ((query t : OracleComp spec _) >>= oa) qc) ↔
      z.2 t ≠ 0 ∧
      ∃ u, (z.1, Function.update z.2 t (z.2 t - 1)) ∈ support (simulate (oa u) qc) := by
  refine ⟨?_, ?_⟩
  · intro hz
    exact ⟨apply_ne_zero_of_mem_support_simulate_queryBind hz,
      exists_mem_support_of_mem_support_simulate_queryBind hz⟩
  · rintro ⟨hz0, hu⟩
    rcases hu with ⟨u, hu⟩
    rcases (mem_support_simulate_iff (oa := oa u) qc
      (z := (z.1, Function.update z.2 t (z.2 t - 1)))).1 hu with ⟨b, hb0, hbEq⟩
    have hbRun : (z.1, b) ∈ support ((simulateQ countingOracle (oa u)).runAdd) := by
      simpa [simulate] using hb0
    have hbRun' : (z.1, b) ∈
        support ((simulateQ (QueryImpl.id' spec).withCounting (oa u)).runAdd) := by
      simpa [countingOracle] using hbRun
    let q0 : QueryCount ι := QueryCount.single t + b
    have hq0mem : (z.1, q0) ∈ support (simulate ((query t : OracleComp spec _) >>= oa) 0) := by
      have hex :
          ∃ i a b', (a, b') ∈ support (simulateQ (QueryImpl.id' spec).withCounting (oa i)).runAdd ∧
            (a, QueryCount.single t + b') = (z.1, q0) :=
        ⟨u, z.1, b, hbRun', by simp [q0]⟩
      simpa [simulate, countingOracle, QueryImpl.withCounting_apply] using hex
    have hqsum : qc + q0 = z.2 := by
      funext j
      have hbEqj : qc j + b j = (Function.update z.2 t (z.2 t - 1)) j := by
        simpa [Pi.add_apply] using congrFun hbEq j
      rcases eq_or_ne j t with rfl | hj
      · have hzpos : 0 < z.2 j := Nat.pos_of_ne_zero hz0
        simp only [q0, Pi.add_apply, QueryCount.single, Pi.single_eq_same, Function.update_self]
          at hbEqj ⊢
        omega
      · simp only [q0, Pi.add_apply, QueryCount.single, Pi.single_eq_of_ne hj,
          Function.update_of_ne hj] at hbEqj ⊢
        omega
    exact (mem_support_simulate_iff (oa := ((query t : OracleComp spec _) >>= oa))
      qc z).2 ⟨q0, hq0mem, hqsum⟩

lemma exists_mem_support_of_mem_support {oa : OracleComp spec α} {x : α} (hx : x ∈ support oa)
    (qc : QueryCount ι) : ∃ qc', (x, qc') ∈ support (simulate oa qc) := by
  have hx' : x ∈ support (Prod.fst <$> (simulateQ countingOracle oa).runAdd) := by
    simpa [fst_map_run_simulateQ] using hx
  rw [support_map] at hx'
  obtain ⟨z, hz, rfl⟩ := hx'
  refine ⟨qc + z.2, (mem_support_simulate_iff (oa := oa) qc (z := (z.1, qc + z.2))).2
    ⟨z.2, ?_, rfl⟩⟩
  rw [simulate, support_map]
  exact ⟨z, hz, by simp [Prod.map]⟩

end support

end countingOracle
