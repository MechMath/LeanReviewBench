/-
Copyright (c) 2026 Devon Tuma. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Devon Tuma
-/
module

public import PolyFun.PFunctor.Free.Basic
public import VCVio.EvalDist.Defs.Measure.Core
public import Mathlib.MeasureTheory.Measure.ProbabilityMeasure
public import Mathlib.MeasureTheory.Measure.Prod
public import Mathlib.Probability.UniformOn

/-!
# Measure semantics for polynomial free monads

This module interprets a polynomial free program directly as a Mathlib `Measure`. Each operation
is assigned a probability measure on its answer type, and `PFunctor.FreeM.denote` recursively
composes those measures with `Measure.bind` when the continuation is almost everywhere measurable.
An unmeasurable continuation denotes zero. This convention makes the fold subprobabilistic
without depending on Mathlib's arbitrary default for an unmeasurable pushforward.

`Measure α` becomes a type only after `α` receives a `MeasurableSpace`, so this interpretation is
an explicit fold rather than an unrestricted Lean monad morphism. The measurable-continuation
boundary remains visible in the general laws. Discrete answer types discharge the internal
measurability obligations while leaving the result space arbitrary.

## Main definitions

* `PFunctor.AnswerMeasure` assigns a probability measure to each operation.
* `PFunctor.AnswerMeasure.uniformOfFiniteNonempty` assigns the uniform measure to every finite,
  nonempty answer type.
* `PFunctor.FreeM.denote` is the measure denoted by a free program.

## Main statements

* `PFunctor.FreeM.denote_lift` identifies the denotation of one operation.
* `PFunctor.FreeM.denote_bind_of_discrete` and `PFunctor.FreeM.denote_map_of_discrete` give the
  discrete Giry composition laws.
* `PFunctor.FreeM.denote_bind_bind_prod_mk_eq_prod` identifies two independent executions with
  Mathlib's product measure.
-/

@[expose] public section

open MeasureTheory ProbabilityTheory

universe u v w uA

namespace PFunctor

/-- Per-operation answer measures for a polynomial interface.

The measurable structure on answer types is a separate parameter rather than a field, mirroring
Mathlib's separation of `MeasurableSpace` from the measures carried on it. Answer types need not
be discrete. -/
class AnswerMeasure (P : PFunctor.{uA, u}) [∀ a, MeasurableSpace (P.B a)] where
  /-- The distribution of answers to an operation. -/
  toMeasure : (a : P.A) → Measure (P.B a)
  /-- Answering an operation is lossless. -/
  isProbabilityMeasure : ∀ a, IsProbabilityMeasure (toMeasure a)

attribute [instance] AnswerMeasure.isProbabilityMeasure

/-- Construct uniform measure semantics from finite, nonempty answer types.

This is deliberately not an instance: measure semantics remain an explicit choice at each use
site, and are never inferred merely from finiteness. -/
@[reducible]
noncomputable def AnswerMeasure.uniformOfFiniteNonempty (P : PFunctor.{uA, u})
    [∀ a, Finite (P.B a)] [∀ a, Nonempty (P.B a)] [∀ a, MeasurableSpace (P.B a)] :
    P.AnswerMeasure where
  toMeasure _ := uniformOn Set.univ
  isProbabilityMeasure _ := inferInstance

namespace FreeM

variable {P : PFunctor.{uA, u}} [∀ a, MeasurableSpace (P.B a)] [P.AnswerMeasure]
  {α : Type v} {β : Type w}

open scoped Classical in
/-- The measure denoted by a polynomial free program. A measurable continuation uses Giry bind;
an unmeasurable continuation denotes zero. Probability-mass preservation requires measurability. -/
noncomputable def denote [MeasurableSpace α] : FreeM P α → Measure α
  | .pure x => Measure.dirac x
  | .liftBind a cont =>
      if AEMeasurable (fun b => denote (cont b)) (AnswerMeasure.toMeasure a) then
        Measure.bind (AnswerMeasure.toMeasure a) fun b => denote (cont b)
      else 0

@[simp]
theorem denote_pure [MeasurableSpace α] (x : α) :
    denote (pure x : FreeM P α) = Measure.dirac x := rfl

theorem denote_liftBind [MeasurableSpace α] (a : P.A) (cont : P.B a → FreeM P α)
    (h : AEMeasurable (fun b => denote (cont b)) (AnswerMeasure.toMeasure a)) :
    denote (FreeM.liftBind a cont)
      = Measure.bind (AnswerMeasure.toMeasure a) fun b => denote (cont b) := by
  simp [denote, h]

/-- An unmeasurable operation continuation has zero denotation. -/
theorem denote_liftBind_of_not_aemeasurable [MeasurableSpace α]
    (a : P.A) (cont : P.B a → FreeM P α)
    (h : ¬AEMeasurable (fun b => denote (cont b)) (AnswerMeasure.toMeasure a)) :
    denote (FreeM.liftBind a cont) = 0 := by
  simp [denote, h]

/-- A one-operation program denotes its configured answer measure. -/
@[simp]
theorem denote_lift (a : P.A) :
    denote (FreeM.lift a : FreeM P (P.B a)) = AnswerMeasure.toMeasure a := by
  rw [FreeM.lift, denote_liftBind a pure Measure.measurable_dirac.aemeasurable]
  exact Measure.bind_dirac

/-- A one-operation program is a probability measure whenever its continuation is an
almost-everywhere measurable family of probability measures.

This is the continuous composition boundary. For discrete answer types the hypotheses are
automatic; for a genuinely continuous oracle they are precisely the obligations represented by
a Mathlib `Kernel`. -/
theorem isProbabilityMeasure_denote_liftBind [MeasurableSpace α] (a : P.A)
    (cont : P.B a → FreeM P α)
    (hMeasurable : AEMeasurable (fun b => denote (cont b)) (AnswerMeasure.toMeasure a))
    (hProbability : ∀ᵐ b ∂AnswerMeasure.toMeasure a,
      IsProbabilityMeasure (denote (cont b))) :
    IsProbabilityMeasure (denote (FreeM.liftBind a cont)) := by
  rw [denote_liftBind a cont hMeasurable]
  exact MeasureTheory.isProbabilityMeasure_bind hMeasurable hProbability

/-! ## Giry composition laws -/

variable [∀ a, DiscreteMeasurableSpace (P.B a)]

/-- Every program over discrete answer types denotes a probability measure, independently of
the measurable space on its output. -/
@[instance]
theorem isProbabilityMeasure_denote [MeasurableSpace α] (program : FreeM P α) :
    IsProbabilityMeasure (denote program) := by
  induction program with
  | pure _ => exact ⟨by simp⟩
  | lift_bind a cont ih =>
      exact isProbabilityMeasure_denote_liftBind a cont
        Measurable.of_discrete.aemeasurable
        (Filter.Eventually.of_forall ih)

/-- `denote` preserves bind when the denoted continuation is measurable. Discrete answer types
discharge the recursive measurability obligation inside the free program. -/
theorem denote_bind [MeasurableSpace α] [MeasurableSpace β]
    (program : FreeM P α) (f : α → FreeM P β)
    (hf : Measurable fun x => denote (f x)) :
    denote (FreeM.bind program f) = Measure.bind (denote program) fun x => denote (f x) := by
  induction program with
  | pure x => simpa using (Measure.dirac_bind hf x).symm
  | lift_bind a cont ih =>
      change denote (FreeM.liftBind a (fun b => (cont b).bind f)) =
        Measure.bind (denote (FreeM.liftBind a cont)) (fun x => denote (f x))
      rw [denote_liftBind _ _ Measurable.of_discrete.aemeasurable,
        denote_liftBind _ _ Measurable.of_discrete.aemeasurable]
      rw [Measure.bind_bind (Measurable.of_discrete).aemeasurable hf.aemeasurable]
      exact Measure.bind_congr_right (Filter.Eventually.of_forall fun b => ih b)

/-- `denote` preserves bind unconditionally when the program's result type is discrete. -/
theorem denote_bind_of_discrete [MeasurableSpace α] [DiscreteMeasurableSpace α]
    [MeasurableSpace β] (program : FreeM P α) (f : α → FreeM P β) :
    denote (FreeM.bind program f) = Measure.bind (denote program) fun x => denote (f x) :=
  denote_bind program f Measurable.of_discrete

/-- `denote` turns a measurable map of program outputs into the pushforward measure. -/
theorem denote_map_of_measurable [MeasurableSpace α] [MeasurableSpace β]
    (program : FreeM P α) (f : α → β) (hf : Measurable f) :
    denote (FreeM.map f program) = (denote program).map f := by
  rw [← FreeM.bind_pure_comp f program, denote_bind program (pure ∘ f)]
  · simpa only [Function.comp_apply, denote_pure] using
      Measure.bind_dirac_eq_map (denote program) hf
  · change Measurable (Measure.dirac ∘ f)
    exact Measure.measurable_dirac.comp hf

/-- `denote` preserves every output map from a discrete result type. -/
theorem denote_map_of_discrete [MeasurableSpace α] [DiscreteMeasurableSpace α]
    [MeasurableSpace β] (program : FreeM P α) (f : α → β) :
    denote (FreeM.map f program) = (denote program).map f :=
  denote_map_of_measurable program f Measurable.of_discrete

/-- Sequentially running two programs whose second execution does not depend on the first result
denotes the product of their measures. -/
theorem denote_bind_bind_prod_mk_eq_prod [MeasurableSpace α] [DiscreteMeasurableSpace α]
    [MeasurableSpace β] (left : FreeM P α) (right : FreeM P β) :
    denote (FreeM.bind left fun x =>
      FreeM.bind right fun y => pure (x, y)) =
        (denote left).prod (denote right) := by
  rw [denote_bind_of_discrete left, Measure.prod_eq_of_sfinite]
  exact Measure.bind_congr_right (Filter.Eventually.of_forall fun x => by
    change denote (FreeM.bind right fun y => pure (x, y)) =
      Measure.map (Prod.mk x) (denote right)
    rw [denote_bind right (fun y => pure (x, y))]
    · simpa only [denote_pure] using
        Measure.bind_dirac_eq_map (denote right) (by fun_prop)
    · change Measurable (Measure.dirac ∘ Prod.mk x)
      exact Measure.measurable_dirac.comp (by fun_prop))

end FreeM

namespace FreeM

variable {P : PFunctor.{uA, u}} [∀ a, MeasurableSpace (P.B a)] [P.AnswerMeasure]
  {α : Type u}

/-- Every free program denotes a subprobability measure. Measurable continuations preserve the
mass bound through integration; unmeasurable continuations have zero denotation. -/
theorem denote_apply_univ_le_one [MeasurableSpace α] (program : FreeM P α) :
    denote program Set.univ ≤ 1 := by
  induction program with
  | pure _ => simp
  | lift_bind a cont ih =>
      change denote (FreeM.liftBind a cont) Set.univ ≤ 1
      by_cases h : AEMeasurable (fun b => denote (cont b)) (AnswerMeasure.toMeasure a)
      · rw [denote_liftBind a cont h, Measure.bind_apply MeasurableSet.univ h]
        calc
          (∫⁻ b, denote (cont b) Set.univ ∂AnswerMeasure.toMeasure a) ≤
              ∫⁻ _b, 1 ∂AnswerMeasure.toMeasure a := lintegral_mono ih
          _ = 1 := by simp
      · simp only [denote_liftBind_of_not_aemeasurable a cont h, Measure.coe_zero,
          Pi.zero_apply, zero_le]

/-- The direct free-monad fold supplies measure semantics for a measure-valued specification. -/
noncomputable instance (priority := 20) instEvalDistSemanticsFreeM :
    EvalDistSemantics (FreeM P) where
  denote := denote
  apply_univ_le_one := denote_apply_univ_le_one

/-- The direct free-monad measure fold preserves pure without any discreteness assumption on
oracle answers. -/
noncomputable instance (priority := 20) instLawfulPureEvalDistSemanticsFreeM :
    LawfulPureEvalDistSemantics (FreeM P) where
  denote_pure := denote_pure

/-- With a measure specification in scope, `𝒟[…]` is definitionally the direct free-monad
measure fold. `𝒟[…]` is the public head: this is a transport lemma, not a simp rule, so the
`𝒟`-keyed laws below and in `Defs.Measure` are the ones `simp` uses. -/
theorem evalDist_eq_denote [MeasurableSpace α] (program : FreeM P α) :
    𝒟[program] = denote program := rfl

/-- A one-operation program denotes its configured answer measure. -/
@[simp]
theorem evalDist_lift (a : P.A) :
    𝒟[(FreeM.lift a : FreeM P (P.B a))] = AnswerMeasure.toMeasure a :=
  denote_lift a

/-- A one-operation program observed in a coarser measurable structure on its answers denotes the
configured answer measure trimmed to that structure. -/
theorem evalDist_lift_of_le (a : P.A) {m : MeasurableSpace (P.B a)}
    (hm : m ≤ ‹∀ a, MeasurableSpace (P.B a)› a) :
    @evalDist (FreeM P) _ (P.B a) m (FreeM.lift a) = (AnswerMeasure.toMeasure a).trim hm := by
  have hid : Measurable[‹∀ a, MeasurableSpace (P.B a)› a, m] (id : P.B a → P.B a) :=
    fun _ hs => hm _ hs
  have hdirac : Measurable[‹∀ a, MeasurableSpace (P.B a)› a]
      (fun b => @Measure.dirac (P.B a) m b) :=
    (@Measure.measurable_dirac _ m).comp hid
  have hcont : AEMeasurable (fun b => @denote P _ _ (P.B a) m (pure b))
      (AnswerMeasure.toMeasure a) := by
    simp only [denote_pure]
    exact hdirac.aemeasurable
  change @denote P _ _ (P.B a) m (FreeM.liftBind a pure) = _
  rw [@denote_liftBind P _ _ (P.B a) m a pure hcont]
  simp only [denote_pure]
  ext s hs
  rw [Measure.bind_apply hs hdirac.aemeasurable, trim_measurableSet_eq hm hs]
  simp only [Measure.dirac_apply' _ hs]
  exact lintegral_indicator_one (hm _ hs)

/-- A single operation denotes a probability measure, including for continuous answer spaces. -/
theorem isProbabilityMeasure_evalDist_lift (a : P.A) :
    IsProbabilityMeasure 𝒟[(FreeM.lift a : FreeM P (P.B a))] := by
  rw [evalDist_lift]
  infer_instance

/-- An operation with an almost everywhere measurable continuation denotes Giry bind. -/
theorem evalDist_liftBind [MeasurableSpace α] (a : P.A) (cont : P.B a → FreeM P α)
    (h : AEMeasurable (fun b => denote (cont b)) (AnswerMeasure.toMeasure a)) :
    𝒟[FreeM.liftBind a cont] = Measure.bind (AnswerMeasure.toMeasure a) fun b => 𝒟[cont b] :=
  denote_liftBind a cont h

/-- Integrating a single operation uses the tower law under AE-measurable continuation and
valuation hypotheses, including for continuous query answers. -/
theorem lintegral_evalDist_liftBind [MeasurableSpace α] (a : P.A)
    (cont : P.B a → FreeM P α)
    (hcont : AEMeasurable (fun b ↦ 𝒟[cont b]) (AnswerMeasure.toMeasure a))
    {g : α → ENNReal} (hg : AEMeasurable g 𝒟[FreeM.liftBind a cont]) :
    ∫⁻ y, g y ∂𝒟[FreeM.liftBind a cont] =
      ∫⁻ b, ∫⁻ y, g y ∂𝒟[cont b] ∂AnswerMeasure.toMeasure a := by
  have hdenote : AEMeasurable (fun b ↦ denote (cont b)) (AnswerMeasure.toMeasure a) := by
    simpa only [evalDist_eq_denote] using hcont
  rw [evalDist_liftBind a cont hdenote] at hg ⊢
  exact Measure.lintegral_bind hcont hg

/-- A measurable pure function after one operation pushes forward its answer measure.
No discreteness assumption on the answer space is needed. -/
theorem evalDist_lift_bind_pure [MeasurableSpace α] (a : P.A) (f : P.B a → α)
    (hf : Measurable f) :
    𝒟[(FreeM.lift a >>= fun b ↦ pure (f b) : FreeM P α)] =
      (𝒟[(FreeM.lift a : FreeM P (P.B a))]).map f := by
  have hcont : AEMeasurable (fun b => denote (pure (f b) : FreeM P α))
      (AnswerMeasure.toMeasure a) := by
    change AEMeasurable (Measure.dirac ∘ f) (AnswerMeasure.toMeasure a)
    exact (Measure.measurable_dirac.comp hf).aemeasurable
  change 𝒟[FreeM.liftBind a (fun b => pure (f b))] = _
  rw [evalDist_liftBind (P := P) a _ hcont, evalDist_lift (P := P)]
  simp only [evalDist_pure]
  exact Measure.bind_dirac_eq_map _ hf

variable [∀ a, DiscreteMeasurableSpace (P.B a)]

instance [MeasurableSpace α] (program : FreeM P α) : IsProbabilityMeasure 𝒟[program] :=
  isProbabilityMeasure_denote program

/-- Over a discrete-answer interface, the direct measure semantics satisfies the Giry monad
laws. -/
noncomputable instance (priority := 20) instLawfulEvalDistSemanticsFreeM :
    LawfulEvalDistSemantics (FreeM P) where
  denote_bind := denote_bind

end FreeM
end PFunctor
