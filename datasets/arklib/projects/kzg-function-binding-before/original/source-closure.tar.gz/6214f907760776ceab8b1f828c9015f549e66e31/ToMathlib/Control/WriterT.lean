/-
Copyright (c) 2024 Devon Tuma. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Devon Tuma
-/
module

public import Mathlib.Algebra.Group.TypeTags.Basic
public import Mathlib.Control.Monad.Writer
public import Mathlib.Order.Basic
public import Batteries.Control.AlternativeMonad

/-!
# Writer Monad Transformer Utilities

This file extends `WriterT` with helper lemmas and the additive wrapper `AddWriterT`.

The first half of the file collects basic `WriterT` run, bind, and lifting lemmas, together with
the `LawfulAppend` class used to build lawful `WriterT` instances over append-like logs.

The second half specializes `WriterT` to additive cost accumulation via `Multiplicative`, and
introduces predicates and notation for reasoning about outputs and accumulated costs.
-/

@[expose] public section

universe u v w

/-- Typeclass for instances where `∅` is an identity for `++`. -/
class LawfulAppend (α : Type u)
    [EmptyCollection α] [Append α] where
  empty_append (x : α) : ∅ ++ x = x
  append_empty (x : α) : x ++ ∅ = x
  append_assoc (x y z : α) : x ++ (y ++ z) = x ++ y ++ z

namespace LawfulAppend

attribute [simp] LawfulAppend.empty_append LawfulAppend.append_empty

attribute [grind =] LawfulAppend.empty_append
  LawfulAppend.append_empty LawfulAppend.append_assoc

instance {M : Type u → Type v} {ω : Type u} [Monad M]
    [EmptyCollection ω] [Append ω] [LawfulAppend ω] [LawfulMonad M] :
    LawfulMonad (WriterT ω M) := LawfulMonad.mk'
  (bind_pure_comp := fun _ _ => by ext; simp)
  (id_map := fun _ => by ext; simp)
  (pure_bind := fun _ _ => by ext; simp)
  (bind_assoc := fun _ _ _ => by ext; simp [LawfulAppend.append_assoc])

instance (α : Type u) : LawfulAppend (List α) where
  empty_append := by simp
  append_empty := by simp
  append_assoc := by grind

end LawfulAppend

namespace WriterT.AppendWP

/-- Append associativity supplies the core law used by the writer interpretation. -/
scoped instance instAssociativeOfLawfulAppend {ω : Type u} [EmptyCollection ω] [Append ω]
    [LawfulAppend ω] : Std.Associative (α := ω) (· ++ ·) where
  assoc a b c := (LawfulAppend.append_assoc a b c).symm

/-- The empty append log is a two-sided identity for the writer interpretation. -/
scoped instance instLawfulIdentityOfLawfulAppend {ω : Type u} [EmptyCollection ω] [Append ω]
    [LawfulAppend ω] : Std.LawfulIdentity (α := ω) (· ++ ·) ∅ where
  left_id := LawfulAppend.empty_append
  right_id := LawfulAppend.append_empty

end WriterT.AppendWP

namespace WriterT

/-- A direct core monad lift writes the empty multiplicative log. -/
@[simp]
theorem run_core_monadLift {m : Type u → Type v} [Monad m] {ω α : Type u}
    [Monoid ω] (x : m α) :
    (MonadLift.monadLift x : WriterT ω m α).run = (fun a ↦ (a, 1)) <$> x := rfl



section basic

variable {m : Type u → Type v} [Monad m] {ω : Type u} {α β γ : Type u}

section monoid

variable [Monoid ω]

@[simp]
lemma run_monadLift (x : m α) : (monadLift x : WriterT ω m α).run = (·, 1) <$> x := rfl

lemma liftM_def (x : m α) :
    (liftM x : WriterT ω m α) = WriterT.mk ((·, 1) <$> x) := rfl

lemma monadLift_def (x : m α) :
    (MonadLift.monadLift x : WriterT ω m α) = WriterT.mk ((·, 1) <$> x) := rfl

lemma bind_def (x : WriterT ω m α) (f : α → WriterT ω m β) :
    x >>= f = WriterT.mk (x.run >>= fun (a, w₁) ↦
      (Prod.map id (w₁ * ·)) <$> (f a)) := rfl

@[simp]
lemma run_seqLeft {m : Type u → Type v} [Monad m] {ω : Type u} [Monoid ω] {α β : Type u}
    (x : WriterT ω m α) (y : WriterT ω m β) :
    (x *> y).run = x.run >>= fun z => Prod.map id (z.2 * ·) <$> y.run := rfl

/-- `Prod.fst <$> WriterT.run` preserves `pure` (Monoid flavour). -/
lemma fst_map_run_pure [LawfulMonad m] (x : α) :
    Prod.fst <$> ((pure x : WriterT ω m α).run) = pure x := by
  simp [WriterT.run_pure]

/-- `Prod.fst <$> WriterT.run` preserves `bind` (Monoid flavour) — i.e. it is a
monad morphism `WriterT ω m → m`. -/
lemma fst_map_run_bind [LawfulMonad m] (b : WriterT ω m α) (f : α → WriterT ω m β) :
    Prod.fst <$> (b >>= f).run =
      (Prod.fst <$> b.run) >>= fun x => Prod.fst <$> (f x).run := by
  simp only [WriterT.run_bind, map_bind, Functor.map_map]
  exact (bind_map_left (m := m) Prod.fst b.run (fun x => Prod.fst <$> (f x).run)).symm

end monoid

section append

variable [EmptyCollection ω]

@[simp]
lemma run_monadLift' (x : m α) : (monadLift x : WriterT ω m α).run = (·, ∅) <$> x := rfl

lemma liftM_def' (x : m α) :
    (liftM x : WriterT ω m α) = WriterT.mk ((·, ∅) <$> x) := rfl

lemma monadLift_def' (x : m α) :
    (MonadLift.monadLift x : WriterT ω m α) = WriterT.mk ((·, ∅) <$> x) := rfl

variable [Append ω]

lemma bind_def' (x : WriterT ω m α) (f : α → WriterT ω m β) :
    x >>= f = WriterT.mk (x.run >>= fun (a, w₁) ↦
      (Prod.map id (w₁ ++ ·)) <$> (f a)) := rfl

@[simp]
lemma run_pure' [LawfulMonad m] (x : α) :
    (pure x : WriterT ω m α).run = pure (x, ∅) := rfl

lemma run_bind' [LawfulMonad m] (x : WriterT ω m α) (f : α → WriterT ω m β) :
    (x >>= f).run = x.run >>= fun (a, w₁) => Prod.map id (w₁ ++ ·) <$> (f a).run := rfl

lemma run_map' (x : WriterT ω m α) (f : α → β) : (f <$> x).run = Prod.map f id <$> x.run := rfl

/-- `Prod.fst <$> WriterT.run` preserves `pure` (Append flavour). -/
lemma fst_map_run_pure' [LawfulMonad m] (x : α) :
    Prod.fst <$> ((pure x : WriterT ω m α).run) = pure x := by
  simp

/-- `Prod.fst <$> WriterT.run` preserves `bind` (Append flavour) — i.e. it is a
monad morphism `WriterT ω m → m`. -/
lemma fst_map_run_bind' [LawfulMonad m] (b : WriterT ω m α) (f : α → WriterT ω m β) :
    Prod.fst <$> (b >>= f).run =
      (Prod.fst <$> b.run) >>= fun x => Prod.fst <$> (f x).run := by
  simp only [WriterT.run_bind', map_bind, Functor.map_map]
  exact (bind_map_left (m := m) Prod.fst b.run (fun x => Prod.fst <$> (f x).run)).symm

end append

end basic

-- @[simp]
-- lemma run_fail [AlternativeMonad m] [LawfulAlternative m] :
--     (failure : WriterT ω m α).run = Failure.fail := by
--   simp [failureOfLift_eq_lift_fail, WriterT.liftM_def]

-- /-- The naturally induced `Failure` on `WriterT` is lawful. -/
-- instance [Monad m] [LawfulMonad m] [Failure m] [LawfulFailure m] :
--     LawfulFailure (WriterT ω m) where
--   fail_bind' {α β} f := by
--     show WriterT.mk _ = WriterT.mk _
--     simp [monadLift_def, map_eq_bind_pure_comp, WriterT.mk, bind_assoc,
--       failureOfLift_eq_lift_fail, liftM_def]

section fail

variable {m : Type u → Type v} [AlternativeMonad m] {ω : Type u} {α β γ : Type u}

/-- Try `x₁`, falling back to `x₂ ()` through the `orElse` of the underlying monad `m`; the log
is the one written by the branch whose result is returned. -/
@[always_inline, inline]
protected def orElse {α : Type u} (x₁ : WriterT ω m α)
    (x₂ : Unit → WriterT ω m α) : WriterT ω m α :=
  WriterT.mk (x₁.run <|> (x₂ ()).run)

/-- The failing computation, inherited from the underlying monad `m`. -/
@[always_inline, inline]
protected def failure {α : Type u} : WriterT ω m α := WriterT.mk failure

instance [Monoid ω] : AlternativeMonad (WriterT ω m) where
  failure := WriterT.failure
  orElse  := WriterT.orElse

@[simp]
lemma run_failure [Monoid ω] {α : Type u} : (failure : WriterT ω m α).run = failure := rfl

instance [Monoid ω] [LawfulMonad m] : LawfulMonadLift m (WriterT ω m) where
  monadLift_pure x := map_pure (·, 1) x
  monadLift_bind {_ _} _ _ := by
    ext
    simp [MonadLift.monadLift]

end fail

end WriterT

/-! ## AddWriterT: Additive Writer Monad Transformer -/

/-- Writer monad transformer with additive cost accumulation.
Defined as `WriterT (Multiplicative ω) M`, which uses `Monoid (Multiplicative ω)`
(derived from `AddMonoid ω`) so that `tell` accumulates via `+` with identity `0`.

The types `Multiplicative ω` and `ω` are definitionally equal (`Multiplicative` is a plain
`def`, not a `structure`), so no runtime wrapping occurs. -/
abbrev AddWriterT (ω : Type u) (M : Type u → Type v) := WriterT (Multiplicative ω) M

namespace AddWriterT

variable {ω : Type u} {M : Type u → Type v} [Monad M] {α : Type u}

/-- Observe the output and additive cost, removing the writer's multiplicative type tag. -/
def runAdd (oa : AddWriterT ω M α) : M (α × ω) :=
  Prod.map id Multiplicative.toAdd <$> oa.run

/-- Removing the cost tag preserves the output projection. -/
@[simp]
lemma fst_map_runAdd [LawfulMonad M] (oa : AddWriterT ω M α) :
    Prod.fst <$> oa.runAdd = Prod.fst <$> oa.run := by
  simp [runAdd, Functor.map_map]

@[simp]
lemma runAdd_pure [AddMonoid ω] [LawfulMonad M] (x : α) :
    (pure x : AddWriterT ω M α).runAdd = pure (x, 0) := by
  simp [runAdd]

@[simp]
lemma runAdd_bind [AddMonoid ω] [LawfulMonad M] {β : Type u}
    (oa : AddWriterT ω M α) (ob : α → AddWriterT ω M β) :
    (oa >>= ob).runAdd = oa.runAdd >>= fun (x, cost) =>
      Prod.map id (cost + ·) <$> (ob x).runAdd := by
  simp [runAdd, WriterT.run_bind, map_bind, bind_map_left, Functor.map_map, Prod.map]

@[simp]
lemma runAdd_map [AddMonoid ω] [LawfulMonad M] {β : Type u}
    (f : α → β) (oa : AddWriterT ω M α) :
    (f <$> oa).runAdd = Prod.map f id <$> oa.runAdd := by
  simp [runAdd, Functor.map_map, Prod.map]

@[simp]
lemma runAdd_liftM [AddMonoid ω] [LawfulMonad M] (oa : M α) :
    (liftM oa : AddWriterT ω M α).runAdd = (fun x => (x, 0)) <$> oa := by
  simp [runAdd, Functor.map_map]

/-- Forget the additive cost log and keep only the outputs of an `AddWriterT` computation. -/
def outputs (oa : AddWriterT ω M α) : M α :=
  Prod.fst <$> oa.run

/-- Observe only the accumulated additive cost of an `AddWriterT` computation. -/
def costs (oa : AddWriterT ω M α) : M ω :=
  (fun z => Multiplicative.toAdd z.2) <$> oa.run

/-- Record an additive cost `w` in the writer log. -/
def addTell [AddMonoid ω] (w : ω) : AddWriterT ω M PUnit :=
  tell (Multiplicative.ofAdd w)

@[simp]
lemma outputs_def (oa : AddWriterT ω M α) :
    oa.outputs = Prod.fst <$> oa.run := rfl

@[simp]
lemma costs_def (oa : AddWriterT ω M α) :
    oa.costs = (fun z => Multiplicative.toAdd z.2) <$> oa.run := rfl

/-- A pure additive-writer computation has zero cost. -/
@[simp high]
lemma costs_pure [AddMonoid ω] [LawfulMonad M] (x : α) :
    (pure x : AddWriterT ω M α).costs = pure 0 := by
  simp [costs]

@[simp]
lemma run_addTell [AddMonoid ω] (w : ω) :
    (addTell (M := M) w).run = pure (⟨⟩, Multiplicative.ofAdd w) := rfl

@[simp]
lemma runAdd_addTell [AddMonoid ω] [LawfulMonad M] (w : ω) :
    (addTell (M := M) w).runAdd = pure (⟨⟩, w) := by
  simp [runAdd]

lemma outputs_addTell [AddMonoid ω] [LawfulMonad M] (w : ω) :
    (addTell (M := M) w).outputs = pure ⟨⟩ := by
  simp [outputs, addTell]

lemma costs_addTell [AddMonoid ω] [LawfulMonad M] (w : ω) :
    (addTell (M := M) w).costs = pure w := by
  simp [costs, addTell]

section costPredicates

/-- `CostsAs oa f` means that the accumulated cost of `oa` is determined by its output via the
function `f`.

Concretely, whenever `oa` produces output `a`, the recorded cost is exactly `f a`. This is a
strong structural property: it can fail when the same output can be reached by different execution
paths carrying different costs. -/
def CostsAs (oa : AddWriterT ω M α) (f : α → ω) : Prop :=
  oa.costs = f <$> oa.outputs

/-- `HasCost oa w` means that every execution path of `oa` incurs the constant cost `w`. -/
def HasCost (oa : AddWriterT ω M α) (w : ω) : Prop :=
  oa.CostsAs (fun _ ↦ w)

/-- `OutputCostAtMost oa w` means that `oa` admits an output-indexed cost description bounded above
by the constant `w`.

Concretely, there is some function `f : α → ω` such that every execution producing output `a`
accumulates cost `f a`, and each such `f a` is at most `w`. This is stronger than a merely
pathwise upper bound when the same output can be reached with different costs. -/
def OutputCostAtMost [Preorder ω] (oa : AddWriterT ω M α) (w : ω) : Prop :=
  ∃ f : α → ω, oa.CostsAs f ∧ ∀ a, f a ≤ w

/-- `OutputCostAtLeast oa w` means that `oa` admits an output-indexed cost description bounded
below by the constant `w`.

As with [`AddWriterT.OutputCostAtMost`], this packages a cost function determined by the final
output, not just an arbitrary pathwise lower bound. -/
def OutputCostAtLeast [Preorder ω] (oa : AddWriterT ω M α) (w : ω) : Prop :=
  ∃ f : α → ω, oa.CostsAs f ∧ ∀ a, w ≤ f a

/-- `Cost[ oa ] = w` means that the `AddWriterT` computation `oa` incurs the same additive cost
`w` on every execution path.

This is notation for [`AddWriterT.HasCost`]. It is intended for theorem statements where the
constant-cost reading is more natural than the underlying output-indexed formulation
[`AddWriterT.CostsAs`]. -/
syntax:max "Cost[ " term " ]" " = " term:50 : term

macro_rules
  | `(Cost[ $oa ] = $w) => `(AddWriterT.HasCost $oa $w)

/-- `OutputCost[ oa ] ≤ w` means that `oa` admits an output-indexed additive-cost bound by `w`.

This is notation for [`AddWriterT.OutputCostAtMost`]. It is best used when cost is already known
to be determined by the final output, or when that stronger formulation is useful in a proof. -/
syntax:max "OutputCost[ " term " ]" " ≤ " term:50 : term

macro_rules
  | `(OutputCost[ $oa ] ≤ $w) => `(AddWriterT.OutputCostAtMost $oa $w)

/-- `OutputCost[ oa ] ≥ w` means that `oa` admits an output-indexed additive-cost lower bound by
`w`.

This is notation for [`AddWriterT.OutputCostAtLeast`]. As with [`OutputCost[ oa ] ≤ w`], it is
formulated in terms of an output-indexed cost witness rather than arbitrary execution paths. -/
syntax:max "OutputCost[ " term " ]" " ≥ " term:50 : term

macro_rules
  | `(OutputCost[ $oa ] ≥ $w) => `(AddWriterT.OutputCostAtLeast $oa $w)

@[simp]
lemma costsAs_iff (oa : AddWriterT ω M α) (f : α → ω) :
    oa.CostsAs f ↔ oa.costs = f <$> oa.outputs :=
  Iff.rfl

@[simp]
lemma hasCost_iff (oa : AddWriterT ω M α) (w : ω) :
    (Cost[ oa ] = w) ↔ oa.costs = (fun _ ↦ w) <$> oa.outputs :=
  Iff.rfl

@[simp]
lemma outputCostAtMost_iff [Preorder ω] (oa : AddWriterT ω M α) (w : ω) :
    (OutputCost[ oa ] ≤ w) ↔ ∃ f : α → ω, oa.CostsAs f ∧ ∀ a, f a ≤ w :=
  Iff.rfl

@[simp]
lemma outputCostAtLeast_iff [Preorder ω] (oa : AddWriterT ω M α) (w : ω) :
    (OutputCost[ oa ] ≥ w) ↔ ∃ f : α → ω, oa.CostsAs f ∧ ∀ a, w ≤ f a :=
  Iff.rfl

lemma outputCostAtMost_of_hasCost [Preorder ω] {oa : AddWriterT ω M α} {w b : ω}
    (h : Cost[ oa ] = w) (hwb : w ≤ b) : OutputCost[ oa ] ≤ b := by
  refine ⟨fun _ ↦ w, ?_, fun _ ↦ hwb⟩
  exact h

lemma outputCostAtLeast_of_hasCost [Preorder ω] {oa : AddWriterT ω M α} {w b : ω}
    (h : Cost[ oa ] = w) (hbw : b ≤ w) : OutputCost[ oa ] ≥ b := by
  refine ⟨fun _ ↦ w, ?_, fun _ ↦ hbw⟩
  exact h

end costPredicates

end AddWriterT
