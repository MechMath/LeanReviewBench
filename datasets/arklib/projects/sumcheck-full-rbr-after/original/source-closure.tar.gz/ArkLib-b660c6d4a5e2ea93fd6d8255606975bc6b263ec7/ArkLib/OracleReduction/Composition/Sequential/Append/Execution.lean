/-
Copyright (c) 2024-2026 ArkLib Contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Quang Dao, scaraven
-/
module

public import ArkLib.OracleReduction.Composition.Sequential.Append.StateFunction

/-!
  # Sequential Composition: Execution

  Running an appended prover / verifier / reduction. The main result is `Prover.append_run`,
  which decomposes `(P₁.append P₂).run` into the two component runs; it is supported by the
  transport ladder in the `AppendRunHelpers` section below.
-/

@[expose] public section

open OracleComp OracleSpec SubSpec

open ProtocolSpec

variable {ι : Type} {oSpec : OracleSpec ι} {Stmt₁ Wit₁ Stmt₂ Wit₂ Stmt₃ Wit₃ : Type}
  {m n : ℕ} {pSpec₁ : ProtocolSpec m} {pSpec₂ : ProtocolSpec n}

section Execution

/-! ## Helper lemmas for `Prover.append_run`

The appended prover `P₁.append P₂` is defined by a three-way `dif` on the round index (below the
seam / at the seam / above the seam), and each branch transports its state along a type equality.
Reasoning about `runToRound` therefore forces us to work up to `HEq`.  The lemmas below build the
transport ladder that `Prover.append_run` needs; they are all `private`, since they exist only to
serve that proof and the security proofs later in this file.
-/

section AppendRunHelpers

variable {P₁ : Prover oSpec Stmt₁ Wit₁ Stmt₂ Wit₂ pSpec₁}
    {P₂ : Prover oSpec Stmt₂ Wit₂ Stmt₃ Wit₃ pSpec₂}

/-! ### Transport helpers

The generic `HEq` congruence lemmas this ladder runs on (`heq_apply`, `heq_funext`, `heq_pi`,
`heq_prod`, `heq_bind`, `heq_dcast`, …) live in `ArkLib/ToMathlib/Logic/HEq.lean`; only the one
below is specific to `OracleComp` and so stays here. -/

/-- Congruence for `liftM` along a fixed `SubSpec` inclusion. The `OracleComp` analogue of
`heq_bind` / `heq_pure`, which cannot live with them because it mentions `SubSpec`. -/
private theorem heq_liftM {ι' : Type} {superSpec : OracleSpec ι'} [oSpec ⊂ₒ superSpec]
    {α α' : Type} (hα : α = α')
    {x : OracleComp oSpec α} {x' : OracleComp oSpec α'} (hx : HEq x x') :
    HEq (liftM x : OracleComp superSpec α) (liftM x' : OracleComp superSpec α') := by
  subst hα
  obtain rfl := eq_of_heq hx
  rfl

/-! ### Round behaviour below the seam -/

/-- Below the seam, the appended prover sends the first prover's message. -/
private theorem append_sendMessage_left (i : Fin (m + n)) (hi : i.val < m)
    (hDir : (pSpec₁ ++ₚ pSpec₂).dir i = .P_to_V)
    (hDir₁ : pSpec₁.dir ⟨i.val, hi⟩ = .P_to_V)
    (state : (P₁.append P₂).PrvState i.castSucc)
    (state₁ : P₁.PrvState (⟨i.val, hi⟩ : Fin m).castSucc)
    (hst : HEq state state₁) :
    HEq ((P₁.append P₂).sendMessage ⟨i, hDir⟩ state)
        (P₁.sendMessage ⟨⟨i.val, hi⟩, hDir₁⟩ state₁) := by
  conv_lhs => unfold Prover.append
  dsimp only
  rw [dite_eq_left hi]
  refine (cast_heq _ _).trans (heq_of_eq ?_)
  congr 1
  exact eq_of_heq ((cast_heq _ _).trans hst)

/-- Below the seam, the appended prover receives the challenge as the first prover does. -/
private theorem append_receiveChallenge_left (i : Fin (m + n)) (hi : i.val < m)
    (hDir : (pSpec₁ ++ₚ pSpec₂).dir i = .V_to_P)
    (hDir₁ : pSpec₁.dir ⟨i.val, hi⟩ = .V_to_P)
    (state : (P₁.append P₂).PrvState i.castSucc)
    (state₁ : P₁.PrvState (⟨i.val, hi⟩ : Fin m).castSucc)
    (hst : HEq state state₁) :
    HEq ((P₁.append P₂).receiveChallenge ⟨i, hDir⟩ state)
        (P₁.receiveChallenge ⟨⟨i.val, hi⟩, hDir₁⟩ state₁) := by
  conv_lhs => unfold Prover.append
  dsimp only
  rw [dite_eq_left hi]
  refine (cast_heq _ _).trans (heq_of_eq ?_)
  congr 1
  exact eq_of_heq ((cast_heq _ _).trans hst)

/-! ### Transcript payload types -/

/-- The two `Type` families a left-index transcript ranges over are equal. -/
private theorem transcript_family_left (k : ℕ) (hk : k ≤ m) (h1 : k ≤ m + n) :
    (fun i : Fin k => (pSpec₁ ++ₚ pSpec₂).«Type» (Fin.castLE h1 i))
      = (fun i : Fin k => pSpec₁.«Type» (Fin.castLE hk i)) := by
  funext i
  have hcast : Fin.castLE h1 i = Fin.castAdd n (Fin.castLE hk i) := by ext; simp
  rw [hcast, append_Type_castAdd]

/-- At a round index below the seam, a partial transcript of the appended protocol has the same
type as one of the first protocol. -/
private theorem transcript_left_type_eq (k : Fin (m + n + 1)) (j : Fin (m + 1))
    (hkj : k.val = j.val) :
    (pSpec₁ ++ₚ pSpec₂).Transcript k = pSpec₁.Transcript j := by
  obtain ⟨kv, hk⟩ := k
  obtain ⟨jv, hjv⟩ := j
  dsimp only at hkj
  subst hkj
  change ((i : Fin kv) → (pSpec₁ ++ₚ pSpec₂).«Type» (Fin.castLE (by omega) i))
    = ((i : Fin kv) → pSpec₁.«Type» (Fin.castLE (by omega) i))
  refine congrArg (fun F : Fin kv → Type => (i : Fin kv) → F i) ?_
  exact transcript_family_left kv (by omega) (by omega)

/-- `Transcript.concat` is compatible with the left-append transport. -/
private theorem heq_concat_left (j : Fin (m + n)) (hj : j.val < m)
    {msg : (pSpec₁ ++ₚ pSpec₂).«Type» j} {msg₁ : pSpec₁.«Type» ⟨j.val, hj⟩} (hmsg : HEq msg msg₁)
    {tr : (pSpec₁ ++ₚ pSpec₂).Transcript j.castSucc}
    {tr₁ : pSpec₁.Transcript (⟨j.val, hj⟩ : Fin m).castSucc} (htr : HEq tr tr₁) :
    HEq (Transcript.concat msg tr) (Transcript.concat msg₁ tr₁) := by
  refine heq_pi (transcript_family_left (j.val + 1) (by omega) (by omega)) (fun i => ?_)
  rcases Nat.lt_or_ge i.val j.val with h | h
  · refine (Transcript.concat_apply_lt tr msg i.val h i.isLt).trans ?_
    refine HEq.trans ?_ (Transcript.concat_apply_lt tr₁ msg₁ i.val h i.isLt).symm
    exact heq_dapply (transcript_family_left j.val (by omega) (by omega)) htr ⟨i.val, h⟩
  · have hi : i.val = j.val := by have := i.isLt; omega
    exact ((Transcript.concat_apply_last tr msg i.val hi i.isLt).trans hmsg).trans
      (Transcript.concat_apply_last tr₁ msg₁ i.val hi i.isLt).symm

/-! ### `processRound` only sees its input through a bind -/

/-- `processRound` uses its incoming computation only through a `bind`, so it suffices to prove
round lemmas for a `pure` input and re-bind. -/
private theorem processRound_eq_bind {N : ℕ} {pSpec : ProtocolSpec N} (j : Fin N)
    (P : Prover oSpec Stmt₁ Wit₁ Stmt₂ Wit₂ pSpec)
    (cur : OracleComp (oSpec + [pSpec.Challenge]ₒ)
      (pSpec.Transcript j.castSucc × P.PrvState j.castSucc)) :
    P.processRound j cur = cur >>= fun x => P.processRound j (pure x) := by
  unfold Prover.processRound
  simp [pure_bind]

/-! ### Lift coherence: the two-step lift agrees with the direct lift -/

/-- Lifting an `oSpec` computation into the first component and then into the appended protocol
is the same as lifting it into the appended protocol directly. -/
private theorem liftAppendLeft_liftM {α : Type} (oa : OracleComp oSpec α) :
    (liftAppendLeft pSpec₂ (liftM oa : OracleComp (oSpec + [pSpec₁.Challenge]ₒ) α))
      = (liftM oa : OracleComp (oSpec + [(pSpec₁ ++ₚ pSpec₂).Challenge]ₒ) α) := by
  unfold liftAppendLeft
  induction oa using OracleComp.inductionOn with
  | pure a => rfl
  | query_bind t k ih =>
    simp [ih]
    congr 1

/-- Lifting a left-component challenge query into the appended protocol queries the
left-injected index and transports the response back. -/
private theorem liftAppendLeft_getChallenge (i : ChallengeIdx pSpec₁) :
    liftAppendLeft pSpec₂
        ((liftM (pSpec₁.getChallenge i)) :
          OracleComp (oSpec + [pSpec₁.Challenge]ₒ) (pSpec₁.Challenge i))
      = cast (challenge_append_inl (pSpec₂ := pSpec₂) i) <$>
          ((liftM ((pSpec₁ ++ₚ pSpec₂).getChallenge (ChallengeIdx.inl i))) :
            OracleComp (oSpec + [(pSpec₁ ++ₚ pSpec₂).Challenge]ₒ)
              ((pSpec₁ ++ₚ pSpec₂).Challenge (ChallengeIdx.inl i))) := by
  unfold liftAppendLeft
  rfl

/-! ### `processRound` below the seam -/

/-- **A round below the seam.** The appended prover's round `j < m` is the first prover's round
`j`, lifted. Stated for a `pure` input; `processRound_eq_bind` re-binds it. -/
private theorem append_processRound_left_pure_input (j : Fin (m + n)) (hj : j.val < m)
    (tr : (pSpec₁ ++ₚ pSpec₂).Transcript j.castSucc)
    (st : (P₁.append P₂).PrvState j.castSucc)
    (tr₁ : pSpec₁.Transcript (⟨j.val, hj⟩ : Fin m).castSucc)
    (st₁ : P₁.PrvState (⟨j.val, hj⟩ : Fin m).castSucc)
    (htr : HEq tr tr₁) (hst : HEq st st₁) :
    HEq ((P₁.append P₂).processRound j (pure ⟨tr, st⟩))
        (liftAppendLeft pSpec₂ (P₁.processRound ⟨j.val, hj⟩ (pure ⟨tr₁, st₁⟩))) := by
  have hdir : Fin.vappend pSpec₁.dir pSpec₂.dir j = pSpec₁.dir ⟨j.val, hj⟩ :=
    Fin.vappend_left_of_lt _ _ j hj
  unfold Prover.processRound liftAppendLeft
  simp only [pure_bind]
  split <;> rename_i hA <;> split <;> rename_i hB
  · -- both V_to_P
    simp only [liftM_bind, liftM_pure, liftAppendLeft_liftM, liftAppendLeft_getChallenge,
      bind_map_left]
    have hChal : (pSpec₁ ++ₚ pSpec₂).Challenge (⟨j, hA⟩ : ChallengeIdx (pSpec₁ ++ₚ pSpec₂))
        = pSpec₁.Challenge ⟨⟨j.val, hj⟩, hB⟩ :=
      challenge_append_inl (pSpec₂ := pSpec₂) ⟨⟨j.val, hj⟩, hB⟩
    have hStS : (P₁.append P₂).PrvState j.succ = P₁.PrvState (⟨j.val, hj⟩ : Fin m).succ :=
      Prover.append_prvState_left _ _ rfl
    have hTrS : (pSpec₁ ++ₚ pSpec₂).Transcript j.succ
        = pSpec₁.Transcript (⟨j.val, hj⟩ : Fin m).succ :=
      transcript_left_type_eq _ _ rfl
    have hPairOut : ((pSpec₁ ++ₚ pSpec₂).Transcript j.succ × (P₁.append P₂).PrvState j.succ)
        = (pSpec₁.Transcript (⟨j.val, hj⟩ : Fin m).succ
            × P₁.PrvState (⟨j.val, hj⟩ : Fin m).succ) :=
      congrArg₂ Prod hTrS hStS
    have hMOut : OracleComp (oSpec + [(pSpec₁ ++ₚ pSpec₂).Challenge]ₒ)
          ((pSpec₁ ++ₚ pSpec₂).Transcript j.succ × (P₁.append P₂).PrvState j.succ)
        = OracleComp (oSpec + [(pSpec₁ ++ₚ pSpec₂).Challenge]ₒ)
          (pSpec₁.Transcript (⟨j.val, hj⟩ : Fin m).succ
            × P₁.PrvState (⟨j.val, hj⟩ : Fin m).succ) :=
      congrArg _ hPairOut
    have hFun : ((pSpec₁ ++ₚ pSpec₂).Challenge (⟨j, hA⟩ : ChallengeIdx (pSpec₁ ++ₚ pSpec₂))
          → (P₁.append P₂).PrvState j.succ)
        = (pSpec₁.Challenge ⟨⟨j.val, hj⟩, hB⟩ → P₁.PrvState (⟨j.val, hj⟩ : Fin m).succ) :=
      congrArg₂ (fun X Y => X → Y) hChal hStS
    have hMFun : OracleComp (oSpec + [(pSpec₁ ++ₚ pSpec₂).Challenge]ₒ)
          ((pSpec₁ ++ₚ pSpec₂).Challenge (⟨j, hA⟩ : ChallengeIdx (pSpec₁ ++ₚ pSpec₂))
            → (P₁.append P₂).PrvState j.succ)
        = OracleComp (oSpec + [(pSpec₁ ++ₚ pSpec₂).Challenge]ₒ)
          (pSpec₁.Challenge ⟨⟨j.val, hj⟩, hB⟩ → P₁.PrvState (⟨j.val, hj⟩ : Fin m).succ) :=
      congrArg _ hFun
    refine heq_bind rfl hPairOut HEq.rfl ?_
    refine heq_funext rfl hMOut ?_
    intro c c' hc
    obtain rfl := eq_of_heq hc
    refine heq_bind hFun hPairOut ?_ ?_
    · exact heq_liftM hFun (append_receiveChallenge_left j hj hA hB st st₁ hst)
    · refine heq_funext hFun hMOut ?_
      intro f f' hf
      exact heq_pure hPairOut
        (heq_prod hTrS hStS
          (heq_concat_left j hj (cast_heq hChal c).symm htr)
          (heq_apply hChal hStS hf (cast_heq hChal c).symm))
  · rw [hdir, hB] at hA; exact absurd hA (by simp)
  · rw [hdir, hB] at hA; exact absurd hA (by simp)
  · -- both P_to_V
    simp only [liftM_bind, liftM_pure, liftAppendLeft_liftM]
    have hMsg : (pSpec₁ ++ₚ pSpec₂).«Type» j = pSpec₁.«Type» ⟨j.val, hj⟩ :=
      calc (pSpec₁ ++ₚ pSpec₂).«Type» j
          = (pSpec₁ ++ₚ pSpec₂).«Type» (Fin.castAdd n (⟨j.val, hj⟩ : Fin m)) :=
            congrArg _ (Fin.ext rfl).symm
        _ = pSpec₁.«Type» ⟨j.val, hj⟩ := append_Type_castAdd _
    have hStS : (P₁.append P₂).PrvState j.succ = P₁.PrvState (⟨j.val, hj⟩ : Fin m).succ :=
      Prover.append_prvState_left _ _ rfl
    have hTrS : (pSpec₁ ++ₚ pSpec₂).Transcript j.succ
        = pSpec₁.Transcript (⟨j.val, hj⟩ : Fin m).succ :=
      transcript_left_type_eq _ _ rfl
    have hPairIn : ((pSpec₁ ++ₚ pSpec₂).Message ⟨j, hA⟩ × (P₁.append P₂).PrvState j.succ)
        = (pSpec₁.Message ⟨⟨j.val, hj⟩, hB⟩ × P₁.PrvState (⟨j.val, hj⟩ : Fin m).succ) :=
      congrArg₂ Prod hMsg hStS
    have hPairOut : ((pSpec₁ ++ₚ pSpec₂).Transcript j.succ × (P₁.append P₂).PrvState j.succ)
        = (pSpec₁.Transcript (⟨j.val, hj⟩ : Fin m).succ
            × P₁.PrvState (⟨j.val, hj⟩ : Fin m).succ) :=
      congrArg₂ Prod hTrS hStS
    refine heq_bind hPairIn hPairOut ?_ ?_
    · exact heq_liftM hPairIn (append_sendMessage_left j hj hA hB st st₁ hst)
    · have hMOut : OracleComp (oSpec + [(pSpec₁ ++ₚ pSpec₂).Challenge]ₒ)
            ((pSpec₁ ++ₚ pSpec₂).Transcript j.succ × (P₁.append P₂).PrvState j.succ)
          = OracleComp (oSpec + [(pSpec₁ ++ₚ pSpec₂).Challenge]ₒ)
            (pSpec₁.Transcript (⟨j.val, hj⟩ : Fin m).succ
              × P₁.PrvState (⟨j.val, hj⟩ : Fin m).succ) :=
        congrArg _ hPairOut
      refine heq_funext hPairIn hMOut ?_
      intro x x' hx
      exact heq_pure hPairOut
        (heq_prod hTrS hStS (heq_concat_left j hj (heq_fst hMsg hStS hx) htr)
          (heq_snd hMsg hStS hx))

/-! ### Running up to a round below the seam -/

/-- The appended prover's `input` is the first prover's, modulo the state transport. -/
private theorem append_input (ctxIn : Stmt₁ × Wit₁) :
    HEq ((P₁.append P₂).input ctxIn) (P₁.input ctxIn) := by
  conv_lhs => unfold Prover.append
  dsimp only
  rw [eq_mpr_eq_cast]
  exact cast_heq _ (P₁.input ctxIn)

/-- The two empty transcripts (appended protocol, first protocol) agree. -/
private theorem heq_default_transcript :
    HEq (default : (pSpec₁ ++ₚ pSpec₂).Transcript 0) (default : pSpec₁.Transcript 0) := by
  refine heq_pi (transcript_family_left 0 (by omega) (by omega)) (fun i => ?_)
  exact Fin.elim0 i

/-- The payload type of `runToRound` below the seam. -/
private theorem payload_left_eq (k : Fin (m + n + 1)) (j : Fin (m + 1)) (hkj : k.val = j.val) :
    ((pSpec₁ ++ₚ pSpec₂).Transcript k × (P₁.append P₂).PrvState k)
      = (pSpec₁.Transcript j × P₁.PrvState j) :=
  congrArg₂ Prod (transcript_left_type_eq k j hkj) (Prover.append_prvState_left k j hkj)

/-- **Running below the seam.** Up to any round `k ≤ m`, running the appended prover is running
the first prover to round `k`, lifted. Induction on `k`, stepped by
`append_processRound_left_pure_input`. -/
private theorem append_runToRound_left (stmt : Stmt₁) (wit : Wit₁) (j : Fin (m + 1)) :
    ∀ (k : Fin (m + n + 1)), k.val = j.val →
      HEq ((P₁.append P₂).runToRound k stmt wit)
          (liftAppendLeft pSpec₂ (P₁.runToRound j stmt wit)) := by
  induction j using Fin.induction with
  | zero =>
    intro k hk
    obtain rfl : k = 0 := Fin.ext (by simpa using hk)
    unfold Prover.runToRound
    simp only [Fin.induction_zero, liftAppendLeft]
    exact heq_pure (payload_left_eq 0 0 (by simp))
      (heq_prod (transcript_left_type_eq 0 0 (by simp)) (Prover.append_prvState_left 0 0 (by simp))
        heq_default_transcript (append_input _))
  | succ i ih =>
    intro k hk
    have hle : m ≤ m + n := Nat.le_add_right m n
    obtain rfl : k = (Fin.castLE hle i).succ := by
      refine Fin.ext ?_
      have := i.isLt
      simpa using hk
    unfold Prover.runToRound
    simp only [Fin.induction_succ]
    rw [processRound_eq_bind (P := P₁.append P₂), processRound_eq_bind (P := P₁)]
    simp only [liftM_bind]
    refine heq_bind (payload_left_eq _ _ (by simp)) (payload_left_eq _ _ (by simp))
      (ih _ (by simp)) ?_
    refine heq_funext (payload_left_eq _ _ (by simp))
      (congrArg _ (payload_left_eq _ _ (by simp))) ?_
    intro x x' hx
    exact append_processRound_left_pure_input (Fin.castLE hle i) i.isLt
      x.1 x.2 x'.1 x'.2
      (heq_fst (transcript_left_type_eq _ _ (by simp))
        (Prover.append_prvState_left _ _ (by simp)) hx)
      (heq_snd (transcript_left_type_eq _ _ (by simp))
        (Prover.append_prvState_left _ _ (by simp)) hx)

/-! ### The seam round `m`, and rounds above it -/

/-- **The seam round, `P_to_V` case.** The appended prover's message at round `m` is the second
prover's first message, after binding the first prover's output. -/
private theorem append_sendMessage_seam (i : Fin (m + n)) (him : i.val = m) (hn : 0 < n)
    (hDir : (pSpec₁ ++ₚ pSpec₂).dir i = .P_to_V)
    (hDir₂ : pSpec₂.dir ⟨0, hn⟩ = .P_to_V)
    (state : (P₁.append P₂).PrvState i.castSucc)
    (state₁ : P₁.PrvState (Fin.last m)) (hst : HEq state state₁) :
    HEq ((P₁.append P₂).sendMessage ⟨i, hDir⟩ state)
        (P₁.output state₁ >>= fun ctx => P₂.sendMessage ⟨⟨0, hn⟩, hDir₂⟩ (P₂.input ctx)) := by
  conv_lhs => unfold Prover.append
  dsimp only
  rw [dite_eq_right (by omega : ¬ i.val < m), dite_eq_left him]
  refine (cast_heq _ _).trans (heq_of_eq ?_)
  exact congrArg (fun z => P₁.output z >>= fun ctx =>
    P₂.sendMessage ⟨⟨0, hn⟩, hDir₂⟩ (P₂.input ctx))
    (eq_of_heq ((cast_heq _ _).trans hst))

/-- **The seam round, `V_to_P` case.** The `receiveChallenge` counterpart of
`append_sendMessage_seam`. This is where the purity of `P₁.output` is consumed. -/
private theorem append_receiveChallenge_seam (i : Fin (m + n)) (him : i.val = m) (hn : 0 < n)
    (outputFn : P₁.PrvState (Fin.last m) → Stmt₂ × Wit₂)
    (hOutput : P₁.output = fun st => pure (outputFn st))
    (hDir : (pSpec₁ ++ₚ pSpec₂).dir i = .V_to_P)
    (hDir₂ : pSpec₂.dir ⟨0, hn⟩ = .V_to_P)
    (state : (P₁.append P₂).PrvState i.castSucc)
    (state₁ : P₁.PrvState (Fin.last m)) (hst : HEq state state₁) :
    HEq ((P₁.append P₂).receiveChallenge ⟨i, hDir⟩ state)
        (P₂.receiveChallenge ⟨⟨0, hn⟩, hDir₂⟩ (P₂.input (outputFn state₁))) := by
  conv_lhs => unfold Prover.append
  dsimp only
  rw [dite_eq_right (by omega : ¬ i.val < m), dite_eq_left him]
  refine (cast_heq _ _).trans (heq_of_eq ?_)
  rw [hOutput]
  simp only [pure_bind]
  exact congrArg (fun z => P₂.receiveChallenge ⟨⟨0, hn⟩, hDir₂⟩ (P₂.input (outputFn z)))
    (eq_of_heq ((cast_heq _ _).trans hst))

/-- Past the seam, the appended prover sends the second prover's message. -/
private theorem append_sendMessage_right (i : Fin (m + n)) (hi : m < i.val) (hik : i.val - m < n)
    (hDir : (pSpec₁ ++ₚ pSpec₂).dir i = .P_to_V)
    (hDir₂ : pSpec₂.dir ⟨i.val - m, hik⟩ = .P_to_V)
    (state : (P₁.append P₂).PrvState i.castSucc)
    (state₂ : P₂.PrvState (⟨i.val - m, hik⟩ : Fin n).castSucc) (hst : HEq state state₂) :
    HEq ((P₁.append P₂).sendMessage ⟨i, hDir⟩ state)
        (P₂.sendMessage ⟨⟨i.val - m, hik⟩, hDir₂⟩ state₂) := by
  conv_lhs => unfold Prover.append
  dsimp only
  rw [dite_eq_right (by omega : ¬ i.val < m), dite_eq_right (by omega : ¬ i.val = m)]
  refine (cast_heq _ _).trans (heq_of_eq ?_)
  congr 1
  exact eq_of_heq ((heq_dcast _ _).trans ((cast_heq _ _).trans hst))

/-- Past the seam, the appended prover receives the challenge as the second prover does. -/
private theorem append_receiveChallenge_right (i : Fin (m + n)) (hi : m < i.val)
    (hik : i.val - m < n)
    (hDir : (pSpec₁ ++ₚ pSpec₂).dir i = .V_to_P)
    (hDir₂ : pSpec₂.dir ⟨i.val - m, hik⟩ = .V_to_P)
    (state : (P₁.append P₂).PrvState i.castSucc)
    (state₂ : P₂.PrvState (⟨i.val - m, hik⟩ : Fin n).castSucc) (hst : HEq state state₂) :
    HEq ((P₁.append P₂).receiveChallenge ⟨i, hDir⟩ state)
        (P₂.receiveChallenge ⟨⟨i.val - m, hik⟩, hDir₂⟩ state₂) := by
  conv_lhs => unfold Prover.append
  dsimp only
  rw [dite_eq_right (by omega : ¬ i.val < m), dite_eq_right (by omega : ¬ i.val = m)]
  refine (cast_heq _ _).trans (heq_of_eq ?_)
  congr 1
  exact eq_of_heq ((heq_dcast _ _).trans ((cast_heq _ _).trans hst))

/-- `append_sendMessage_right` stated at an explicit `pSpec₂` round index. -/
private theorem append_sendMessage_right' (i : Fin (m + n)) (l : Fin n) (hil : i.val = m + l.val)
    (hl : 0 < l.val)
    (hDir : (pSpec₁ ++ₚ pSpec₂).dir i = .P_to_V) (hDir₂ : pSpec₂.dir l = .P_to_V)
    (state : (P₁.append P₂).PrvState i.castSucc) (state₂ : P₂.PrvState l.castSucc)
    (hst : HEq state state₂) :
    HEq ((P₁.append P₂).sendMessage ⟨i, hDir⟩ state) (P₂.sendMessage ⟨l, hDir₂⟩ state₂) := by
  have hik : i.val - m < n := by have := i.isLt; omega
  obtain rfl : l = ⟨i.val - m, hik⟩ := Fin.ext (show l.val = i.val - m by omega)
  exact append_sendMessage_right i (by omega) hik hDir hDir₂ state state₂ hst

/-- `append_receiveChallenge_right` stated at an explicit `pSpec₂` round index. -/
private theorem append_receiveChallenge_right' (i : Fin (m + n)) (l : Fin n)
    (hil : i.val = m + l.val)
    (hl : 0 < l.val)
    (hDir : (pSpec₁ ++ₚ pSpec₂).dir i = .V_to_P) (hDir₂ : pSpec₂.dir l = .V_to_P)
    (state : (P₁.append P₂).PrvState i.castSucc) (state₂ : P₂.PrvState l.castSucc)
    (hst : HEq state state₂) :
    HEq ((P₁.append P₂).receiveChallenge ⟨i, hDir⟩ state)
        (P₂.receiveChallenge ⟨l, hDir₂⟩ state₂) := by
  have hik : i.val - m < n := by have := i.isLt; omega
  obtain rfl : l = ⟨i.val - m, hik⟩ := Fin.ext (show l.val = i.val - m by omega)
  exact append_receiveChallenge_right i (by omega) hik hDir hDir₂ state state₂ hst

/-! ### Combining a full left transcript with a partial right transcript -/

/-- Below the seam, the appended protocol's payload type is the first protocol's. -/
private theorem append_Type_lt (i : Fin (m + n)) (h : i.val < m) :
    (pSpec₁ ++ₚ pSpec₂).«Type» i = pSpec₁.«Type» ⟨i.val, h⟩ :=
  calc (pSpec₁ ++ₚ pSpec₂).«Type» i
      = (pSpec₁ ++ₚ pSpec₂).«Type» (Fin.castAdd n (⟨i.val, h⟩ : Fin m)) :=
        congrArg _ (Fin.ext rfl).symm
    _ = pSpec₁.«Type» ⟨i.val, h⟩ := append_Type_castAdd _

/-- Past the seam, the appended protocol's payload type is the second protocol's. -/
private theorem append_Type_ge (i : Fin (m + n)) (h2 : i.val - m < n) (h : m ≤ i.val) :
    (pSpec₁ ++ₚ pSpec₂).«Type» i = pSpec₂.«Type» ⟨i.val - m, h2⟩ :=
  calc (pSpec₁ ++ₚ pSpec₂).«Type» i
      = (pSpec₁ ++ₚ pSpec₂).«Type» (Fin.natAdd m (⟨i.val - m, h2⟩ : Fin n)) :=
        congrArg _ (Fin.ext (show m + (i.val - m) = i.val by omega)).symm
    _ = pSpec₂.«Type» ⟨i.val - m, h2⟩ := append_Type_natAdd _

/-- Glue a complete `pSpec₁` transcript onto a partial `pSpec₂` transcript. -/
private def concatLR {k : Fin (m + n + 1)} {l : Fin (n + 1)} (hkl : k.val = m + l.val)
    (tr₁ : pSpec₁.FullTranscript) (tr₂ : pSpec₂.Transcript l) :
    (pSpec₁ ++ₚ pSpec₂).Transcript k := fun i =>
  have hi : i.val < k.val := i.isLt
  have hl : l.val < n + 1 := l.isLt
  have hk : k.val ≤ m + n := by have := k.isLt; omega
  if h : i.val < m then
    cast (append_Type_lt (pSpec₂ := pSpec₂) (Fin.castLE hk i) h).symm (tr₁ ⟨i.val, h⟩)
  else
    cast (append_Type_ge (pSpec₁ := pSpec₁) (Fin.castLE hk i)
        (show i.val - m < n by omega) (show m ≤ i.val by omega)).symm
      (tr₂ ⟨i.val - m, by omega⟩)

/-- Below the seam, `concatLR` reads from its left (full) transcript. -/
private theorem concatLR_apply_lt {k : Fin (m + n + 1)} {l : Fin (n + 1)} (hkl : k.val = m + l.val)
    (tr₁ : pSpec₁.FullTranscript) (tr₂ : pSpec₂.Transcript l)
    (i : Fin k.val) (h : i.val < m) :
    HEq (concatLR hkl tr₁ tr₂ i) (tr₁ ⟨i.val, h⟩) := by
  unfold concatLR
  rw [dite_eq_left h]
  exact cast_heq _ _

/-- Past the seam, `concatLR` reads from its right (partial) transcript. -/
private theorem concatLR_apply_ge {k : Fin (m + n + 1)} {l : Fin (n + 1)} (hkl : k.val = m + l.val)
    (tr₁ : pSpec₁.FullTranscript) (tr₂ : pSpec₂.Transcript l)
    (i : Fin k.val) (h : ¬ i.val < m) (h2 : i.val - m < l.val) :
    HEq (concatLR hkl tr₁ tr₂ i) (tr₂ ⟨i.val - m, h2⟩) := by
  unfold concatLR
  rw [dite_eq_right h]
  exact cast_heq _ _

/-- The empty transcript at round `0` of a non-empty protocol. -/
private def emptyTranscript {N : ℕ} {pSpec : ProtocolSpec N} (hN : 0 < N) :
    pSpec.Transcript (⟨0, hN⟩ : Fin N).castSucc := fun z => Fin.elim0 z

/-- Gluing at the seam: extending the left transcript by the first `pSpec₂` message. -/
private theorem concatLR_seam (hjlt : m < m + n) (hn : 0 < n)
    (tr : (pSpec₁ ++ₚ pSpec₂).Transcript (⟨m, hjlt⟩ : Fin (m + n)).castSucc)
    (tr₁ : pSpec₁.FullTranscript) (htr : HEq tr tr₁)
    (msg : (pSpec₁ ++ₚ pSpec₂).«Type» ⟨m, hjlt⟩) (msg₂ : pSpec₂.«Type» ⟨0, hn⟩)
    (hmsg : HEq msg msg₂)
    (hkl : ((⟨m, hjlt⟩ : Fin (m + n)).succ : Fin (m + n + 1)).val
      = m + ((⟨0, hn⟩ : Fin n).succ).val) :
    Transcript.concat msg tr
      = concatLR hkl tr₁ (Transcript.concat msg₂ (emptyTranscript hn)) := by
  funext i
  have hi : i.val < m + 1 := i.isLt
  refine eq_of_heq ?_
  rcases Nat.lt_or_ge i.val m with h | h
  · refine (Transcript.concat_apply_lt tr msg i.val h i.isLt).trans ?_
    refine HEq.trans ?_ (concatLR_apply_lt hkl tr₁ _ i h).symm
    have hfam := transcript_family_left (pSpec₁ := pSpec₁) (pSpec₂ := pSpec₂) m
      (le_refl m) (Nat.le_add_right m n)
    exact heq_dapply hfam htr ⟨i.val, h⟩
  · refine (Transcript.concat_apply_last tr msg i.val (show i.val = m by omega) i.isLt).trans ?_
    refine HEq.trans hmsg ?_
    refine HEq.trans ?_
      (concatLR_apply_ge hkl tr₁ _ i (show ¬ i.val < m by omega)
        (show i.val - m < 0 + 1 by omega)).symm
    exact (Transcript.concat_apply_last (emptyTranscript hn) msg₂ (i.val - m)
      (show i.val - m = 0 by omega) (show i.val - m < 0 + 1 by omega)).symm

/-- Gluing above the seam: extending by a later `pSpec₂` message. -/
private theorem concatLR_step (j : Fin (m + n)) (l : Fin n) (hjl : j.val = m + l.val)
    (tr₁ : pSpec₁.FullTranscript) (tr₂ : pSpec₂.Transcript l.castSucc)
    (msg : (pSpec₁ ++ₚ pSpec₂).«Type» j) (msg₂ : pSpec₂.«Type» l) (hmsg : HEq msg msg₂)
    (hkl : (j.castSucc : Fin (m + n + 1)).val = m + (l.castSucc).val)
    (hkl' : (j.succ : Fin (m + n + 1)).val = m + (l.succ).val) :
    Transcript.concat msg (concatLR hkl tr₁ tr₂)
      = concatLR hkl' tr₁ (Transcript.concat msg₂ tr₂) := by
  funext i
  have hi : i.val < j.val + 1 := i.isLt
  refine eq_of_heq ?_
  rcases Nat.lt_or_ge i.val m with h | h
  · refine (Transcript.concat_apply_lt _ msg i.val (show i.val < j.val by omega) i.isLt).trans ?_
    refine (concatLR_apply_lt hkl tr₁ tr₂ ⟨i.val, show i.val < j.val by omega⟩ h).trans ?_
    exact (concatLR_apply_lt hkl' tr₁ _ i h).symm
  · rcases Nat.lt_or_ge i.val j.val with h2 | h2
    · refine (Transcript.concat_apply_lt _ msg i.val h2 i.isLt).trans ?_
      refine (concatLR_apply_ge hkl tr₁ tr₂ ⟨i.val, show i.val < j.val by omega⟩
        (show ¬ i.val < m by omega) (show i.val - m < l.val by omega)).trans ?_
      refine HEq.trans ?_
        (concatLR_apply_ge hkl' tr₁ _ i (show ¬ i.val < m by omega)
          (show i.val - m < l.val + 1 by omega)).symm
      exact (Transcript.concat_apply_lt tr₂ msg₂ (i.val - m) (show i.val - m < l.val by omega)
        (show i.val - m < l.val + 1 by omega)).symm
    · refine (Transcript.concat_apply_last _ msg i.val
        (show i.val = j.val by omega) i.isLt).trans ?_
      refine HEq.trans hmsg ?_
      refine HEq.trans ?_
        (concatLR_apply_ge hkl' tr₁ _ i (show ¬ i.val < m by omega)
          (show i.val - m < l.val + 1 by omega)).symm
      exact (Transcript.concat_apply_last tr₂ msg₂ (i.val - m) (show i.val - m = l.val by omega)
        (show i.val - m < l.val + 1 by omega)).symm

/-! ### Right-hand lifts -/

/-- The `liftAppendRight` analogue of `liftAppendLeft_liftM`. -/
private theorem liftAppendRight_liftM {α : Type} (oa : OracleComp oSpec α) :
    (liftAppendRight pSpec₁ (liftM oa : OracleComp (oSpec + [pSpec₂.Challenge]ₒ) α))
      = (liftM oa : OracleComp (oSpec + [(pSpec₁ ++ₚ pSpec₂).Challenge]ₒ) α) := by
  unfold liftAppendRight
  induction oa using OracleComp.inductionOn with
  | pure a => rfl
  | query_bind t k ih =>
    simp [ih]
    congr 1

/-- Lifting a right-component challenge query into the appended protocol queries the
right-injected index and transports the response back. -/
private theorem liftAppendRight_getChallenge (i : ChallengeIdx pSpec₂) :
    liftAppendRight pSpec₁
        ((liftM (pSpec₂.getChallenge i)) :
          OracleComp (oSpec + [pSpec₂.Challenge]ₒ) (pSpec₂.Challenge i))
      = cast (challenge_append_inr (pSpec₁ := pSpec₁) i) <$>
          ((liftM ((pSpec₁ ++ₚ pSpec₂).getChallenge (ChallengeIdx.inr i))) :
            OracleComp (oSpec + [(pSpec₁ ++ₚ pSpec₂).Challenge]ₒ)
              ((pSpec₁ ++ₚ pSpec₂).Challenge (ChallengeIdx.inr i))) := by
  unfold liftAppendRight
  rfl

/-! ### `processRound` above the seam -/

/-- **A round past the seam.** The appended prover's round `m + l` (for `l > 0`) is the second
prover's round `l`, lifted, with the transcript re-glued by `concatLR`. -/
private theorem append_processRound_right_pure_input (l : Fin n) (hl : 0 < l.val)
    (tr₁ : pSpec₁.FullTranscript) (tr₂ : pSpec₂.Transcript l.castSucc)
    (st : (P₁.append P₂).PrvState (Fin.natAdd m l).castSucc) (st₂ : P₂.PrvState l.castSucc)
    (hst : HEq st st₂)
    (hkl : ((Fin.natAdd m l).castSucc : Fin (m + n + 1)).val = m + (l.castSucc).val)
    (hkl' : ((Fin.natAdd m l).succ : Fin (m + n + 1)).val = m + (l.succ).val) :
    HEq ((P₁.append P₂).processRound (Fin.natAdd m l) (pure ⟨concatLR hkl tr₁ tr₂, st⟩))
        ((fun p => ((concatLR hkl' tr₁ p.1 : (pSpec₁ ++ₚ pSpec₂).Transcript (Fin.natAdd m l).succ),
            p.2)) <$>
          liftAppendRight pSpec₁ (P₂.processRound l (pure ⟨tr₂, st₂⟩))) := by
  have hil : (Fin.natAdd m l).val = m + l.val := rfl
  have hlt : (Fin.natAdd m l).val - m < n := show m + l.val - m < n by have := l.isLt; omega
  have hidx : (⟨(Fin.natAdd m l).val - m, hlt⟩ : Fin n) = l :=
    Fin.ext (show m + l.val - m = l.val by omega)
  have hdir : Fin.vappend pSpec₁.dir pSpec₂.dir (Fin.natAdd m l) = pSpec₂.dir l := by
    rw [Fin.vappend_right_of_not_lt _ _ _ (show ¬ m + l.val < m by omega), hidx]
  have hStS : (P₁.append P₂).PrvState (Fin.natAdd m l).succ = P₂.PrvState l.succ :=
    Prover.append_prvState_right ((Fin.natAdd m l).succ) l.succ (show m < m + l.val + 1 by omega)
      (show m + l.val + 1 = m + (l.val + 1) by omega)
  unfold Prover.processRound liftAppendRight
  simp only [pure_bind]
  split <;> rename_i hA <;> split <;> rename_i hB
  · -- V_to_P
    simp only [liftM_bind, liftM_pure, liftAppendRight_liftM, liftAppendRight_getChallenge,
      map_bind, map_pure, bind_map_left]
    have hChal : (pSpec₁ ++ₚ pSpec₂).Challenge
          (⟨Fin.natAdd m l, hA⟩ : ChallengeIdx (pSpec₁ ++ₚ pSpec₂))
        = pSpec₂.Challenge ⟨l, hB⟩ :=
      challenge_append_inr (pSpec₁ := pSpec₁) ⟨l, hB⟩
    have hFun : ((pSpec₁ ++ₚ pSpec₂).Challenge
          (⟨Fin.natAdd m l, hA⟩ : ChallengeIdx (pSpec₁ ++ₚ pSpec₂))
          → (P₁.append P₂).PrvState (Fin.natAdd m l).succ)
        = (pSpec₂.Challenge ⟨l, hB⟩ → P₂.PrvState l.succ) :=
      congrArg₂ (fun X Y => X → Y) hChal hStS
    refine heq_bind rfl (congrArg₂ Prod rfl hStS) HEq.rfl ?_
    refine heq_funext rfl (congrArg _ (congrArg₂ Prod rfl hStS)) ?_
    intro c c' hc
    obtain rfl := eq_of_heq hc
    refine heq_bind hFun (congrArg₂ Prod rfl hStS) ?_ ?_
    · exact heq_liftM hFun
        (append_receiveChallenge_right' (Fin.natAdd m l) l hil hl hA hB st st₂ hst)
    · refine heq_funext hFun (congrArg _ (congrArg₂ Prod rfl hStS)) ?_
      intro f f' hf
      refine heq_pure (congrArg₂ Prod rfl hStS) ?_
      refine heq_prod rfl hStS ?_ (heq_apply hChal hStS hf (cast_heq hChal c).symm)
      exact heq_of_eq (concatLR_step (Fin.natAdd m l) l (by simp) tr₁ tr₂ c
        (cast hChal c) (cast_heq hChal c).symm hkl hkl')
  · rw [hdir, hB] at hA; exact absurd hA (by simp)
  · rw [hdir, hB] at hA; exact absurd hA (by simp)
  · -- P_to_V
    simp only [liftM_bind, liftM_pure, liftAppendRight_liftM, map_bind, map_pure]
    have hMsgIdx : (pSpec₁ ++ₚ pSpec₂).Message
          (⟨Fin.natAdd m l, hA⟩ : MessageIdx (pSpec₁ ++ₚ pSpec₂))
        = pSpec₂.Message ⟨l, hB⟩ := append_Type_natAdd _
    have hPairIn : ((pSpec₁ ++ₚ pSpec₂).Message
          (⟨Fin.natAdd m l, hA⟩ : MessageIdx (pSpec₁ ++ₚ pSpec₂))
          × (P₁.append P₂).PrvState (Fin.natAdd m l).succ)
        = (pSpec₂.Message ⟨l, hB⟩ × P₂.PrvState l.succ) :=
      congrArg₂ Prod hMsgIdx hStS
    refine heq_bind hPairIn (congrArg₂ Prod rfl hStS) ?_ ?_
    · exact heq_liftM hPairIn
        (append_sendMessage_right' (Fin.natAdd m l) l hil hl hA hB st st₂ hst)
    · refine heq_funext hPairIn (congrArg _ (congrArg₂ Prod rfl hStS)) ?_
      intro x x' hx
      refine heq_pure (congrArg₂ Prod rfl hStS) ?_
      refine heq_prod rfl hStS ?_ (heq_snd hMsgIdx hStS hx)
      exact heq_of_eq (concatLR_step (Fin.natAdd m l) l (by simp) tr₁ tr₂ x.1 x'.1
        (heq_fst hMsgIdx hStS hx) hkl hkl')

/-! ### `processRound` at the seam -/

/-- **The seam round.** The appended prover's round `m` is the second prover's round `0`, lifted,
started from the state `P₂.input` produces from `P₁`'s output. This is the only round lemma that
needs `P₁.output` to be pure — see `Prover.append_run`'s docstring for why. -/
private theorem append_processRound_seam_pure_input (hjlt : m < m + n) (hn : 0 < n)
    (outputFn : P₁.PrvState (Fin.last m) → Stmt₂ × Wit₂)
    (hOutput : P₁.output = fun st => pure (outputFn st))
    (tr : (pSpec₁ ++ₚ pSpec₂).Transcript (⟨m, hjlt⟩ : Fin (m + n)).castSucc)
    (tr₁ : pSpec₁.FullTranscript) (htr : HEq tr tr₁)
    (st : (P₁.append P₂).PrvState (⟨m, hjlt⟩ : Fin (m + n)).castSucc)
    (st₁ : P₁.PrvState (Fin.last m)) (hst : HEq st st₁)
    (hkl : ((⟨m, hjlt⟩ : Fin (m + n)).succ : Fin (m + n + 1)).val
      = m + ((⟨0, hn⟩ : Fin n).succ).val) :
    HEq ((P₁.append P₂).processRound ⟨m, hjlt⟩ (pure ⟨tr, st⟩))
        ((fun p => ((concatLR hkl tr₁ p.1 :
              (pSpec₁ ++ₚ pSpec₂).Transcript (⟨m, hjlt⟩ : Fin (m + n)).succ), p.2)) <$>
          liftAppendRight pSpec₁
            (P₂.processRound ⟨0, hn⟩ (pure ⟨emptyTranscript hn, P₂.input (outputFn st₁)⟩))) := by
  have hdir : Fin.vappend pSpec₁.dir pSpec₂.dir ⟨m, hjlt⟩ = pSpec₂.dir ⟨0, hn⟩ := by
    rw [Fin.vappend_right_of_not_lt _ _ _ (show ¬ m < m by omega)]
    congr 1
    exact Fin.ext (show m - m = 0 by omega)
  have hMsg : (pSpec₁ ++ₚ pSpec₂).«Type» (⟨m, hjlt⟩ : Fin (m + n)) = pSpec₂.«Type» ⟨0, hn⟩ :=
    (append_Type_ge (⟨m, hjlt⟩ : Fin (m + n)) (show m - m < n by omega)
      (show m ≤ m by omega)).trans (congrArg pSpec₂.«Type» (Fin.ext (show m - m = 0 by omega)))
  have hStS : (P₁.append P₂).PrvState (⟨m, hjlt⟩ : Fin (m + n)).succ
      = P₂.PrvState (⟨0, hn⟩ : Fin n).succ :=
    Prover.append_prvState_right _ _ (show m < m + 1 by omega) (show m + 1 = m + (0 + 1) by omega)
  have hβ : (((pSpec₁ ++ₚ pSpec₂).Transcript (⟨m, hjlt⟩ : Fin (m + n)).succ)
        × (P₁.append P₂).PrvState (⟨m, hjlt⟩ : Fin (m + n)).succ)
      = (((pSpec₁ ++ₚ pSpec₂).Transcript (⟨m, hjlt⟩ : Fin (m + n)).succ)
        × P₂.PrvState (⟨0, hn⟩ : Fin n).succ) := congrArg₂ Prod rfl hStS
  unfold Prover.processRound liftAppendRight
  simp only [pure_bind]
  split <;> rename_i hA <;> split <;> rename_i hB
  · -- V_to_P
    simp only [liftM_bind, liftM_pure, liftAppendRight_liftM, liftAppendRight_getChallenge,
      map_bind, map_pure, bind_map_left]
    have hChal : (pSpec₁ ++ₚ pSpec₂).Challenge
          (⟨⟨m, hjlt⟩, hA⟩ : ChallengeIdx (pSpec₁ ++ₚ pSpec₂))
        = pSpec₂.Challenge ⟨⟨0, hn⟩, hB⟩ := hMsg
    have hFun : ((pSpec₁ ++ₚ pSpec₂).Challenge
          (⟨⟨m, hjlt⟩, hA⟩ : ChallengeIdx (pSpec₁ ++ₚ pSpec₂))
          → (P₁.append P₂).PrvState (⟨m, hjlt⟩ : Fin (m + n)).succ)
        = (pSpec₂.Challenge ⟨⟨0, hn⟩, hB⟩ → P₂.PrvState (⟨0, hn⟩ : Fin n).succ) :=
      congrArg₂ (fun X Y => X → Y) hChal hStS
    refine heq_bind rfl hβ HEq.rfl ?_
    refine heq_funext rfl (congrArg _ hβ) ?_
    intro c c' hc
    obtain rfl := eq_of_heq hc
    refine heq_bind hFun hβ ?_ ?_
    · exact heq_liftM hFun
        (append_receiveChallenge_seam ⟨m, hjlt⟩ rfl hn outputFn hOutput hA hB st st₁ hst)
    · refine heq_funext hFun (congrArg _ hβ) ?_
      intro f f' hf
      refine heq_pure hβ ?_
      refine heq_prod rfl hStS ?_ (heq_apply hChal hStS hf (cast_heq hChal c).symm)
      exact heq_of_eq (concatLR_seam hjlt hn tr tr₁ htr c (cast hChal c)
        (cast_heq hChal c).symm hkl)
  · rw [hdir, hB] at hA; exact absurd hA (by simp)
  · rw [hdir, hB] at hA; exact absurd hA (by simp)
  · -- P_to_V
    simp only [liftM_bind, liftM_pure, liftAppendRight_liftM, map_bind, map_pure]
    have hMsgIdx : (pSpec₁ ++ₚ pSpec₂).Message
          (⟨⟨m, hjlt⟩, hA⟩ : MessageIdx (pSpec₁ ++ₚ pSpec₂))
        = pSpec₂.Message ⟨⟨0, hn⟩, hB⟩ := hMsg
    have hα : ((pSpec₁ ++ₚ pSpec₂).Message (⟨⟨m, hjlt⟩, hA⟩ : MessageIdx (pSpec₁ ++ₚ pSpec₂))
          × (P₁.append P₂).PrvState (⟨m, hjlt⟩ : Fin (m + n)).succ)
        = (pSpec₂.Message ⟨⟨0, hn⟩, hB⟩ × P₂.PrvState (⟨0, hn⟩ : Fin n).succ) :=
      congrArg₂ Prod hMsgIdx hStS
    refine heq_bind hα hβ ?_ ?_
    · exact heq_liftM hα
        (by simpa only [hOutput, pure_bind] using
          append_sendMessage_seam ⟨m, hjlt⟩ rfl hn hA hB st st₁ hst)
    · refine heq_funext hα (congrArg _ hβ) ?_
      intro x x' hx
      refine heq_pure hβ ?_
      refine heq_prod rfl hStS ?_ (heq_snd hMsgIdx hStS hx)
      exact heq_of_eq (concatLR_seam hjlt hn tr tr₁ htr x.1 x'.1
        (heq_fst hMsgIdx hStS hx) hkl)

/-- The seam factors through an effectful output if it starts with a message, or if the
left output is pure. -/
private theorem append_processRound_seam (hjlt : m < m + n) (hn : 0 < n)
    (hSeam : P₁.OutputIsPure ∨ pSpec₂.dir ⟨0, hn⟩ = .P_to_V)
    (tr : (pSpec₁ ++ₚ pSpec₂).Transcript (⟨m, hjlt⟩ : Fin (m + n)).castSucc)
    (tr₁ : pSpec₁.FullTranscript) (htr : HEq tr tr₁)
    (st : (P₁.append P₂).PrvState (⟨m, hjlt⟩ : Fin (m + n)).castSucc)
    (st₁ : P₁.PrvState (Fin.last m)) (hst : HEq st st₁)
    (hkl : ((⟨m, hjlt⟩ : Fin (m + n)).succ : Fin (m + n + 1)).val
      = m + ((⟨0, hn⟩ : Fin n).succ).val) :
    HEq ((P₁.append P₂).processRound ⟨m, hjlt⟩ (pure ⟨tr, st⟩))
        ((liftM (P₁.output st₁) :
            OracleComp (oSpec + [(pSpec₁ ++ₚ pSpec₂).Challenge]ₒ) (Stmt₂ × Wit₂)) >>= fun ctx =>
          (fun p => ((concatLR hkl tr₁ p.1 :
              (pSpec₁ ++ₚ pSpec₂).Transcript (⟨m, hjlt⟩ : Fin (m + n)).succ), p.2)) <$>
          liftAppendRight pSpec₁
            (P₂.processRound ⟨0, hn⟩ (pure ⟨emptyTranscript hn, P₂.input ctx⟩))) := by
  rcases hSeam with hPure | hFirst
  · obtain ⟨outputFn, hOutputPt⟩ := hPure.output_is_pure
    have hOutput : P₁.output = fun st => pure (outputFn st) := funext hOutputPt
    simpa only [hOutput, liftM_pure, pure_bind] using
      append_processRound_seam_pure_input hjlt hn outputFn hOutput tr tr₁ htr st st₁ hst hkl
  · have hdir : Fin.vappend pSpec₁.dir pSpec₂.dir ⟨m, hjlt⟩ = pSpec₂.dir ⟨0, hn⟩ := by
      rw [Fin.vappend_right_of_not_lt _ _ _ (show ¬ m < m by omega)]
      congr 1
      exact Fin.ext (show m - m = 0 by omega)
    have hMsg : (pSpec₁ ++ₚ pSpec₂).«Type» (⟨m, hjlt⟩ : Fin (m + n)) = pSpec₂.«Type» ⟨0, hn⟩ :=
      (append_Type_ge (⟨m, hjlt⟩ : Fin (m + n)) (show m - m < n by omega)
        (show m ≤ m by omega)).trans (congrArg pSpec₂.«Type» (Fin.ext (show m - m = 0 by omega)))
    have hStS : (P₁.append P₂).PrvState (⟨m, hjlt⟩ : Fin (m + n)).succ
        = P₂.PrvState (⟨0, hn⟩ : Fin n).succ :=
      Prover.append_prvState_right _ _ (show m < m + 1 by omega) (show m + 1 = m + (0 + 1) by omega)
    have hβ : (((pSpec₁ ++ₚ pSpec₂).Transcript (⟨m, hjlt⟩ : Fin (m + n)).succ)
          × (P₁.append P₂).PrvState (⟨m, hjlt⟩ : Fin (m + n)).succ)
        = (((pSpec₁ ++ₚ pSpec₂).Transcript (⟨m, hjlt⟩ : Fin (m + n)).succ)
          × P₂.PrvState (⟨0, hn⟩ : Fin n).succ) := congrArg₂ Prod rfl hStS
    have hFirstA : (pSpec₁ ++ₚ pSpec₂).dir ⟨m, hjlt⟩ = .P_to_V := hdir.trans hFirst
    unfold Prover.processRound liftAppendRight
    simp only [pure_bind]
    split <;> rename_i hA <;> split <;> rename_i hB
    all_goals try { rw [hdir, hFirst] at hA; contradiction }
    all_goals try { rw [hFirst] at hB; contradiction }
    simp only [liftM_bind, liftM_pure, liftAppendRight_liftM, map_bind, map_pure]
    have hMsgIdx : (pSpec₁ ++ₚ pSpec₂).Message
          (⟨⟨m, hjlt⟩, hFirstA⟩ : MessageIdx (pSpec₁ ++ₚ pSpec₂))
        = pSpec₂.Message ⟨⟨0, hn⟩, hFirst⟩ := hMsg
    have hα : ((pSpec₁ ++ₚ pSpec₂).Message
          (⟨⟨m, hjlt⟩, hFirstA⟩ : MessageIdx (pSpec₁ ++ₚ pSpec₂))
          × (P₁.append P₂).PrvState (⟨m, hjlt⟩ : Fin (m + n)).succ)
        = (pSpec₂.Message ⟨⟨0, hn⟩, hFirst⟩ × P₂.PrvState (⟨0, hn⟩ : Fin n).succ) :=
      congrArg₂ Prod hMsgIdx hStS
    have hSend := heq_liftM (superSpec := oSpec + [(pSpec₁ ++ₚ pSpec₂).Challenge]ₒ) hα
      (append_sendMessage_seam ⟨m, hjlt⟩ rfl hn hFirstA hFirst st st₁ hst)
    simp only [liftM_bind] at hSend
    refine HEq.trans (heq_bind hα hβ hSend
      (f' := fun x => pure (concatLR hkl tr₁ (Transcript.concat x.1 (emptyTranscript hn)),
        x.2)) ?_) ?_
    · refine heq_funext hα (congrArg _ hβ) ?_
      intro x x' hx
      refine heq_pure hβ ?_
      refine heq_prod rfl hStS ?_ (heq_snd hMsgIdx hStS hx)
      exact heq_of_eq (concatLR_seam hjlt hn tr tr₁ htr x.1 x'.1
        (heq_fst hMsgIdx hStS hx) hkl)
    · exact heq_of_eq (bind_assoc _ _ _)

/-! ### Running past the seam -/

/-- `runToRound` at a successor index is the previous run followed by one `processRound`. -/
private theorem runToRound_succ_bind {N : ℕ} {pSpec : ProtocolSpec N}
    (P : Prover oSpec Stmt₁ Wit₁ Stmt₂ Wit₂ pSpec) (j : Fin N) (stmt : Stmt₁) (wit : Wit₁) :
    P.runToRound j.succ stmt wit
      = P.runToRound j.castSucc stmt wit >>= fun x => P.processRound j (pure x) := by
  rw [Prover.runToRound_succ, processRound_eq_bind]

/-- Running to round `0` just applies `input` to the initial context. -/
private theorem runToRound_castSucc_zero (hl : 0 < n) (s : Stmt₂) (w : Wit₂) :
    P₂.runToRound ((⟨0, hl⟩ : Fin n).castSucc) s w
      = pure ⟨emptyTranscript hl, P₂.input (s, w)⟩ := rfl


/-- The un-glued right-hand run: the left half's result paired with the second prover's
partial run.  Gluing is applied by an outer `map`, which is what makes the induction compose. -/
private def rightRun
    (stmt : Stmt₁) (wit : Wit₁) (l : Fin (n + 1)) :
    OracleComp (oSpec + [(pSpec₁ ++ₚ pSpec₂).Challenge]ₒ)
      (pSpec₁.FullTranscript × (pSpec₂.Transcript l × P₂.PrvState l)) := do
  let p₁ ← liftAppendLeft pSpec₂ (P₁.runToRound (Fin.last m) stmt wit)
  let ctx ← (liftM (P₁.output p₁.2) :
    OracleComp (oSpec + [(pSpec₁ ++ₚ pSpec₂).Challenge]ₒ) (Stmt₂ × Wit₂))
  let p₂ ← liftAppendRight pSpec₁ (P₂.runToRound l ctx.1 ctx.2)
  pure (p₁.1, p₂)

/-- **Running past the seam.** Up to round `m + l'` (for `l' > 0`), running the appended prover is
the full left run followed by the second prover's run to round `l'`, with the two transcripts glued
by `concatLR`. Induction on `l`, with `append_processRound_seam` as the base case and
`append_processRound_right_pure_input` as the step. -/
private theorem append_runToRound_right (hn : 0 < n)
    (hSeam : P₁.OutputIsPure ∨ pSpec₂.dir ⟨0, hn⟩ = .P_to_V)
    (stmt : Stmt₁) (wit : Wit₁) :
    ∀ (l : ℕ) (_hl : l < n) (k : Fin (m + n + 1)) (l' : Fin (n + 1))
      (hkl : k.val = m + l'.val) (_hl' : l'.val = l + 1),
      HEq ((P₁.append P₂).runToRound k stmt wit)
          ((fun q : pSpec₁.FullTranscript × (pSpec₂.Transcript l' × P₂.PrvState l') =>
              ((concatLR hkl q.1 q.2.1 : (pSpec₁ ++ₚ pSpec₂).Transcript k), q.2.2))
            <$> rightRun (P₁ := P₁) (P₂ := P₂) stmt wit l') := by
  intro l
  induction l with
  | zero =>
    intro hl k l' hkl hl'
    obtain rfl : l' = (⟨0, hl⟩ : Fin n).succ := Fin.ext (by simpa using hl')
    have hjlt : m < m + n := Nat.lt_add_of_pos_right hn
    obtain rfl : k = (⟨m, hjlt⟩ : Fin (m + n)).succ := Fin.ext (by simpa using hkl)
    have hStS : (P₁.append P₂).PrvState (⟨m, hjlt⟩ : Fin (m + n)).succ
        = P₂.PrvState (⟨0, hl⟩ : Fin n).succ :=
      Prover.append_prvState_right _ _ (show m < m + 1 by omega) (show m + 1 = m + (0 + 1) by omega)
    have hβ : (((pSpec₁ ++ₚ pSpec₂).Transcript (⟨m, hjlt⟩ : Fin (m + n)).succ)
          × (P₁.append P₂).PrvState (⟨m, hjlt⟩ : Fin (m + n)).succ)
        = (((pSpec₁ ++ₚ pSpec₂).Transcript (⟨m, hjlt⟩ : Fin (m + n)).succ)
          × P₂.PrvState (⟨0, hl⟩ : Fin n).succ) := congrArg₂ Prod rfl hStS
    unfold rightRun
    simp only [Prover.runToRound_succ, runToRound_castSucc_zero, map_bind, map_pure]
    rw [processRound_eq_bind]
    refine heq_bind (payload_left_eq _ (Fin.last m) (by simp)) hβ
      (append_runToRound_left stmt wit (Fin.last m) _ (by simp)) ?_
    refine heq_funext (payload_left_eq _ (Fin.last m) (by simp)) (congrArg _ hβ) ?_
    intro x p₁ hx
    refine HEq.trans (append_processRound_seam hjlt hl hSeam x.1 p₁.1
      (heq_fst (transcript_left_type_eq _ (Fin.last m) (by simp))
        (Prover.append_prvState_left _ (Fin.last m) (by simp)) hx) x.2 p₁.2
      (heq_snd (transcript_left_type_eq _ (Fin.last m) (by simp))
        (Prover.append_prvState_left _ (Fin.last m) (by simp)) hx) hkl) ?_
    refine heq_of_eq ?_
    simp only [map_eq_bind_pure_comp]
    rfl
  | succ l ih =>
    intro hl k l' hkl hl'
    obtain rfl : l' = (⟨l + 1, hl⟩ : Fin n).succ := Fin.ext (by simpa using hl')
    have hlt' : l < n := by omega
    obtain rfl : k = (Fin.natAdd m (⟨l + 1, hl⟩ : Fin n)).succ :=
      Fin.ext (show k.val = m + (l + 1) + 1 by omega)
    have hkl' : ((Fin.natAdd m (⟨l + 1, hl⟩ : Fin n)).castSucc : Fin (m + n + 1)).val
        = m + ((⟨l + 1, hl⟩ : Fin n).castSucc : Fin (n + 1)).val := rfl
    have hStS : (P₁.append P₂).PrvState (Fin.natAdd m (⟨l + 1, hl⟩ : Fin n)).castSucc
        = P₂.PrvState ((⟨l + 1, hl⟩ : Fin n).castSucc) :=
      Prover.append_prvState_right _ _ (show m < m + (l + 1) by omega)
        (show m + (l + 1) = m + (l + 1) by omega)
    have hα : (((pSpec₁ ++ₚ pSpec₂).Transcript
            (Fin.natAdd m (⟨l + 1, hl⟩ : Fin n)).castSucc)
          × (P₁.append P₂).PrvState (Fin.natAdd m (⟨l + 1, hl⟩ : Fin n)).castSucc)
        = (((pSpec₁ ++ₚ pSpec₂).Transcript (Fin.natAdd m (⟨l + 1, hl⟩ : Fin n)).castSucc)
          × P₂.PrvState ((⟨l + 1, hl⟩ : Fin n).castSucc)) := congrArg₂ Prod rfl hStS
    have hf : HEq (fun x => (P₁.append P₂).processRound (Fin.natAdd m (⟨l + 1, hl⟩ : Fin n))
          (pure x))
        (fun x' : ((pSpec₁ ++ₚ pSpec₂).Transcript
              (Fin.natAdd m (⟨l + 1, hl⟩ : Fin n)).castSucc
            × P₂.PrvState ((⟨l + 1, hl⟩ : Fin n).castSucc)) =>
          (P₁.append P₂).processRound (Fin.natAdd m (⟨l + 1, hl⟩ : Fin n))
            (pure (x'.1, cast hStS.symm x'.2))) := by
      refine heq_funext hα rfl ?_
      intro x x' hx
      have h1 : x.1 = x'.1 := eq_of_heq (heq_fst rfl hStS hx)
      have h2 : x.2 = cast hStS.symm x'.2 :=
        eq_of_heq ((heq_snd rfl hStS hx).trans (cast_heq hStS.symm x'.2).symm)
      refine heq_of_eq (congrArg _ (congrArg _ ?_))
      rw [← h1, ← h2]
    rw [Prover.runToRound_succ, processRound_eq_bind]
    refine HEq.trans
      (heq_bind hα rfl (ih hlt' _ ((⟨l + 1, hl⟩ : Fin n).castSucc) hkl' (by simp)) hf) ?_
    have hStS' : (P₁.append P₂).PrvState (Fin.natAdd m (⟨l + 1, hl⟩ : Fin n)).succ
        = P₂.PrvState ((⟨l + 1, hl⟩ : Fin n).succ) :=
      Prover.append_prvState_right _ _ (show m < m + (l + 1) + 1 by omega)
        (show m + (l + 1) + 1 = m + (l + 1 + 1) by omega)
    have hβ' : (((pSpec₁ ++ₚ pSpec₂).Transcript
            (Fin.natAdd m (⟨l + 1, hl⟩ : Fin n)).succ)
          × (P₁.append P₂).PrvState (Fin.natAdd m (⟨l + 1, hl⟩ : Fin n)).succ)
        = (((pSpec₁ ++ₚ pSpec₂).Transcript (Fin.natAdd m (⟨l + 1, hl⟩ : Fin n)).succ)
          × P₂.PrvState ((⟨l + 1, hl⟩ : Fin n).succ)) := congrArg₂ Prod rfl hStS'
    have hstep : HEq
        (fun q : pSpec₁.FullTranscript × (pSpec₂.Transcript ((⟨l + 1, hl⟩ : Fin n).castSucc)
            × P₂.PrvState ((⟨l + 1, hl⟩ : Fin n).castSucc)) =>
          (P₁.append P₂).processRound (Fin.natAdd m (⟨l + 1, hl⟩ : Fin n))
            (pure (concatLR hkl' q.1 q.2.1, cast hStS.symm q.2.2)))
        (fun q : pSpec₁.FullTranscript × (pSpec₂.Transcript ((⟨l + 1, hl⟩ : Fin n).castSucc)
            × P₂.PrvState ((⟨l + 1, hl⟩ : Fin n).castSucc)) =>
          ((fun p => ((concatLR hkl q.1 p.1 : (pSpec₁ ++ₚ pSpec₂).Transcript
                (Fin.natAdd m (⟨l + 1, hl⟩ : Fin n)).succ), p.2)) <$>
            liftAppendRight pSpec₁
              (P₂.processRound (⟨l + 1, hl⟩ : Fin n) (pure q.2)))) := by
      refine heq_funext rfl (congrArg _ hβ') ?_
      intro q q' hq
      obtain rfl := eq_of_heq hq
      exact append_processRound_right_pure_input (⟨l + 1, hl⟩ : Fin n) (Nat.succ_pos l) q.1 q.2.1
        (cast hStS.symm q.2.2) q.2.2 (cast_heq _ _) rfl rfl
    simp only [bind_map_left]
    refine HEq.trans (heq_bind rfl hβ' HEq.rfl hstep) ?_
    refine heq_of_eq ?_
    simp only [rightRun, runToRound_succ_bind, liftM_bind, bind_assoc,
      map_eq_bind_pure_comp, pure_bind]
    rfl

/-! ### Output, and the final transcript identity -/

/-- At the final index, `concatLR` is the full-transcript append `++ₜ`. -/
private theorem concatLR_last (hkl : (Fin.last (m + n)).val = m + (Fin.last n).val)
    (tr₁ : pSpec₁.FullTranscript) (tr₂ : pSpec₂.FullTranscript) :
    concatLR hkl tr₁ tr₂ = tr₁ ++ₜ tr₂ := by
  funext i
  refine eq_of_heq ?_
  rcases Nat.lt_or_ge i.val m with h | h
  · refine (concatLR_apply_lt hkl tr₁ tr₂ i h).trans ?_
    exact (Fin.happend_heq_left tr₁ tr₂ ⟨i.val, by have := i.isLt; omega⟩ h).symm
  · refine (concatLR_apply_ge hkl tr₁ tr₂ i (show ¬ i.val < m by omega)
      (show i.val - m < n by have := i.isLt; omega)).trans ?_
    exact (Fin.happend_heq_right tr₁ tr₂ ⟨i.val, by have := i.isLt; omega⟩
      (show ¬ i.val < m by omega)).symm

/-! ### Assembly -/

/-- `Prover.append_run` for a non-empty second protocol: `append_runToRound_right` at `l' = n`,
followed by the output step (`Prover.append_output_pos`). -/
private theorem append_run_pos (hn : 0 < n)
    (hSeam : P₁.OutputIsPure ∨ pSpec₂.dir ⟨0, hn⟩ = .P_to_V)
    (stmt : Stmt₁) (wit : Wit₁) :
    (P₁.append P₂).run stmt wit
      = (rightRun (P₁ := P₁) (P₂ := P₂) stmt wit (Fin.last n) >>= fun q =>
          ((liftM (P₂.output q.2.2) :
              OracleComp (oSpec + [(pSpec₁ ++ₚ pSpec₂).Challenge]ₒ) (Stmt₃ × Wit₃))
            >>= fun ctx =>
            pure ((q.1 ++ₜ q.2.1 : (pSpec₁ ++ₚ pSpec₂).FullTranscript), ctx))) := by
  have hkl : (Fin.last (m + n)).val = m + (Fin.last n).val := by simp
  have hStS : (P₁.append P₂).PrvState (Fin.last (m + n)) = P₂.PrvState (Fin.last n) :=
    Prover.append_prvState_right _ _ (by simp; omega) (by simp)
  have hα : (((pSpec₁ ++ₚ pSpec₂).Transcript (Fin.last (m + n)))
        × (P₁.append P₂).PrvState (Fin.last (m + n)))
      = (((pSpec₁ ++ₚ pSpec₂).Transcript (Fin.last (m + n))) × P₂.PrvState (Fin.last n)) :=
    congrArg₂ Prod rfl hStS
  have key := append_runToRound_right (P₁ := P₁) (P₂ := P₂) hn hSeam stmt wit
    (n - 1) (by omega)
    (Fin.last (m + n)) (Fin.last n) hkl (by simp; omega)
  have hf : HEq
      (fun p : ((pSpec₁ ++ₚ pSpec₂).Transcript (Fin.last (m + n))
          × (P₁.append P₂).PrvState (Fin.last (m + n))) =>
        ((liftM ((P₁.append P₂).output p.2) :
            OracleComp (oSpec + [(pSpec₁ ++ₚ pSpec₂).Challenge]ₒ) (Stmt₃ × Wit₃))
          >>= fun ctx => pure ((p.1 : (pSpec₁ ++ₚ pSpec₂).FullTranscript), ctx)))
      (fun p : ((pSpec₁ ++ₚ pSpec₂).Transcript (Fin.last (m + n))
          × P₂.PrvState (Fin.last n)) =>
        ((liftM (P₂.output p.2) :
            OracleComp (oSpec + [(pSpec₁ ++ₚ pSpec₂).Challenge]ₒ) (Stmt₃ × Wit₃))
          >>= fun ctx => pure ((p.1 : (pSpec₁ ++ₚ pSpec₂).FullTranscript), ctx))) := by
    refine heq_funext hα rfl ?_
    intro p p' hp
    refine heq_of_eq ?_
    have h1 : p.1 = p'.1 := eq_of_heq (heq_fst rfl hStS hp)
    have h2 : (P₁.append P₂).output p.2 = P₂.output p'.2 :=
      Prover.append_output_pos (by omega) p.2 p'.2 (heq_snd rfl hStS hp)
    rw [h1, h2]
  refine eq_of_heq ?_
  unfold Prover.run
  refine HEq.trans (heq_bind hα rfl key hf) ?_
  refine HEq.trans (heq_of_eq (bind_map_left _ _ _)) (heq_of_eq ?_)
  congr 1
  funext q
  refine congrArg (fun t => liftM (P₂.output q.2.2) >>= fun ctx => pure (t, ctx)) ?_
  exact concatLR_last hkl q.1 q.2.1

/-- For an empty protocol, running to the last round just applies `input`. -/
private theorem runToRound_last_zero {pSpec : ProtocolSpec 0}
    (P : Prover oSpec Stmt₂ Wit₂ Stmt₃ Wit₃ pSpec) (s : Stmt₂) (w : Wit₂) :
    P.runToRound (Fin.last 0) s w = pure ⟨fun z => Fin.elim0 z, P.input (s, w)⟩ := rfl

/-- Appending an empty transcript on the right changes nothing. -/
private theorem heq_append_nil (hn : n = 0) (tr₁ : pSpec₁.FullTranscript)
    (tr₂ : pSpec₂.FullTranscript) :
    HEq ((tr₁ ++ₜ tr₂ : (pSpec₁ ++ₚ pSpec₂).FullTranscript)) tr₁ := by
  subst hn
  refine heq_pi (transcript_family_left (pSpec₁ := pSpec₁) (pSpec₂ := pSpec₂) m
    (le_refl m) (by omega)) ?_
  intro i
  exact Fin.happend_heq_left tr₁ tr₂ i (by have := i.isLt; omega)

end AppendRunHelpers

namespace Prover

variable {P₁ : Prover oSpec Stmt₁ Wit₁ Stmt₂ Wit₂ pSpec₁}
    {P₂ : Prover oSpec Stmt₂ Wit₂ Stmt₃ Wit₃ pSpec₂}
    {stmt : Stmt₁} {wit : Wit₁}

/-- Running an appended prover equals its two component runs with concatenated transcripts
if the left output is pure, the right protocol is empty, or the right protocol starts with a
prover message. Later rounds may have either direction. -/
theorem append_run_of_seam
    (hSeam : ∀ hn : 0 < n, P₁.OutputIsPure ∨ pSpec₂.dir ⟨0, hn⟩ = .P_to_V)
    (stmt : Stmt₁) (wit : Wit₁) :
    (P₁.append P₂).run stmt wit = (do
      let ⟨transcript₁, stmt₂, wit₂⟩ ← liftAppendLeft pSpec₂ (P₁.run stmt wit)
      let ⟨transcript₂, stmt₃, wit₃⟩ ← liftAppendRight pSpec₁ (P₂.run stmt₂ wit₂)
      return ⟨transcript₁ ++ₜ transcript₂, stmt₃, wit₃⟩) := by
  rcases Nat.eq_zero_or_pos n with hn | hn
  · subst hn
    have hStS : (P₁.append P₂).PrvState (Fin.last (m + 0)) = P₁.PrvState (Fin.last m) :=
      Prover.append_prvState_left _ _ (by simp)
    have hTr : (pSpec₁ ++ₚ pSpec₂).Transcript (Fin.last (m + 0))
        = pSpec₁.Transcript (Fin.last m) := transcript_left_type_eq _ _ (by simp)
    have hα : (((pSpec₁ ++ₚ pSpec₂).Transcript (Fin.last (m + 0)))
          × (P₁.append P₂).PrvState (Fin.last (m + 0)))
        = (pSpec₁.Transcript (Fin.last m) × P₁.PrvState (Fin.last m)) :=
      congrArg₂ Prod hTr hStS
    have key := append_runToRound_left (P₁ := P₁) (P₂ := P₂) stmt wit (Fin.last m)
      (Fin.last (m + 0)) (by simp)
    have hf : HEq
        (fun p : ((pSpec₁ ++ₚ pSpec₂).Transcript (Fin.last (m + 0))
            × (P₁.append P₂).PrvState (Fin.last (m + 0))) =>
          ((liftM ((P₁.append P₂).output p.2) :
              OracleComp (oSpec + [(pSpec₁ ++ₚ pSpec₂).Challenge]ₒ) (Stmt₃ × Wit₃))
            >>= fun ctx => pure ((p.1 : (pSpec₁ ++ₚ pSpec₂).FullTranscript), ctx)))
        (fun p : (pSpec₁.Transcript (Fin.last m) × P₁.PrvState (Fin.last m)) =>
          ((liftM (P₁.output p.2 >>= fun ctx =>
                P₂.output (dcast (by simp) (P₂.input ctx))) :
              OracleComp (oSpec + [(pSpec₁ ++ₚ pSpec₂).Challenge]ₒ) (Stmt₃ × Wit₃))
            >>= fun ctx => pure ((cast hTr.symm p.1 : (pSpec₁ ++ₚ pSpec₂).FullTranscript),
              ctx))) := by
      refine heq_funext hα rfl ?_
      intro p p' hp
      refine heq_of_eq ?_
      rw [Prover.append_output_zero rfl p.2 p'.2 (heq_snd hTr hStS hp),
        eq_of_heq ((heq_fst hTr hStS hp).trans (cast_heq hTr.symm p'.1).symm)]
      rfl
    refine eq_of_heq ?_
    unfold Prover.run
    refine HEq.trans (heq_bind hα rfl key hf) ?_
    refine heq_of_eq ?_
    simp only [liftM_bind, liftM_pure, liftAppendLeft_liftM, liftAppendRight_liftM, bind_assoc,
      pure_bind, runToRound_last_zero]
    refine bind_congr (fun p => ?_)
    refine bind_congr (fun ctx => ?_)
    have hd : (dcast (by simp) (P₂.input ctx) : P₂.PrvState (Fin.last 0))
        = P₂.input ctx := eq_of_heq (heq_dcast _ _)
    have hc : (cast hTr.symm p.1 : (pSpec₁ ++ₚ pSpec₂).FullTranscript)
        = p.1 ++ₜ (fun z => Fin.elim0 z) :=
      eq_of_heq ((cast_heq hTr.symm p.1).trans
        (heq_append_nil rfl p.1 (fun z => Fin.elim0 z)).symm)
    rw [hd, hc]
    rfl
  · rw [append_run_pos hn (hSeam hn) stmt wit]
    unfold rightRun Prover.run
    simp only [liftM_bind, liftM_pure, liftAppendLeft_liftM, liftAppendRight_liftM, bind_assoc,
      pure_bind]

/-- Running an appended prover factors into its component runs when the left output is pure.
For effectful outputs, `append_run_of_seam` also covers empty and message-opening protocols. -/
theorem append_run [hPure : P₁.OutputIsPure] (stmt : Stmt₁) (wit : Wit₁) :
    (P₁.append P₂).run stmt wit = (do
      let ⟨transcript₁, stmt₂, wit₂⟩ ← liftAppendLeft pSpec₂ (P₁.run stmt wit)
      let ⟨transcript₂, stmt₃, wit₃⟩ ← liftAppendRight pSpec₁ (P₂.run stmt₂ wit₂)
      return ⟨transcript₁ ++ₜ transcript₂, stmt₃, wit₃⟩) :=
  append_run_of_seam (fun _ => Or.inl hPure) stmt wit

end Prover

namespace Verifier

variable {V₁ : Verifier oSpec Stmt₁ Stmt₂ pSpec₁} {V₂ : Verifier oSpec Stmt₂ Stmt₃ pSpec₂}
  {stmt : Stmt₁}

/-- Running the sequential composition of two verifiers on a transcript of the combined protocol
  is equivalent to running the first verifier on the first part of the transcript, and the second
  verifier on the second part of the transcript, and returning the final statement. -/
theorem append_run (tr : (pSpec₁ ++ₚ pSpec₂).FullTranscript) :
    (V₁.append V₂).run stmt tr =
        (do
          let stmt₂ ← V₁.run stmt tr.fst
          let stmt₃ ← V₂.run stmt₂ tr.snd
          return stmt₃) := rfl

end Verifier

end Execution
