/-
Copyright (c) 2026 PolyFun Contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Quang Dao
-/
module

public import PolyFun.PFunctor.Basic
public import PolyFun.PFunctor.Equiv.Basic
import Batteries.Tactic.Lint

/-!
# Lenses between polynomial functors

Lenses map positions forward and directions backward. This module provides extensionality,
identity and composition, the action on polynomial objects, and canonical lenses for sums,
products, tensor, and substitution. Position and direction universes remain independent.
-/

@[expose] public section

universe u v uA uB uA₁ uB₁ uA₂ uB₂ uA₃ uB₃ uA₄ uB₄ uA₅ uB₅ uA₆ uB₆

section find_home

variable {α : Sort u} {β : α → Sort v} {γ : α → Sort v}

lemma heq_forall_iff (h : ∀ a, β a = γ a) {f : (a : α) → β a} {g : (a : α) → γ a} :
    f ≍ g ↔ ∀ a, (f a) ≍ (g a) := by
  have := funext h
  subst this
  aesop

end find_home

namespace PFunctor

/-- A **section** of an interface `p` is a lens `p ⟹ y` (the book's `p ⟹ y`),
equivalently a dependent section `(a : p.A) → p.B a` choosing a direction at every
position. Composing a section after a system's interface lens closes the system off
(Niu–Spivak §4.3.4); see `DynSystem.close`. -/
abbrev Section (p : PFunctor.{uA, uB}) : Type _ := Lens p y.{uA, uB}

namespace Lens

/-- Lenses agree when their position maps agree pointwise and their direction maps agree after
transport along those position equalities. -/
@[ext (iff := false)]
theorem ext {P : PFunctor.{uA₁, uB₁}} {Q : PFunctor.{uA₂, uB₂}} (l₁ l₂ : Lens P Q)
    (h₁ : ∀ a, l₁.toFunA a = l₂.toFunA a) (h₂ : ∀ a, l₁.toFunB a = (h₁ a) ▸ l₂.toFunB a) :
    l₁ = l₂ := by
  rcases l₁ with ⟨toFunA₁, _⟩
  rcases l₂ with ⟨toFunA₂, _⟩
  have h : toFunA₁ = toFunA₂ := funext h₁
  subst h
  simp_all only [mk.injEq, heq_eq_eq, true_and]
  simpa using funext h₂

/-- Heterogeneous extensionality for lenses: equal position maps and
heterogeneously equal direction maps identify two lenses. Useful when the
direction families are equal only after rewriting along the position map. -/
theorem ext_heq {P : PFunctor.{uA₁, uB₁}} {Q : PFunctor.{uA₂, uB₂}} (l₁ l₂ : Lens P Q)
    (hA : l₁.toFunA = l₂.toFunA) (hB : l₁.toFunB ≍ l₂.toFunB) : l₁ = l₂ := by
  cases l₁ with
  | mk a₁ b₁ =>
    cases l₂ with
    | mk a₂ b₂ =>
      dsimp only [Lens.toFunA, Lens.toFunB] at hA hB
      cases hA
      cases eq_of_heq hB
      rfl

/-- The identity lens -/
@[reducible]
protected def id (P : PFunctor.{uA, uB}) : Lens P P where
  toFunA := fun a => a
  toFunB := fun _ b => b

/-- Composition of lenses -/
def comp {P : PFunctor.{uA₁, uB₁}} {Q : PFunctor.{uA₂, uB₂}} {R : PFunctor.{uA₃, uB₃}}
    (l : Lens Q R) (l' : Lens P Q) : Lens P R where
  toFunA := l.toFunA ∘ l'.toFunA
  toFunB := fun i => (l'.toFunB i) ∘ l.toFunB (l'.toFunA i)

@[inherit_doc] scoped[PFunctor] infixl:75 " ∘ₗ " => PFunctor.Lens.comp

/-- Apply a polynomial lens to an element of the source polynomial's
extension. The position is sent forward and the payload is pulled back along
the lens's direction map. -/
def mapObj {P : PFunctor.{uA₁, uB₁}} {Q : PFunctor.{uA₂, uB₂}}
    (l : Lens P Q) {α : Type v} (x : P.Obj α) : Q.Obj α :=
  Obj.mk (l.toFunA x.fst) (x.snd ∘ l.toFunB x.fst)

@[simp]
theorem mapObj_id {P : PFunctor.{uA, uB}} {α : Type v}
    (x : P.Obj α) : mapObj (Lens.id P) x = x :=
  rfl

@[simp]
theorem mapObj_comp {P : PFunctor.{uA₁, uB₁}}
    {Q : PFunctor.{uA₂, uB₂}} {R : PFunctor.{uA₃, uB₃}}
    (g : Lens Q R) (f : Lens P Q) {α : Type v} (x : P.Obj α) :
    mapObj (g ∘ₗ f) x = mapObj g (mapObj f x) :=
  rfl

/-- Two lenses are equal when they act equally on every source position
equipped with its identity direction labelling. This packages the dependent
position equality and direction-map transport needed by `Lens.ext`. -/
theorem ext_mapObj {P : PFunctor.{uA₁, uB₁}} {Q : PFunctor.{uA₂, uB₂}} (l₁ l₂ : Lens P Q)
    (h : ∀ a, mapObj l₁ (Obj.mk a id : P.Obj (P.B a)) = mapObj l₂ (Obj.mk a id)) : l₁ = l₂ := by
  let hA : ∀ a, l₁.toFunA a = l₂.toFunA a :=
    fun a => congrArg Obj.fst (h a)
  refine Lens.ext _ _ hA ?_
  intro a
  apply eq_of_heq
  have hraw : l₁.toFunB a ≍ l₂.toFunB a :=
    (Sigma.ext_iff.mp (h a)).2
  have hcast : (hA a ▸ l₂.toFunB a) ≍ l₂.toFunB a :=
    eqRec_heq_self _ _
  exact hraw.trans hcast.symm

@[simp]
theorem id_comp {P : PFunctor.{uA₁, uB₁}} {Q : PFunctor.{uA₂, uB₂}} (f : Lens P Q) :
    (Lens.id Q) ∘ₗ f = f := rfl

@[simp]
theorem comp_id {P : PFunctor.{uA₁, uB₁}} {Q : PFunctor.{uA₂, uB₂}} (f : Lens P Q) :
    f ∘ₗ (Lens.id P) = f := rfl

theorem comp_assoc {P : PFunctor.{uA₁, uB₁}} {Q : PFunctor.{uA₂, uB₂}} {R : PFunctor.{uA₃, uB₃}}
    {S : PFunctor.{uA₄, uB₄}} (l : Lens R S) (l' : Lens Q R) (l'' : Lens P Q) :
    (l ∘ₗ l') ∘ₗ l'' = l ∘ₗ (l' ∘ₗ l'') := rfl

/-- An equivalence between two polynomial functors `P` and `Q`, using lenses.
    This corresponds to an isomorphism in the category `PFunctor` with `Lens` morphisms. -/
@[ext]
structure Equiv (P : PFunctor.{uA₁, uB₁}) (Q : PFunctor.{uA₂, uB₂}) where
  /-- The forward lens of the equivalence, from `P` to `Q`. -/
  toLens : Lens P Q
  /-- The backward lens of the equivalence, from `Q` to `P`. -/
  invLens : Lens Q P
  left_inv : comp invLens toLens = Lens.id P := by simp
  right_inv : comp toLens invLens = Lens.id Q := by simp

@[inherit_doc] scoped[PFunctor] infix:50 " ≃ₗ " => PFunctor.Lens.Equiv

namespace Equiv

/-- The identity equivalence on `P`, built from the identity lens in both directions. -/
@[refl, simps]
def refl (P : PFunctor.{uA, uB}) : P ≃ₗ P :=
  ⟨Lens.id P, Lens.id P, rfl, rfl⟩

/-- The inverse equivalence, swapping the forward and backward lenses of `e`. -/
@[symm, simps]
def symm {P : PFunctor.{uA₁, uB₁}} {Q : PFunctor.{uA₂, uB₂}} (e : P ≃ₗ Q) : Q ≃ₗ P :=
  ⟨e.invLens, e.toLens, e.right_inv, e.left_inv⟩

/-- The composite equivalence `P ≃ₗ R` obtained by chaining `e₁ : P ≃ₗ Q` and `e₂ : Q ≃ₗ R`. -/
@[trans, simps]
def trans {P : PFunctor.{uA₁, uB₁}} {Q : PFunctor.{uA₂, uB₂}} {R : PFunctor.{uA₃, uB₃}}
    (e₁ : P ≃ₗ Q) (e₂ : Q ≃ₗ R) : P ≃ₗ R :=
  ⟨e₂.toLens ∘ₗ e₁.toLens, e₁.invLens ∘ₗ e₂.invLens,
    by
      rw [comp_assoc]
      rw (occs := [2]) [← comp_assoc]
      simp [e₁.left_inv, e₂.left_inv],
    by
      rw [comp_assoc]
      rw (occs := [2]) [← comp_assoc]
      simp [e₁.right_inv, e₂.right_inv]⟩

/-- Lens equivalences compose in `calc` chains, across independent universes. -/
instance instTrans :
    @Trans PFunctor.{uA₁, uB₁} PFunctor.{uA₂, uB₂} PFunctor.{uA₃, uB₃}
      Lens.Equiv Lens.Equiv Lens.Equiv where
  trans := Equiv.trans

section Groupoid

variable {P : PFunctor.{uA₁, uB₁}} {Q : PFunctor.{uA₂, uB₂}} {R : PFunctor.{uA₃, uB₃}}
  {S : PFunctor.{uA₄, uB₄}}

/-- A lens equivalence is determined by its forward lens: inverses are unique. -/
theorem toLens_injective : Function.Injective (toLens : P ≃ₗ Q → Lens P Q) := by
  intro e f h
  have hinv : e.invLens = f.invLens := by
    calc
      e.invLens = e.invLens ∘ₗ (f.toLens ∘ₗ f.invLens) := by rw [f.right_inv]; rfl
      _ = (e.invLens ∘ₗ e.toLens) ∘ₗ f.invLens := by rw [h]; rfl
      _ = f.invLens := by rw [e.left_inv]; rfl
  exact Equiv.ext h hinv

@[simp] theorem symm_symm (e : P ≃ₗ Q) : e.symm.symm = e := rfl

@[simp] theorem refl_symm : (refl P).symm = refl P := rfl

@[simp] theorem trans_refl (e : P ≃ₗ Q) : e.trans (refl Q) = e := rfl

@[simp] theorem refl_trans (e : P ≃ₗ Q) : (refl P).trans e = e := rfl

theorem trans_assoc (e₁ : P ≃ₗ Q) (e₂ : Q ≃ₗ R) (e₃ : R ≃ₗ S) :
    (e₁.trans e₂).trans e₃ = e₁.trans (e₂.trans e₃) := rfl

@[simp] theorem symm_trans_self (e : P ≃ₗ Q) : e.symm.trans e = refl Q :=
  Equiv.ext e.right_inv e.right_inv

@[simp] theorem self_trans_symm (e : P ≃ₗ Q) : e.trans e.symm = refl P :=
  Equiv.ext e.left_inv e.left_inv

theorem symm_trans (e₁ : P ≃ₗ Q) (e₂ : Q ≃ₗ R) :
    (e₁.trans e₂).symm = e₂.symm.trans e₁.symm := rfl

end Groupoid

end Equiv

/-- Cancel postcomposition with the forward lens of a lens equivalence. -/
theorem cancel_toLens {P : PFunctor.{uA₁, uB₁}} {Q : PFunctor.{uA₂, uB₂}} {R : PFunctor.{uA₃, uB₃}}
    (e : P ≃ₗ Q) {f g : Lens R P} (h : e.toLens ∘ₗ f = e.toLens ∘ₗ g) : f = g := by
  calc
    f = e.invLens ∘ₗ (e.toLens ∘ₗ f) := by
      rw [← comp_assoc, e.left_inv, id_comp]
    _ = e.invLens ∘ₗ (e.toLens ∘ₗ g) :=
      congrArg (e.invLens ∘ₗ ·) h
    _ = g := by rw [← comp_assoc, e.left_inv, id_comp]

/-- The (unique) initial lens from the zero functor to any functor `P`. -/
def initial {P : PFunctor.{uA, uB}} : Lens 0 P :=
  PEmpty.elim ⇆ fun a => PEmpty.elim a

/-- The (unique) terminal lens from any functor `P` to the unit functor `1`. -/
def terminal {P : PFunctor.{uA, uB}} : Lens P 1 :=
  (fun _ => PUnit.unit) ⇆ fun _ => PEmpty.elim

alias fromZero := initial
alias toOne := terminal

/-- `0` is initial: `initial` is the only lens out of it. -/
instance uniqueFromZero {P : PFunctor.{uA, uB}} :
    Unique (Lens (0 : PFunctor.{uA₁, uB₁}) P) where
  default := initial
  uniq _ := Lens.ext _ _ (fun a => a.elim) fun a => a.elim

/-- `1` is terminal: `terminal` is the only lens into it. -/
instance uniqueToOne {P : PFunctor.{uA, uB}} :
    Unique (Lens P (1 : PFunctor.{uA₁, uB₁})) where
  default := terminal
  uniq _ := Lens.ext _ _ (fun _ => rfl) fun _ => funext fun d => d.elim

/-- Construct a lens from the variable polynomial by selecting a position. The
backward map is uniquely determined by the unit direction of `y`. -/
def fromY {P : PFunctor.{uA, uB}} (a : P.A) : Lens y.{uA₁, uB₁} P :=
  (fun _ => a) ⇆ fun _ _ => PUnit.unit

@[simp, grind =] theorem fromY_toFunA {P : PFunctor.{uA, uB}} (a : P.A) (u : PUnit) :
    (fromY a : Lens y.{uA₁, uB₁} P).toFunA u = a := rfl

@[simp, grind =] theorem fromY_toFunB {P : PFunctor.{uA, uB}} (a : P.A) (u : PUnit)
    (d : P.B a) :
    (fromY a : Lens y.{uA₁, uB₁} P).toFunB u d = PUnit.unit := rfl

@[deprecated (since := "2026-08-17")] alias fromX := fromY
@[deprecated (since := "2026-08-17")] alias fromX_toFunA := fromY_toFunA
@[deprecated (since := "2026-08-17")] alias fromX_toFunB := fromY_toFunB

/-- Construct a lens into a constant polynomial from its position map. The
backward map is uniquely determined by the empty direction type. -/
def toConst {P : PFunctor.{uA, uB}} {A : Type uA₂} (f : P.A → A) :
    Lens P (C A : PFunctor.{uA₂, uB₁}) :=
  f ⇆ fun _ => PEmpty.elim

@[simp, grind =] theorem toConst_toFunA {P : PFunctor.{uA, uB}} {A : Type uA₂}
    (f : P.A → A) (a : P.A) :
    (toConst f : Lens P (C A : PFunctor.{uA₂, uB₁})).toFunA a = f a := rfl

/-- Construct a lens into a linear polynomial from a position map and a choice
of source direction over every position. -/
def toLinear {P : PFunctor.{uA, uB}} {A : Type uA₂}
    (f : P.A → A) (choose : (a : P.A) → P.B a) :
    Lens P (linear A : PFunctor.{uA₂, uB₁}) :=
  f ⇆ fun a _ => choose a

@[simp, grind =] theorem toLinear_toFunA {P : PFunctor.{uA, uB}} {A : Type uA₂}
    (f : P.A → A) (choose : (a : P.A) → P.B a) (a : P.A) :
    (toLinear f choose : Lens P (linear A : PFunctor.{uA₂, uB₁})).toFunA a = f a := rfl

@[simp, grind =] theorem toLinear_toFunB {P : PFunctor.{uA, uB}} {A : Type uA₂}
    (f : P.A → A) (choose : (a : P.A) → P.B a) (a : P.A) (u : PUnit) :
    (toLinear f choose : Lens P (linear A : PFunctor.{uA₂, uB₁})).toFunB a u = choose a := rfl

/-- Left injection lens `inl : P → P + Q` -/
def inl {P : PFunctor.{uA₁, uB}} {Q : PFunctor.{uA₂, uB}} :
    Lens.{uA₁, uB, max uA₁ uA₂, uB} P (P + Q) :=
  Sum.inl ⇆ fun _ => id

/-- Right injection lens `inr : Q → P + Q` -/
def inr {P : PFunctor.{uA₁, uB}} {Q : PFunctor.{uA₂, uB}} :
    Lens.{uA₂, uB, max uA₁ uA₂, uB} Q (P + Q) :=
  Sum.inr ⇆ fun _ => id

/-- Copairing of lenses `[l₁, l₂]ₗ : P + Q → R` -/
def sumPair {P : PFunctor.{uA₁, uB}} {Q : PFunctor.{uA₂, uB}} {R : PFunctor.{uA₃, uB₃}}
    (l₁ : Lens P R) (l₂ : Lens Q R) :
    Lens.{max uA₁ uA₂, uB, uA₃, uB₃} (P + Q) R :=
  Sum.elim l₁.toFunA l₂.toFunA ⇆ fun
    | .inl pa => l₁.toFunB pa
    | .inr qa => l₂.toFunB qa

/-- Parallel application of lenses for coproduct `l₁ ⊎ l₂ : P + Q → R + W` -/
def sumMap {P : PFunctor.{uA₁, uB₁}} {Q : PFunctor.{uA₂, uB₁}} {R : PFunctor.{uA₃, uB₃}}
    {W : PFunctor.{uA₄, uB₃}} (l₁ : Lens P R) (l₂ : Lens Q W) :
    Lens.{max uA₁ uA₂, uB₁, max uA₃ uA₄, uB₃} (P + Q) (R + W) :=
  Sum.map l₁.toFunA l₂.toFunA ⇆ fun
    | .inl pa => l₁.toFunB pa
    | .inr qa => l₂.toFunB qa

/-- Dependent copairing of lenses over `sigma`: `Σ i, F i → R`. -/
def sigmaExists {I : Type v} {F : I → PFunctor.{uA₁, uB₁}} {R : PFunctor.{uA₂, uB₂}}
    (l : ∀ i, Lens (F i) R) :
    Lens (sigma F) R :=
  (fun x => (l (sigma.fst x)).toFunA (sigma.snd x)) ⇆
    (fun x => (l (sigma.fst x)).toFunB (sigma.snd x))

/-- Pointwise mapping of lenses over `sigma`. -/
def sigmaMap {I : Type v} {F : I → PFunctor.{uA₁, uB₁}} {G : I → PFunctor.{uA₂, uB₂}}
    (l : ∀ i, Lens (F i) (G i)) :
    Lens (sigma F) (sigma G) :=
  (fun x => sigma.mk (sigma.fst x) ((l (sigma.fst x)).toFunA (sigma.snd x))) ⇆
    (fun x => (l (sigma.fst x)).toFunB (sigma.snd x))

/-- Projection lens `fst : P * Q → P` -/
def fst {P : PFunctor.{uA₁, uB₁}} {Q : PFunctor.{uA₂, uB₂}} :
    Lens.{max uA₁ uA₂, max uB₁ uB₂, uA₁, uB₁} (P * Q) P :=
  Prod.fst ⇆ fun _ => Sum.inl

/-- Projection lens `snd : P * Q → Q` -/
def snd {P : PFunctor.{uA₁, uB₁}} {Q : PFunctor.{uA₂, uB₂}} :
    Lens.{max uA₁ uA₂, max uB₁ uB₂, uA₂, uB₂} (P * Q) Q :=
  Prod.snd ⇆ fun _ => Sum.inr

/-- Pairing of lenses `⟨l₁, l₂⟩ₗ : P → Q * R` -/
def prodPair {P : PFunctor.{uA₁, uB₁}} {Q : PFunctor.{uA₂, uB₂}} {R : PFunctor.{uA₃, uB₃}}
    (l₁ : Lens P Q) (l₂ : Lens P R) :
    Lens.{uA₁, uB₁, max uA₂ uA₃, max uB₂ uB₃} P (Q * R) :=
  (fun p => (l₁.toFunA p, l₂.toFunA p)) ⇆
    (fun p => Sum.elim (l₁.toFunB p) (l₂.toFunB p))

/-- Parallel application of lenses for product `l₁ ×ₗ l₂ : P * Q → R * W` -/
def prodMap {P : PFunctor.{uA₁, uB₁}} {Q : PFunctor.{uA₂, uB₂}} {R : PFunctor.{uA₃, uB₃}}
    {W : PFunctor.{uA₄, uB₄}} (l₁ : Lens P R) (l₂ : Lens Q W) :
    Lens.{max uA₁ uA₂, max uB₁ uB₂, max uA₃ uA₄, max uB₃ uB₄} (P * Q) (R * W) :=
  (fun pq => (l₁.toFunA pq.1, l₂.toFunA pq.2)) ⇆
    (fun pq => Sum.elim (Sum.inl ∘ l₁.toFunB pq.1) (Sum.inr ∘ l₂.toFunB pq.2))

/-- Dependent pairing of lenses into a `pi`: `P → ∀ i, F i`. -/
def piForall {I : Type v} {P : PFunctor.{uA₁, uB₁}} {F : I → PFunctor.{uA₂, uB₂}}
    (l : ∀ i, Lens P (F i)) :
    Lens P (pi F) :=
  (fun pa i => (l i).toFunA pa) ⇆
    (fun pa ⟨i, fb⟩ => (l i).toFunB pa fb)

/-- Pointwise mapping of lenses over `pi`. -/
def piMap {I : Type v} {F : I → PFunctor.{uA₁, uB₁}} {G : I → PFunctor.{uA₂, uB₂}}
    (l : ∀ i, Lens (F i) (G i)) :
    Lens (pi F) (pi G) :=
  (fun fa i => (l i).toFunA (fa i)) ⇆
    (fun fa ⟨i, gb⟩ => ⟨i, (l i).toFunB (fa i) gb⟩)

/-- Apply lenses to both sides of a composition: `l₁ ◃ₗ l₂ : (P ◃ Q ⇆ R ◃ W)` -/
def compMap {P : PFunctor.{uA₁, uB₁}} {Q : PFunctor.{uA₂, uB₂}} {R : PFunctor.{uA₃, uB₃}}
    {W : PFunctor.{uA₄, uB₄}} (l₁ : Lens P R) (l₂ : Lens Q W) :
    Lens.{max uA₁ uA₂ uB₁, max uB₁ uB₂, max uA₃ uA₄ uB₃, max uB₃ uB₄} (P ◃ Q) (R ◃ W) :=
  (fun ⟨pa, pq⟩ => ⟨l₁.toFunA pa, fun rb' => l₂.toFunA (pq (l₁.toFunB pa rb'))⟩) ⇆
    (fun ⟨pa, pq⟩ ⟨rb, wc⟩ =>
      let pb := l₁.toFunB pa rb
      let qc := l₂.toFunB (pq pb) wc
      ⟨pb, qc⟩)

/-- Apply lenses to both sides of a tensor / parallel product: `l₁ ⊗ₗ l₂ : (P ⊗ Q ⇆ R ⊗ W)` -/
@[implicit_reducible]
def tensorMap {P : PFunctor.{uA₁, uB₁}} {Q : PFunctor.{uA₂, uB₂}} {R : PFunctor.{uA₃, uB₃}}
    {W : PFunctor.{uA₄, uB₄}} (l₁ : Lens P R) (l₂ : Lens Q W) :
    Lens.{max uA₁ uA₂, max uB₁ uB₂, max uA₃ uA₄, max uB₃ uB₄} (P ⊗ Q) (R ⊗ W) :=
  Prod.map l₁.toFunA l₂.toFunA ⇆
    fun (pa, qa) => Prod.map (l₁.toFunB pa) (l₂.toFunB qa)

/-- Lens to introduce `y` on the right: `P → P ◃ y` -/
def tildeR {P : PFunctor.{uA, uB}} : Lens P (P ◃ y) :=
  (fun a => ⟨a, fun _ => PUnit.unit⟩) ⇆ (fun _a => fun ⟨b, _⟩ => b)

/-- Lens to introduce `y` on the left: `P → y ◃ P` -/
def tildeL {P : PFunctor.{uA, uB}} : Lens P (y ◃ P) :=
  (fun a => ⟨PUnit.unit, fun _ => a⟩) ⇆ (fun _a => fun ⟨_, b⟩ => b)

/-- Lens from `P ◃ y` to `P` -/
def invTildeR {P : PFunctor.{uA, uB}} : Lens (P ◃ y) P :=
  (fun a => a.1) ⇆ (fun _ b => ⟨b, PUnit.unit⟩)

/-- Lens from `y ◃ P` to `P` -/
def invTildeL {P : PFunctor.{uA, uB}} : Lens (y ◃ P) P :=
  (fun ⟨_, f⟩ => f PUnit.unit) ⇆ (fun _ b => ⟨PUnit.unit, b⟩)

@[inherit_doc] scoped[PFunctor] infixl:75 " ◃ₗ " => PFunctor.Lens.compMap
@[inherit_doc] scoped[PFunctor] infixl:75 " ×ₗ " => PFunctor.Lens.prodMap
@[inherit_doc] scoped[PFunctor] infixl:75 " ⊎ₗ " => PFunctor.Lens.sumMap
@[inherit_doc] scoped[PFunctor] infixl:75 " ⊗ₗ " => PFunctor.Lens.tensorMap
/-- Notation for the copairing `sumPair l₁ l₂` of two lenses out of a sum; activate it with
`open scoped PFunctor.Lens`. -/
scoped notation "[" l₁ "," l₂ "]ₗ" => sumPair l₁ l₂
/-- Notation for the pairing `prodPair l₁ l₂` of two lenses into a product; activate it with
`open scoped PFunctor.Lens`. -/
scoped notation "⟨" l₁ "," l₂ "⟩ₗ" => prodPair l₁ l₂

set_option linter.checkUnivs false in
/-- The type of lenses from a polynomial functor `P` to `y` -/
-- `Lens.enclose`'s two universe pairs are the independent domain (`uA`/`uB`) and
-- codomain (`uA₁`/`uB₁`) position/direction universes, kept independent.
@[deprecated Section +typeChanged (since := "2026-10-19")]
def enclose (P : PFunctor.{uA, uB}) : Type max uA uA₁ uB uB₁ :=
  Lens P y.{uA₁, uB₁}

/-- The transition lens `δ : Sy^S ⇆ Sy^S ◃ Sy^S` on the self-monomial state
polynomial (Niu–Spivak Example 6.44): `δ = (id, tgt, run)` remembers the start
state, relabels each direction by the state it targets, and composes two hops
into one. It is the comultiplication of the state comonoid `stateComonoid S`, and
the helper behind `speedup`. -/
def fixState {S : Type u} : Lens (selfMonomial S) (selfMonomial S ◃ selfMonomial S) :=
  (fun s₀ => ⟨s₀, fun s₁ => s₁⟩) ⇆ (fun _s₀ => fun ⟨_s₁, s₂⟩ => s₂)

/-- The **two-step system** `(l ◃ l) ∘ₗ δ : Lens (S y^S) (P ◃ P)` of a dynamical system
`l : Lens (S y^S) P` along the transition lens `δ = fixState` (Niu–Spivak Example 6.44):
one composite step exposes a first `P`-position, consumes a direction, exposes a second
`P`-position, and updates. -/
def speedup {S : Type u} {P : PFunctor.{uA, uB}} (l : Lens (selfMonomial S) P) :
    Lens (selfMonomial S) (P ◃ P) :=
  (l ◃ₗ l) ∘ₗ fixState

section Coprod

-- Note the universe levels for `uB` in order to apply coproduct / sum
variable {P : PFunctor.{uA₁, uB₁}} {Q : PFunctor.{uA₂, uB₁}}
  {R : PFunctor.{uA₃, uB₃}} {W : PFunctor.{uA₄, uB₃}} {V : PFunctor.{uA₅, uB₅}}

@[simp]
theorem sumMap_comp_inl (l₁ : Lens P R) (l₂ : Lens Q W) :
    ((l₁ ⊎ₗ l₂) ∘ₗ Lens.inl) = (Lens.inl ∘ₗ l₁) := rfl

@[simp]
theorem sumMap_comp_inr (l₁ : Lens P R) (l₂ : Lens Q W) :
    ((l₁ ⊎ₗ l₂) ∘ₗ Lens.inr) = (Lens.inr ∘ₗ l₂) := rfl

theorem sumPair_comp_sumMap (l₁ : Lens P R) (l₂ : Lens Q W) (f : Lens R V) (g : Lens W V) :
    Lens.sumPair f g ∘ₗ (l₁ ⊎ₗ l₂) = Lens.sumPair (f ∘ₗ l₁) (g ∘ₗ l₂) := by
  ext a <;> rcases a with a | a <;> rfl

@[simp]
theorem sumPair_comp_inl (f : Lens P R) (g : Lens Q R) :
    Lens.sumPair f g ∘ₗ Lens.inl = f := rfl

@[simp]
theorem sumPair_comp_inr (f : Lens P R) (g : Lens Q R) :
    Lens.sumPair f g ∘ₗ Lens.inr = g := rfl

theorem comp_inl_inr (h : Lens.{max uA₁ uA₂, uB₁, uA₃, uB₃} (P + Q) R) :
    Lens.sumPair (h ∘ₗ Lens.inl) (h ∘ₗ Lens.inr) = h := by
  ext a <;> rcases a <;> rfl

@[simp]
theorem sumMap_id :
    Lens.sumMap (Lens.id P) (Lens.id Q) = Lens.id.{max uA₁ uA₂, uB₁} (P + Q) := by
  ext a <;> rcases a <;> rfl

@[simp]
theorem sumPair_inl_inr :
    Lens.sumPair Lens.inl Lens.inr = Lens.id.{max uA₁ uA₂, uB₁} (P + Q) := by
  ext a <;> rcases a <;> rfl

namespace Equiv

/-- Commutativity of coproduct -/
def sumComm (P : PFunctor.{uA₁, uB}) (Q : PFunctor.{uA₂, uB}) :
    Lens.Equiv.{max uA₁ uA₂, uB, max uA₁ uA₂, uB} (P + Q) (Q + P) where
  toLens := Lens.sumPair Lens.inr Lens.inl
  invLens := Lens.sumPair Lens.inr Lens.inl
  left_inv := by
    ext a <;> rcases a with a | a <;> rfl
  right_inv := by
    ext a <;> rcases a with a | a <;> rfl

variable {P : PFunctor.{uA₁, uB}} {Q : PFunctor.{uA₂, uB}} {R : PFunctor.{uA₃, uB}}

@[simp]
theorem sumComm_symm :
    (sumComm P Q).symm = sumComm Q P := rfl

/-- Associativity of coproduct -/
def sumAssoc :
    Lens.Equiv.{max uA₁ uA₂ uA₃, uB, max uA₁ uA₂ uA₃, uB} ((P + Q) + R) (P + (Q + R)) where
  toLens := -- Maps (P + Q) + R to P + (Q + R)
    Lens.sumPair
      (Lens.sumPair -- Maps P + Q to P + (Q + R)
        (Lens.inl) -- Maps P to P + (Q + R) via Sum.inl
        (Lens.inr ∘ₗ Lens.inl) -- Maps Q to P + (Q + R) via Sum.inr ∘ Sum.inl
      )
      (Lens.inr ∘ₗ Lens.inr) -- Maps R to P + (Q + R) via Sum.inr ∘ Sum.inr
  invLens := -- Maps P + (Q + R) to (P + Q) + R
    Lens.sumPair
      (Lens.inl ∘ₗ Lens.inl) -- Maps P to (P + Q) + R via Sum.inl ∘ Sum.inl
      (Lens.sumPair -- Maps Q + R to (P + Q) + R
        (Lens.inl ∘ₗ Lens.inr) -- Maps Q to (P + Q) + R via Sum.inl ∘ Sum.inr
        (Lens.inr) -- Maps R to (P + Q) + R via Sum.inr
      )
  left_inv := by
    ext a <;> rcases a with (a | a) |a <;> rfl
  right_inv := by
    ext a <;> rcases a with a | a |a <;> rfl

/-- Coproduct with `0` is identity (right) -/
def sumZero :
    Lens.Equiv.{max uA uA₁, uB, uA₁, uB} (P + (0 : PFunctor.{uA, uB})) P where
  toLens := Lens.sumPair (Lens.id P) Lens.initial
  invLens := Lens.inl
  left_inv := by
    ext a <;> rcases a with a | a
    · rfl
    · exact PEmpty.elim a
    · rfl
    · exact PEmpty.elim a
  right_inv := by
    ext <;> rfl

/-- Coproduct with `0` is identity (left) -/
def zeroCoprod :
    Lens.Equiv.{max uA uA₁, uB, uA₁, uB} ((0 : PFunctor.{uA, uB}) + P) P where
  toLens := Lens.sumPair Lens.initial (Lens.id P)
  invLens := Lens.inr
  left_inv := by
    ext a <;> rcases a with a | a
    · exact PEmpty.elim a
    · rfl
    · exact PEmpty.elim a
    · rfl
  right_inv := by
    ext <;> rfl

end Equiv

end Coprod

section Prod

variable {P : PFunctor.{uA₁, uB₁}} {Q : PFunctor.{uA₂, uB₂}} {R : PFunctor.{uA₃, uB₃}}
  {W : PFunctor.{uA₄, uB₄}} {V : PFunctor.{uA₅, uB₅}}

@[simp]
theorem fst_comp_prodMap (l₁ : Lens P R) (l₂ : Lens Q W) :
    Lens.fst ∘ₗ (l₁ ×ₗ l₂) = l₁ ∘ₗ Lens.fst := rfl

@[simp]
theorem snd_comp_prodMap (l₁ : Lens P R) (l₂ : Lens Q W) :
    Lens.snd ∘ₗ (l₁ ×ₗ l₂) = l₂ ∘ₗ Lens.snd := rfl

theorem prodMap_comp_prodPair (l₁ : Lens Q W) (l₂ : Lens R V) (f : Lens P Q) (g : Lens P R) :
    (l₁ ×ₗ l₂) ∘ₗ Lens.prodPair f g = Lens.prodPair (l₁ ∘ₗ f) (l₂ ∘ₗ g) := by
  ext a x
  · rfl
  · cases x <;> rfl

@[simp]
theorem fst_comp_prodPair (f : Lens P Q) (g : Lens P R) :
    Lens.fst ∘ₗ Lens.prodPair f g = f := rfl

@[simp]
theorem snd_comp_prodPair (f : Lens P Q) (g : Lens P R) :
    Lens.snd ∘ₗ Lens.prodPair f g = g := rfl

theorem comp_fst_snd (h : Lens.{uA₁, uB₁, max uA₂ uA₃, max uB₂ uB₃} P (Q * R)) :
    Lens.prodPair (Lens.fst ∘ₗ h) (Lens.snd ∘ₗ h) = h := by
  ext a x
  · rfl
  · cases x <;> rfl

@[simp]
theorem prodMap_id :
    Lens.prodMap (Lens.id P) (Lens.id Q) = Lens.id.{max uA₁ uA₂, max uB₁ uB₂} (P * Q) := by
  ext a x
  · rfl
  · cases x <;> rfl

@[simp]
theorem prodPair_fst_snd :
    Lens.prodPair Lens.fst Lens.snd = Lens.id.{max uA₁ uA₂, max uB₁ uB₂} (P * Q) := by
  ext a x
  · rfl
  · cases x <;> rfl

namespace Equiv

/-- Commutativity of product -/
def prodComm (P : PFunctor.{uA₁, uB₁}) (Q : PFunctor.{uA₂, uB₂}) :
    Lens.Equiv.{max uA₁ uA₂, max uB₁ uB₂, max uA₁ uA₂, max uB₁ uB₂} (P * Q) (Q * P) where
  toLens := Prod.swap ⇆ fun _ => Sum.elim Sum.inr Sum.inl
  invLens := Prod.swap ⇆ fun _ => Sum.elim Sum.inr Sum.inl
  left_inv := by
    ext _ b
    · rfl
    · cases b <;> rfl
  right_inv := by
    ext _ b
    · rfl
    · cases b <;> rfl

@[simp]
theorem prodComm_symm : (prodComm P Q).symm = prodComm Q P := rfl

variable {P : PFunctor.{uA₁, uB₁}} {Q : PFunctor.{uA₂, uB₂}} {R : PFunctor.{uA₃, uB₃}}

/-- Associativity of product -/
def prodAssoc : Lens.Equiv.{max uA₁ uA₂ uA₃, max uB₁ uB₂ uB₃, max uA₁ uA₂ uA₃, max uB₁ uB₂ uB₃}
    ((P * Q) * R) (P * (Q * R)) where
  toLens := (_root_.Equiv.prodAssoc P.A Q.A R.A).toFun ⇆
              (fun _ => (_root_.Equiv.sumAssoc _ _ _).invFun)
  invLens := (_root_.Equiv.prodAssoc P.A Q.A R.A).invFun ⇆
               (fun _ => _root_.Equiv.sumAssoc _ _ _)
  left_inv := by
    ext _ b
    · rfl
    · rcases b with b | _
      · cases b <;> rfl
      · rfl
  right_inv := by
    ext _ b
    · rfl
    · rcases b with _ | b
      · rfl
      · cases b <;> rfl

/-- Product with `1` is identity (right) -/
def prodOne :
    Lens.Equiv.{max uA₁ uA₂, max uB₁ uB₂, uA₁, uB₁} (P * (1 : PFunctor.{uA₂, uB₂})) P where
  toLens := Prod.fst ⇆ fun _ => Sum.inl
  invLens := (·, PUnit.unit) ⇆ fun _ => Sum.elim id PEmpty.elim
  left_inv := by
    ext _ b
    · rfl
    · rcases b with _ | b
      · rfl
      · cases b
  right_inv := by
    ext <;> rfl

/-- Product with `1` is identity (left) -/
def oneProd :
    Lens.Equiv.{max uA₁ uA₂, max uB₁ uB₂, uA₁, uB₁} ((1 : PFunctor.{uA₂, uB₂}) * P) P where
  toLens := Prod.snd ⇆ fun _ => Sum.inr
  invLens := (PUnit.unit, ·) ⇆ fun _ => Sum.elim PEmpty.elim id
  left_inv := by
    ext _ b
    · rfl
    · rcases b with b | _
      · cases b
      · rfl
  right_inv := by
    ext <;> rfl

/-- Product with `0` is zero (right) -/
def prodZero :
    Lens.Equiv.{max uA₁ uA₂, max uB₁ uB₂, uA₁, uB₁} (P * (0 : PFunctor.{uA₂, uB₂})) 0 where
  toLens := (fun a => PEmpty.elim a.2) ⇆ fun _ => PEmpty.elim
  invLens := PEmpty.elim ⇆ fun pe => PEmpty.elim pe
  left_inv := by
    ext ⟨_, a⟩ _ <;> exact PEmpty.elim a
  right_inv := by
    ext ⟨_, _⟩

/-- Product with `0` is zero (left) -/
def zeroProd :
    Lens.Equiv.{max uA₁ uA₂, max uB₁ uB₂, uA₁, uB₁} ((0 : PFunctor.{uA₂, uB₂}) * P) 0 where
  toLens := (fun (pa, _) => PEmpty.elim pa) ⇆ fun _ => PEmpty.elim
  invLens := PEmpty.elim ⇆ fun pe => PEmpty.elim pe
  left_inv := by
    ext ⟨a, _⟩ <;> exact PEmpty.elim a
  right_inv := by
    ext ⟨_, _⟩

variable {R : PFunctor.{uA₃, uB₂}}

/-- Left distributive law for product over coproduct -/
def prodCoprodDistrib :
    Lens.Equiv.{max uA₁ uA₂ uA₃, max uB₁ uB₂, max uA₁ uA₂ uA₃, max uB₁ uB₂}
      (P * (Q + R)) ((P * Q) + (P * R)) where
  toLens := (fun (p, qr) => qr.map (p, ·) (p, ·)) ⇆
    (fun | ⟨_, .inl _⟩ | ⟨_, .inr _⟩ => id)
  invLens := Sum.elim (Prod.map id Sum.inl) (Prod.map id Sum.inr) ⇆
    (fun | .inl _ | .inr _ => id)
  left_inv := by ext ⟨_, qr⟩ <;> cases qr <;> rfl
  right_inv := by ext pqpr <;> cases pqpr <;> rfl

/-- Right distributive law for coproduct over product -/
def sumProdDistrib :
    Lens.Equiv.{max uA₁ uA₂ uA₃, max uB₁ uB₂, max uA₁ uA₂ uA₃, max uB₁ uB₂}
      ((Q + R) * P) ((Q * P) + (R * P)) where
  toLens := (fun (qr, p) => qr.map (·, p) (·, p)) ⇆
    (fun | ⟨.inl _, _⟩ | ⟨.inr _, _⟩ => id)
  invLens := Sum.elim (Prod.map Sum.inl id) (Prod.map Sum.inr id) ⇆
    (fun | .inl _ | .inr _ => id)
  left_inv := by ext ⟨qr, _⟩ <;> cases qr <;> rfl
  right_inv := by ext qprp <;> cases qprp <;> rfl

end Equiv

end Prod

section Comp

variable {P : PFunctor.{uA₁, uB₁}} {Q : PFunctor.{uA₂, uB₂}} {R : PFunctor.{uA₃, uB₃}}

@[simp]
theorem compMap_id :
    (Lens.id P) ◃ₗ (Lens.id Q) = Lens.id (P ◃ Q) := by
  ext ⟨_, _⟩ ⟨_, _⟩ <;> rfl

theorem compMap_comp
    {P' : PFunctor.{uA₄, uB₄}} {Q' : PFunctor.{uA₅, uB₅}} {R' : PFunctor.{uA₆, uB₆}}
    (l₁ : Lens P P') (l₂ : Lens Q Q') (l₁' : Lens P' R) (l₂' : Lens Q' R') :
    (l₁' ∘ₗ l₁) ◃ₗ (l₂' ∘ₗ l₂) = (l₁' ◃ₗ l₂') ∘ₗ (l₁ ◃ₗ l₂) := rfl

namespace Equiv

/-- Associativity of composition -/
def compAssoc : (P ◃ Q) ◃ R ≃ₗ P ◃ (Q ◃ R) where
  toLens := (fun ⟨⟨pa, qf⟩, rf⟩ => ⟨pa, fun pb => ⟨qf pb, fun qb => rf ⟨pb, qb⟩⟩⟩) ⇆
            (fun _ ⟨pb, ⟨qb, rb⟩⟩ => ⟨⟨pb, qb⟩, rb⟩)
  invLens := (fun ⟨pa, g⟩ => ⟨⟨pa, fun pb => (g pb).1⟩, fun ⟨pb, qb⟩ => (g pb).2 qb⟩) ⇆
             (fun _ ⟨⟨pb, qb⟩, rb⟩ => ⟨pb, ⟨qb, rb⟩⟩)
  left_inv := rfl
  right_inv := rfl

/-- Composition with `y` is identity (right) -/
def compY : P ◃ y ≃ₗ P where
  toLens := invTildeR
  invLens := tildeR
  left_inv := rfl
  right_inv := rfl

/-- Composition with `y` is identity (left) -/
def yComp : y ◃ P ≃ₗ P where
  toLens := invTildeL
  invLens := tildeL
  left_inv := rfl
  right_inv := rfl

@[deprecated (since := "2026-08-17")] alias compX := compY
@[deprecated (since := "2026-08-17")] alias XComp := yComp

/-- Right distributivity of composition over coproduct (Niu–Spivak Prop 6.47). -/
def sumCompDistrib {R : PFunctor.{uA₃, uB₂}} :
    Lens.Equiv.{max uA₁ uA₂ uA₃ uB₂, max uB₁ uB₂, max uA₁ uA₂ uA₃ uB₂, max uB₁ uB₂}
      ((Q + R : PFunctor.{max uA₂ uA₃, uB₂}) ◃ P) ((Q ◃ P) + (R ◃ P)) where
  toLens := (fun
    | ⟨.inl qa, pf⟩ => .inl ⟨qa, pf⟩
    | ⟨.inr ra, pf⟩ => .inr ⟨ra, pf⟩) ⇆
      (fun | ⟨.inl _, _⟩ | ⟨.inr _, _⟩ => id)
  invLens := (fun
    | .inl ⟨qa, pf⟩ => ⟨.inl qa, pf⟩
    | .inr ⟨ra, pf⟩ => ⟨.inr ra, pf⟩) ⇆
      (fun | .inl _ | .inr _ => id)
  left_inv := by ext ⟨qr, _⟩ <;> cases qr <;> rfl
  right_inv := by ext qprp <;> cases qprp <;> rfl

end Equiv

end Comp

section Tensor

variable {P : PFunctor.{uA₁, uB₁}} {Q : PFunctor.{uA₂, uB₂}} {R : PFunctor.{uA₃, uB₃}}

@[simp]
theorem tensorMap_id : (Lens.id P) ⊗ₗ (Lens.id Q) = Lens.id (P ⊗ Q) :=
  rfl

theorem tensorMap_comp
    {P' : PFunctor.{uA₄, uB₄}} {Q' : PFunctor.{uA₅, uB₅}} {R' : PFunctor.{uA₆, uB₆}}
    (l₁ : Lens P P') (l₂ : Lens Q Q') (l₁' : Lens P' R) (l₂' : Lens Q' R') :
    (l₁' ∘ₗ l₁) ⊗ₗ (l₂' ∘ₗ l₂) = (l₁' ⊗ₗ l₂') ∘ₗ (l₁ ⊗ₗ l₂) := rfl

namespace Equiv

/-- Commutativity of tensor product -/
def tensorComm (P : PFunctor.{uA₁, uB₁}) (Q : PFunctor.{uA₂, uB₂}) : P ⊗ Q ≃ₗ Q ⊗ P where
  toLens := Prod.swap ⇆ (fun _ => Prod.swap)
  invLens := Prod.swap ⇆ (fun _ => Prod.swap)
  left_inv := rfl
  right_inv := rfl

/-- Associativity of tensor product -/
def tensorAssoc : (P ⊗ Q) ⊗ R ≃ₗ P ⊗ (Q ⊗ R) where
  toLens := (_root_.Equiv.prodAssoc _ _ _).toFun ⇆
    (fun _ => (_root_.Equiv.prodAssoc _ _ _).invFun)
  invLens := (_root_.Equiv.prodAssoc _ _ _).invFun ⇆
    (fun _ => (_root_.Equiv.prodAssoc _ _ _).toFun)
  left_inv := rfl
  right_inv := rfl

@[simp, grind =]
theorem tensorAssoc_toFunA (position : ((P ⊗ Q) ⊗ R).A) :
    (tensorAssoc (P := P) (Q := Q) (R := R)).toLens.toFunA position =
      (position.1.1, (position.1.2, position.2)) :=
  rfl

@[simp, grind =]
theorem tensorAssoc_toFunB (position : ((P ⊗ Q) ⊗ R).A)
    (direction : (P ⊗ (Q ⊗ R)).B
      ((tensorAssoc (P := P) (Q := Q) (R := R)).toLens.toFunA position)) :
    (tensorAssoc (P := P) (Q := Q) (R := R)).toLens.toFunB
        position direction =
      ((direction.1, direction.2.1), direction.2.2) :=
  rfl

/-- Tensor product with `y` is identity (right) -/
def tensorY : P ⊗ y ≃ₗ P where
  toLens := Prod.fst ⇆ fun _ => (·, PUnit.unit)
  invLens := (·, PUnit.unit) ⇆ fun _ => Prod.fst
  left_inv := rfl
  right_inv := rfl

/-- Tensor product with `y` is identity (left) -/
def yTensor : y ⊗ P ≃ₗ P where
  toLens := Prod.snd ⇆ fun _ => (PUnit.unit, ·)
  invLens := (PUnit.unit, ·) ⇆ fun _ => Prod.snd
  left_inv := rfl
  right_inv := rfl

@[deprecated (since := "2026-08-17")] alias tensorX := tensorY
@[deprecated (since := "2026-08-17")] alias xTensor := yTensor

/-- Tensor product with `0` is zero (left) -/
def zeroTensor : 0 ⊗ P ≃ₗ 0 where
  toLens := (fun a => PEmpty.elim a.1) ⇆ fun _ => PEmpty.elim
  invLens := PEmpty.elim ⇆ fun a => PEmpty.elim a
  left_inv := by
    ext ⟨a, _⟩ <;> exact PEmpty.elim a
  right_inv := by
    ext a <;> exact PEmpty.elim a

/-- Tensor product with `0` is zero (right) -/
def tensorZero : P ⊗ 0 ≃ₗ 0 where
  toLens := (fun a => PEmpty.elim a.2) ⇆ fun _ => PEmpty.elim
  invLens := PEmpty.elim ⇆ fun a => PEmpty.elim a
  left_inv := by
    ext ⟨_, b⟩ <;> exact PEmpty.elim b
  right_inv := by
    ext a <;> exact PEmpty.elim a

variable {R : PFunctor.{uA₃, uB₂}}

/-- Left distributivity of tensor product over coproduct -/
def tensorCoprodDistrib :
    Lens.Equiv.{max uA₁ uA₂ uA₃, max uB₁ uB₂, max uA₁ uA₂ uA₃, max uB₁ uB₂}
      (P ⊗ (Q + R : PFunctor.{max uA₂ uA₃, uB₂})) ((P ⊗ Q) + (P ⊗ R)) where
  toLens := (fun (p, qr) => qr.map (p, ·) (p, ·)) ⇆
    (fun | ⟨_, .inl _⟩ | ⟨_, .inr _⟩ => id)
  invLens := Sum.elim (Prod.map id Sum.inl) (Prod.map id Sum.inr) ⇆
    (fun | .inl _ | .inr _ => id)
  left_inv := by ext ⟨_, qr⟩ <;> cases qr <;> rfl
  right_inv := by ext pqpr <;> cases pqpr <;> rfl

/-- Right distributivity of tensor product over coproduct -/
def sumTensorDistrib :
    (Q + R : PFunctor.{max uA₂ uA₃, uB₂}) ⊗ P
      ≃ₗ ((Q ⊗ P) + (R ⊗ P) : PFunctor.{max uA₁ uA₂ uA₃, max uB₁ uB₂}) where
  toLens := (fun (qr, p) => qr.map (·, p) (·, p)) ⇆
    (fun | ⟨.inl _, _⟩ | ⟨.inr _, _⟩ => id)
  invLens := Sum.elim (Prod.map Sum.inl id) (Prod.map Sum.inr id) ⇆
    (fun | .inl _ | .inr _ => id)
  left_inv := by ext ⟨qr, _⟩ <;> cases qr <;> rfl
  right_inv := by ext qprp <;> cases qprp <;> rfl

end Equiv

/-- The unique comparison between two possibly differently instantiated
copies of the common tensor/composition unit `y`. -/
def unitComparison : Lens y.{uA₁, uB₁} y.{uA₂, uB₂} :=
  Lens.fromY PUnit.unit

/-- Naturality of the left tensor unitor. The unit component is the canonical
comparison between the independently instantiated source and target copies of
`y`. -/
theorem yTensor_natural
    {P : PFunctor.{uA₁, uB₁}} {Q : PFunctor.{uA₂, uB₂}}
    (f : Lens P Q) :
    f ∘ₗ (Equiv.yTensor (P := P)).toLens =
      (Equiv.yTensor (P := Q)).toLens ∘ₗ
        ((unitComparison : Lens y.{uA₁, uB₁} y.{uA₂, uB₂}) ⊗ₗ f) := by
  rfl

/-- Naturality of the right tensor unitor. The unit component is the canonical
comparison between the independently instantiated source and target copies of
`y`. -/
theorem tensorY_natural
    {P : PFunctor.{uA₁, uB₁}} {Q : PFunctor.{uA₂, uB₂}}
    (f : Lens P Q) :
    f ∘ₗ (Equiv.tensorY (P := P)).toLens =
      (Equiv.tensorY (P := Q)).toLens ∘ₗ
        (f ⊗ₗ
          (unitComparison : Lens y.{uA₁, uB₁} y.{uA₂, uB₂})) := by
  rfl

@[deprecated (since := "2026-08-17")] alias xTensor_natural := yTensor_natural
@[deprecated (since := "2026-08-17")] alias tensorX_natural := tensorY_natural

/-- Naturality of the tensor associator across lenses whose source and target
polynomials may occupy six independent universe pairs. -/
theorem tensorAssoc_natural
    {P₁ : PFunctor.{uA₁, uB₁}} {P₂ : PFunctor.{uA₂, uB₂}}
    {Q₁ : PFunctor.{uA₃, uB₃}} {Q₂ : PFunctor.{uA₄, uB₄}}
    {R₁ : PFunctor.{uA₅, uB₅}} {R₂ : PFunctor.{uA₆, uB₆}}
    (f : Lens P₁ P₂) (g : Lens Q₁ Q₂) (h : Lens R₁ R₂) :
    (f ⊗ₗ (g ⊗ₗ h)) ∘ₗ
        (Equiv.tensorAssoc (P := P₁) (Q := Q₁) (R := R₁)).toLens =
      (Equiv.tensorAssoc (P := P₂) (Q := Q₂) (R := R₂)).toLens ∘ₗ
        ((f ⊗ₗ g) ⊗ₗ h) := by
  rfl

end Tensor

end Lens

namespace Equiv

variable {P : PFunctor.{uA₁, uB₁}} {Q : PFunctor.{uA₂, uB₂}}

/-- Convert an equivalence between two polynomial functors `P` and `Q` to a lens. -/
def toLensEquiv (e : P ≃ₚ Q) : P ≃ₗ Q where
  toLens := e.equivA ⇆ (fun a => (e.equivB a).symm)
  invLens := e.symm.equivA ⇆ (fun a => (e.symm.equivB a).symm)
  left_inv := by
    simp only [Lens.comp, Lens.id]
    ext a b
    · simp [PFunctor.Equiv.symm]
    · simp only [Function.comp_apply]
      have hb :
          (e.equivB a).symm ((e.symm.equivB (e.equivA a)).symm b) =
            _root_.cast (congrArg P.B (e.equivA.symm_apply_apply a)) b := by
        simp only [PFunctor.Equiv.symm]
        exact (equivB_symm_apply (e := e) (a := a) (b := b))
      have h0 : a = e.equivA.symm (e.equivA a) := (e.equivA.symm_apply_apply a).symm
      have hr := eqRec_id_apply (β := P.B) (h := h0) (x := b)
      exact hb.trans hr.symm
  right_inv := by
    simp only [Lens.comp, Lens.id]
    ext a b
    · simp [PFunctor.Equiv.symm]
    · simp only [Function.comp_apply]
      have hb :
          (e.symm.equivB a).symm ((e.equivB (e.symm.equivA a)).symm b) =
            _root_.cast (congrArg Q.B (e.equivA.apply_symm_apply a)) b := by
        simp only [PFunctor.Equiv.symm]
        exact (symm_equivB_symm_apply (e := e) (a := a) (b := b))
      have h0 : a = e.equivA (e.equivA.symm a) :=
        (_root_.Equiv.symm_apply_eq e.equivA).mp rfl
      have hr := eqRec_id_apply (β := Q.B) (h := h0) (x := b)
      exact hb.trans hr.symm

end Equiv

namespace Lens

section Sigma

variable {I : Type v}

instance [IsEmpty I] {F : I → PFunctor.{u}} : IsEmpty (sigma F).A := by
  simp [sigma]
instance [IsEmpty I] {F : I → PFunctor.{u}} {a : (sigma F).A} : IsEmpty ((sigma F).B a) :=
  isEmptyElim a

/-- Sigma of an empty family is the zero functor. -/
def Equiv.emptySigma [IsEmpty I] {F : I → PFunctor.{uA, uB}} : sigma F ≃ₗ 0 :=
  PFunctor.Equiv.toLensEquiv (PFunctor.Equiv.emptySigma (F := F))

@[deprecated (since := "2026-10-19")] alias sigmaEmpty := Equiv.emptySigma

/-- Sigma of a `PUnit`-indexed family is equivalent to the functor itself (up to `ulift`). -/
def Equiv.punitSigma {F : PUnit → PFunctor.{uA, uB}} : sigma F ≃ₗ (F PUnit.unit).ulift :=
  PFunctor.Equiv.toLensEquiv
    (PFunctor.Equiv.trans
      (PFunctor.Equiv.punitSigma (F := F))
      (PFunctor.Equiv.ulift (F PUnit.unit)).symm)

@[deprecated (since := "2026-10-19")] alias sigmaUnit := Equiv.punitSigma

/-- Sigma of a unique-indexed family is equivalent to the default fiber (up to `ulift`). -/
def Equiv.uniqueSigma [Unique I] {F : I → PFunctor.{uA, uB}} : sigma F ≃ₗ (F default).ulift :=
  PFunctor.Equiv.toLensEquiv
    (PFunctor.Equiv.trans
      (PFunctor.Equiv.uniqueSigma (F := F))
      (PFunctor.Equiv.ulift (F default)).symm)

@[deprecated (since := "2026-10-19")] alias sigmaOfUnique := Equiv.uniqueSigma

/-- Left distributivity of product over sigma. -/
def Equiv.prodSigmaDistrib {P : PFunctor.{uA₁, uB₁}} {F : I → PFunctor.{uA₂, uB₂}} :
    (P * sigma F : PFunctor.{max uA₁ uA₂ v, max uB₁ uB₂}) ≃ₗ
      (sigma (fun i => (P * F i : PFunctor.{max uA₁ uA₂, max uB₁ uB₂})) :
        PFunctor.{max uA₁ uA₂ v, max uB₁ uB₂}) :=
  PFunctor.Equiv.toLensEquiv (PFunctor.Equiv.prodSigmaDistrib (P := P) (F := F))

@[deprecated (since := "2026-10-19")] alias prodSigmaDistrib := Equiv.prodSigmaDistrib

/-- Right distributivity of product over sigma. -/
def Equiv.sigmaProdDistrib {P : PFunctor.{uA₁, uB₁}} {F : I → PFunctor.{uA₂, uB₂}} :
    (sigma F * P : PFunctor.{max uA₁ uA₂ v, max uB₁ uB₂}) ≃ₗ
      (sigma (fun i => (F i * P : PFunctor.{max uA₁ uA₂, max uB₁ uB₂})) :
        PFunctor.{max uA₁ uA₂ v, max uB₁ uB₂}) :=
  PFunctor.Equiv.toLensEquiv (PFunctor.Equiv.sigmaProdDistrib (P := P) (F := F))

@[deprecated (since := "2026-10-19")] alias sigmaProdDistrib := Equiv.sigmaProdDistrib

/-- Left distributivity of tensor product over sigma. -/
def Equiv.tensorSigmaDistrib {P : PFunctor.{uA₁, uB₁}} {F : I → PFunctor.{uA₂, uB₂}} :
    P ⊗ sigma F ≃ₗ sigma (fun i => P ⊗ F i) :=
  PFunctor.Equiv.toLensEquiv (PFunctor.Equiv.tensorSigmaDistrib (P := P) (F := F))

@[deprecated (since := "2026-10-19")] alias tensorSigmaDistrib := Equiv.tensorSigmaDistrib

/-- Right distributivity of tensor product over sigma. -/
def Equiv.sigmaTensorDistrib {P : PFunctor.{uA₂, uB₂}} {F : I → PFunctor.{uA₁, uB₁}} :
    sigma F ⊗ P ≃ₗ sigma (fun i => F i ⊗ P) :=
  PFunctor.Equiv.toLensEquiv (PFunctor.Equiv.sigmaTensorDistrib (F := F) (P := P))

@[deprecated (since := "2026-10-19")] alias sigmaTensorDistrib := Equiv.sigmaTensorDistrib

/-- Right distributivity of composition over sigma. -/
def Equiv.sigmaCompDistrib {P : PFunctor.{uA₂, uB₂}} {F : I → PFunctor.{uA₁, uB₁}} :
    sigma F ◃ P ≃ₗ sigma (fun i => F i ◃ P) :=
  PFunctor.Equiv.toLensEquiv (PFunctor.Equiv.sigmaCompDistrib (F := F) (P := P))

@[deprecated (since := "2026-10-19")] alias sigmaCompDistrib := Equiv.sigmaCompDistrib

end Sigma

section Pi

variable {I : Type v}

/-- Pi over a `PUnit`-indexed family is equivalent to the functor itself. -/
def Equiv.piPUnit {P : PFunctor.{u}} : pi (fun (_ : PUnit) => P) ≃ₗ P where
  toLens := (fun f => f PUnit.unit) ⇆ (fun _ pb => ⟨PUnit.unit, pb⟩)
  invLens := (fun pa _ => pa) ⇆ (fun _ spb => spb.2)
  left_inv := rfl
  right_inv := rfl

@[deprecated (since := "2026-10-19")] alias piUnit := Equiv.piPUnit

/-- Pi of a family of zero functors over an inhabited type is the zero functor. -/
def Equiv.piZero [Inhabited I] {F : I → PFunctor.{uA, uB}} (F_zero : ∀ i, F i = 0) :
    pi F ≃ₗ 0 := by
  have : IsEmpty (pi F).A := by
    refine ⟨fun f => ?_⟩
    have hf : (F default).A := f default
    rw [F_zero (default : I)] at hf
    exact hf.elim
  refine
    { toLens := isEmptyElim ⇆ fun a => isEmptyElim a
      invLens := PEmpty.elim ⇆ fun a => PEmpty.elim a
      left_inv := by
        ext a <;> exact isEmptyElim a
      right_inv := by
        ext a <;> exact PEmpty.elim a }

@[deprecated (since := "2026-10-19")] alias piZero := Equiv.piZero

end Pi

namespace Equiv

/-- ULift equivalence for lenses -/
def ulift {P : PFunctor.{uA, uB}} : P.ulift ≃ₗ P where
  toLens := ULift.down ⇆ fun _ => ULift.up
  invLens := ULift.up ⇆ fun _ => ULift.down
  left_inv := rfl
  right_inv := rfl

end Equiv

end Lens

end PFunctor
